starter.config(function ($ionicConfigProvider,
                         $stateProvider,
                         $urlRouterProvider,
                         CONFIG) {

    // 路由区域 ---------------------------------------------------
    // 对路由有不熟悉的，请参考Api文档: https://github.com/angular-ui/ui-router
    // 路由配置
    $stateProvider
    /** ------------- tabs module --------------- **/
    /*home模块*/
        .state("home", {
            url: "/home",
            templateUrl: 'views/home/home.html',
            controller: 'homeCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load("views/home/homeCtrl.js");
                }]
            }
        })
        .state("homeAD", {
            cache: false,
            url: "/homeAD",
            templateUrl: 'views/home/homeAD.html',
            controller: 'homeADCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load("views/home/homeADCtrl.js");
                }]
            }
        })
        /*---------签到-------*/
        .state("dailySignIn", {
            cache: false,
            url: "/dailySignIn",
            templateUrl: 'views/home/dailySignIn/dailySignIn.html',
            controller: 'dailySignInCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/dailySignIn/dailySignInCtrl.js')
                }]
            },
            permission: "Lv1"
        })


        // .state("dailySignIn", {
        //     cache: false,
        //     url: "/dailySignIn",
        //     views: {
        //         '': {
        //             templateUrl: 'views/home/dailySignIn/dailySignIn.html',
        //             controller: 'dailySignInCtrl'
        //         }
        //     },
        //     resolve: {
        //         loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
        //             return $ocLazyLoad.load('views/home/dailySignIn/dailySignInCtrl.js')
        //         }]
        //     },
        //     permission: "Lv1"
        // })


        // .state("dailySignIn", {
        //     cache: false,
        //     templateUrl: 'views/home/dailySignIn/dailySignIn.html',
        //     controller: 'dailySignInCtrl as dailySignIn',
        //     resolve: {
        //         store: function ($ocLazyLoad) {
        //             return $ocLazyLoad.load(
        //                 {
        //                     name: "dailySignIn",  //module name is "store"
        //                     files: ["views/home/dailySignIn/dailySignInCtrl.js"]
        //                 }
        //             )
        //         }
        //     },
        //     permission: "Lv1"
        // })


        // .state("dailySignIn", {
        //     cache: false,
        //     url: "/dailySignIn",
        //     templateUrl: 'views/home/dailySignIn/dailySignIn.html',
        //     controller: 'dailySignInCtrl',
        //     permission: "Lv1"
        // })


        /*---------交易查询-------*/
        .state("tradeQuery", {
            cache: false,
            url: "/tradeQuery",
            templateUrl: 'views/home/tradeQuery/tradeQuery/tradeQuery.html',
            controller: 'tradeQueryCtrl',
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/tradeQuery/tradeQuery/tradeQueryCtrl.js')
                }]
            }
        })
        .state("tradeDetail", {
            cache: false,
            url: "/tradeDetail",
            templateUrl: 'views/home/tradeQuery/tradeDetail/tradeDetail.html',
            controller: 'tradeDetailCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/tradeQuery/tradeDetail/tradeDetailCtrl.js')
                }]
            }
        })
        /*--------------预约办卡-------------*/
        .state("bespeakCard", {
            cache: false,
            url: "/bespeakCard",
            templateUrl: 'views/home/cardBespeak/bespeakCard/bespeakCard.html',
            controller: 'bespeakCardCtrl',
            permission: "Lv1",
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/cardBespeak/bespeakCard/bespeakCardCtrl.js')
                }]
            }
        })
        .state("bespeakRecord", {
            cache: false,
            url: "/bespeakRecord",
            templateUrl: 'views/home/cardBespeak/bespeakRecord/bespeakRecord.html',
            controller: 'bespeakRecordCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/cardBespeak/bespeakRecord/bespeakRecordCtrl.js')
                }]
            }
        })
        .state("bespeakSite", {
            cache: false,
            url: "/bespeakSite",
            templateUrl: 'views/home/cardBespeak/bespeakSite/bespeakSite.html',
            controller: 'bespeakSiteCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/cardBespeak/bespeakSite/bespeakSiteCtrl.js')
                }]
            }
        })

        .state("cardType", {
            cache: false,
            url: "/cardType",
            templateUrl: 'views/home/cardBespeak/cardType/cardType.html',
            controller: 'cardTypeCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/cardBespeak/cardType/cardTypeCtrl.js')
                }]
            }
        })
        /*--------------消息中心-------------*/
        .state("message", {
            cache: false,
            url: "/message",
            templateUrl: 'views/home/message/message/message.html',
            controller: 'messageCtrl',
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/message/message/messageCtrl.js')
                }]
            }
        })
        .state("messageDetail", {
            cache: false,
            url: "/messageDetail",
            templateUrl: 'views/home/message/messageDetail/messageDetail.html',
            controller: 'messageDetailCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/message/messageDetail/messageDetailCtrl.js')
                }]
            }
        })
        /*----------------邀请有奖--------------*/
        .state("inviteRegister", {
            cache: false,
            url: "/inviteRegister",
            templateUrl: 'views/home/inviteRegister/inviteRegister/inviteRegister.html',
            controller: 'inviteRegisterCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/inviteRegister/inviteRegister/inviteRegisterCtrl.js')
                }]
            }
        })
        .state("inviteRecord", {
            cache: false,
            url: "/inviteRecord",
            templateUrl: 'views/home/inviteRegister/inviteRecord/inviteRecord.html',
            controller: 'inviteRecordCtrl',
            params: {params: null},
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/inviteRegister/inviteRecord/inviteRecordCtrl.js')
                }]
            }
        })
        .state("productsRecordList", {
            cache: false,
            url: "/productsRecordList",
            templateUrl: 'views/home/inviteRegister/productsRecordList/productsRecordList.html',
            controller: 'productsRecordListCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/inviteRegister/productsRecordList/productsRecordListCtrl.js')
                }]
            }
        })
        /*--------------注册有礼-------------*/
        .state("registerGift", {
            cache: false,
            url: "/registerGift",
            templateUrl: 'views/home/registerGift/registerGift/registerGift.html',
            controller: 'registerGiftCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/registerGift/registerGift/registerGiftCtrl.js')
                }]
            }
        })
        .state("rewardRegister", {
            cache: false,
            url: "/rewardRegister",
            templateUrl: 'views/home/registerGift/rewardRegister/rewardRegister.html',
            controller: 'rewardRegisterCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/registerGift/rewardRegister/rewardRegisterCtrl.js')
                }]
            }
        })
        /*invest模块*/
        .state("investList", {
            cache: false,
            url: "/investList",
            templateUrl: 'views/invest/investList.html',
            controller: 'investListCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/investListCtrl.js')
                }]
            }
        })
        /*----------------智能存款--------------*/
        .state("demandDeposit", {
            cache: false,
            url: "/demandDeposit",
            templateUrl: 'views/invest/deposit/demandDeposit/demandDeposit.html',
            controller: 'demandDepositCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/demandDeposit/demandDepositCtrl.js')
                }]
            }
        })
        .state("demandChooseCard", {
            cache: false,
            url: "/demandChooseCard",
            templateUrl: 'views/invest/deposit/demandChooseCard/demandChooseCard.html',
            controller: 'demandChooseCardCtrl',
            params: {data: ''},
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/demandChooseCard/demandChooseCardCtrl.js')
                }]
            }
        })
        .state("demandDepositSuccess", {
            cache: false,
            url: "/demandDepositSuccess",
            templateUrl: 'views/invest/deposit/demandDepositSuccess/demandDepositSuccess.html',
            controller: 'demandDepositSuccessCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/demandDepositSuccess/demandDepositSuccessCtrl.js')
                }]
            }
        })

        .state("timeDeposit", {
            cache: false,
            url: "/timeDeposit",
            templateUrl: 'views/invest/deposit/timeDeposit/timeDeposit.html',
            controller: 'timeDepositCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/timeDeposit/timeDepositCtrl.js')
                }]
            }
        })
        .state("timeChooseCard", {
            cache: false,
            url: "/timeChooseCard",
            templateUrl: 'views/invest/deposit/timeChooseCard/timeChooseCard.html',
            controller: 'timeChooseCardCtrl',
            params: {crt_orgno: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/timeChooseCard/timeChooseCardCtrl.js')
                }]
            }
        })
        .state("timeDepositBuy", {
            cache: false,
            url: "/timeDepositBuy",
            templateUrl: 'views/invest/deposit/timeDepositBuy/timeDepositBuy.html',
            controller: 'timeDepositBuyCtrl',
            params: {data: '', data1: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/deposit/timeDepositBuy/timeDepositBuyCtrl.js')
                }]
            }
        })
        .state("metalFilter", {
            cache: false,
            url: "/metalFilter",
            templateUrl: 'views/invest/metal/metalFilter/metalFilter.html',
            controller: 'metalFilterCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/metalFilter/metalFilterCtrl.js')
                }]
            }
        })

        .state("financeDetail", {
            cache: false,
            url: "/financeDetail",
            templateUrl: 'views/invest/finance/financeDetail.html',
            controller: 'financeDetailCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/finance/financeDetailCtrl.js')
                }]
            }
        })
        .state("financeFilter", {
            cache: false,
            url: "/financeFilter",
            templateUrl: 'views/invest/finance/financeFilter/financeFilter.html',
            controller: 'financeFilterCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/finance/financeFilter/financeFilterCtrl.js')
                }]
            }
        })
        /*----------------贵金属--------------*/
        .state("metalDetail", {
            cache: false,
            url: "/metalDetail",
            templateUrl: 'views/invest/metal/metalDetail/metalDetail.html',
            controller: 'metalDetailCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/metalDetail/metalDetailCtrl.js')
                }]
            }
        })
        .state("metalBuy", {
            cache: false,
            url: "/metalBuy",
            templateUrl: 'views/invest/metal/metalBuy/metalBuy.html',
            controller: 'metalBuyCtrl',
            params: {data: '', data1: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/metalBuy/metalBuyCtrl.js')
                }]
            }
        })
        .state("metalOrder", {
            cache: false,
            url: "/metalOrder",
            templateUrl: 'views/invest/metal/metalOrder/metalOrder.html',
            controller: 'metalOrderCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/metalOrder/metalOrderCtrl.js')
                }]
            }
        })
        .state("metalOrderDetail", {
            cache: false,
            url: "/metalOrderDetail",
            templateUrl: 'views/invest/metal/metalOrderDetail/metalOrderDetail.html',
            controller: 'metalOrderDetailCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/metalOrderDetail/metalOrderDetailCtrl.js')
                }]
            }
        })
        .state("choosePick", {
            cache: false,
            url: "/choosePick",
            templateUrl: 'views/invest/metal/choosePick/choosePick.html',
            controller: 'choosePickCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/invest/metal/choosePick/choosePickCtrl.js')
                }]
            }
        })
        /*buy模块*/
        .state("buy", {
            cache: false,
            url: "/buy",
            templateUrl: 'views/pay/buy/buy.html',
            controller: 'buyCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/pay/buy/buyCtrl.js')
                }]
            }
        })
        .state("buyFailed", {
            cache: false,
            url: "/buyFailed",
            templateUrl: 'views/pay/buyFailed/buyFailed.html',
            controller: 'buyFailedCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/pay/buyFailed/buyFailedCtrl.js')
                }]
            }
        })
        .state("paySuccess", {
            cache: false,
            url: "/paySuccess",
            templateUrl: 'views/pay/paySuccess/paySuccess.html',
            controller: 'paySuccessCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/pay/paySuccess/paySuccessCtrl.js')
                }]
            }
        })
        /*mine模块*/
        .state("mine", {
            cache: false,
            url: "/mine",
            templateUrl: 'views/mine/mine.html',
            controller: 'mineCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/mineCtrl.js')
                }]
            }
        })
        /*----------------惠理财--------------*/
        .state("closedAssetsOwn", {
            cache: false,
            url: "/closedAssetsOwn",
            templateUrl: 'views/mine/assets/closedAssets/closedAssetsOwn/closedAssetsOwn.html',
            controller: 'closedAssetsOwnCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/closedAssets/closedAssetsOwn/closedAssetsOwnCtrl.js')
                }]
            }
        })
        .state("productAnnouncement", {
            cache: false,
            url: "/productAnnouncement",
            templateUrl: 'views/mine/assets/closedAssets/productAnnouncement/productAnnouncement.html',
            controller: 'productAnnouncementCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/closedAssets/productAnnouncement/productAnnouncementCtrl.js')
                }]
            }
        })
        .state("closedAssetsApply", {
            cache: false,
            url: "/closedAssetsApply",
            templateUrl: 'views/mine/assets/closedAssets/closedAssetsApply/closedAssetsApply.html',
            controller: 'closedAssetsApplyCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/closedAssets/closedAssetsApply/closedAssetsApplyCtrl.js')
                }]
            }
        })
        /*----------------智能存活期 定期列表--------------*/
        .state("revocableAssets", {
            cache: false,
            url: "/revocableAssets",
            templateUrl: 'views/mine/assets/revocableAssets/revocableAssets.html',
            controller: 'revocableAssetsCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/revocableAssetsCtrl.js')
                }]
            }
        })
        //智能存活期列表
        .state("ZNCCurrentList", {
            cache: false,
            url: "/ZNCCurrentList",
            templateUrl: 'views/mine/assets/ZNCCurrentList/ZNCCurrentList.html',
            controller: 'ZNCCurrentListCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/ZNCCurrentList/ZNCCurrentListCtrl.js')
                }]
            }
        })
        .state("contractDetail", {
            cache: false,
            url: "/contractDetail",
            templateUrl: 'views/mine/assets/revocableAssets/contractDetail/contractDetail.html',
            controller: 'contractDetailCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/contractDetail/contractDetailCtrl.js')
                }]
            }
        })
        .state("changeProduct", {
            cache: false,
            url: "/changeProduct",
            templateUrl: 'views/mine/assets/revocableAssets/changeProduct/changeProduct.html',
            controller: 'changeProductCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/changeProduct/changeProductCtrl.js')
                }]
            }
        })
        .state("revocableAssetsCancel", {
            cache: false,
            url: "/revocableAssetsCancel",
            templateUrl: 'views/mine/assets/revocableAssets/revocableAssetsCancel/revocableAssetsCancel.html',
            controller: 'revocableAssetsCancelCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/revocableAssetsCancel/revocableAssetsCancelCtrl.js')
                }]
            }
        })
        .state("cancelSuc", {
            cache: false,
            url: "/cancelSuc",
            templateUrl: 'views/mine/assets/revocableAssets/cancelSuc/cancelSuc.html',
            controller: 'cancelSucCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/cancelSuc/cancelSucCtrl.js')
                }]
            }
        })
        .state("profitDetail", {
            cache: false,
            url: "/profitDetail",
            templateUrl: 'views/mine/assets/revocableAssets/profitDetail/profitDetail.html',
            controller: 'profitDetailCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/revocableAssets/profitDetail/profitDetailCtrl.js')
                }]
            }
        })
        /*----------------智能存列表详情--------------*/
        .state("fixedAssetsList", {
            cache: false,
            url: "/fixedAssetsList",
            templateUrl: 'views/mine/assets/fixedAssets/fixedAssetsList/fixedAssetsList.html',
            controller: 'fixedAssetsListCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/fixedAssets/fixedAssetsList/fixedAssetsListCtrl.js')
                }]
            }
        })
        .state("fixedAssetsInfo", {
            cache: false,
            url: "/fixedAssetsInfo",
            templateUrl: 'views/mine/assets/fixedAssets/fixedAssetsInfo/fixedAssetsInfo.html',
            controller: 'fixedAssetsInfoCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/fixedAssets/fixedAssetsInfo/fixedAssetsInfoCtrl.js')
                }]
            }
        })
        .state("fixedAssetsDetail", {
            cache: false,
            url: "/fixedAssetsDetail",
            templateUrl: 'views/mine/assets/fixedAssets/fixedAssetsDetail/fixedAssetsDetail.html',
            controller: 'fixedAssetsDetailCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/fixedAssets/fixedAssetsDetail/fixedAssetsDetailCtrl.js')
                }]
            }
        })
        /*----------------积分兑换--------------*/
        .state("integral", {
            cache: false,
            url: "/integral",
            templateUrl: 'views/mine/assets/integral/integral.html',
            controller: 'integralCtrl',
            params: {lastUrl: null},
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/integralCtrl.js')
                }]
            }
        })
        .state("integralList", {
            cache: false,
            url: "/integralList",
            templateUrl: 'views/mine/assets/integral/integralList/integralList.html',
            controller: 'integralListCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/integralList/integralListCtrl.js')
                }]
            }
        })
        .state("integralDetail", {
            cache: false,
            url: "/integralDetail",
            templateUrl: 'views/mine/assets/integral/integralDetail/integralDetail.html',
            controller: 'integralDetailCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/integralDetail/integralDetailCtrl.js')
                }]
            }
        })
        .state("integralOrder", {
            cache: false,
            url: "/integralOrder",
            templateUrl: 'views/mine/assets/integral/integralOrder/integralOrder.html',
            controller: 'integralOrderCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/integralOrder/integralOrderCtrl.js')
                }]
            }
        })
        .state("exchangeRecord", {
            cache: false,
            url: "/exchangeRecord",
            templateUrl: 'views/mine/assets/integral/exchangeRecord/exchangeRecord.html',
            controller: 'exchangeRecordCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/exchangeRecord/exchangeRecordCtrl.js')
                }]
            }
        })
        .state("checkOrder", {
            cache: false,
            url: "/checkOrder",
            templateUrl: 'views/mine/assets/integral/checkOrder/checkOrder.html',
            controller: 'checkOrderCtrl',
            params: {params: null, order_serno: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/checkOrder/checkOrderCtrl.js')
                }]
            }
        })

        .state("checkBranch", {
            cache: false,
            url: "/checkBranch",
            templateUrl: 'views/mine/assets/integral/checkBranch/checkBranch.html',
            controller: 'checkBranchCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/integral/checkBranch/checkBranchCtrl.js')
                }]
            }
        })
        /*----------------mine  ---银行卡--------------*/
        .state("addBankCard", {
            cache: false,
            url: "/addBankCard",
            templateUrl: 'views/mine/bankCards/addBankCard/addBankCard.html',
            controller: 'addBankCardCtrl',
            params: {title: null, cardData: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/addBankCard/addBankCardCtrl.js')
                }]
            }
        })
        .state("addBankCard2", {
            cache: false,
            url: "/addBankCard2",
            templateUrl: 'views/mine/bankCards/addBankCard/addBankCard2.html',
            controller: 'addBankCard2Ctrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/addBankCard/addBankCardCtrl.js')
                }]
            }
        })
        .state("addBankCard3", {
            cache: false,
            url: "/addBankCard3",
            templateUrl: 'views/mine/bankCards/addBankCard/addBankCard3.html',
            controller: 'addBankCard3Ctrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/addBankCard/addBankCardCtrl.js')
                }]
            }
        })
        .state("unBindCard", {
            cache: false,
            url: "/unBindCard",
            templateUrl: 'views/mine/bankCards/unBindCard/unBindCard.html',
            controller: 'unBindCardCtrl',
            params: {'cardInfo': ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/unBindCard/unBindCardCtrl.js')
                }]
            }
        })
        .state("userInfo", {
            cache: false,
            url: "/userInfo",
            templateUrl: 'views/mine/userInfo/userInfo.html',
            controller: 'userInfoCtrl',
            params: {imgUrl: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/userInfo/userInfoCtrl.js')
                }]
            }
        })
        .state("assets", {
            cache: false,
            url: "/assets",
            templateUrl: 'views/mine/assets/assets.html',
            controller: 'assetsCtrl',
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/assetsCtrl.js')
                }]
            }

        })
        .state("closedAssets", {
            cache: false,
            url: "/closedAssets",
            templateUrl: 'views/mine/assets/closedAssets/closedAssets.html',
            controller: 'closedAssetsCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/closedAssets/closedAssetsCtrl.js')
                }]
            }
        })
        .state("fixedAssetsOut", {
            cache: false,
            url: "/fixedAssetsOut",
            templateUrl: 'views/mine/assets/fixedAssets/fixedAssetsOut/fixedAssetsOut.html',
            controller: 'fixedAssetsOutCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/fixedAssets/fixedAssetsOut/fixedAssetsOutCtrl.js')
                }]
            }
        })
        .state("outSuc", {
            cache: false,
            url: "/outSuc",
            templateUrl: 'views/mine/assets/fixedAssets/outSuc/outSuc.html',
            controller: 'outSucCtrl',
            params: {data: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/fixedAssets/outSuc/outSucCtrl.js')
                }]
            }
        })
        .state("validate", {
            cache: false,
            url: "/validate",
            templateUrl: 'views/mine/validate/validate.html',
            controller: 'validateCtrl',
            params: {'validate': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/validate/validateCtrl.js')
                }]
            }
        })
        .state("accountSafe", {
            cache: false,
            url: "/accountSafe",
            templateUrl: 'views/mine/accountSafe/accountSafe.html',
            controller: 'accountSafeCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/accountSafe/accountSafeCtrl.js')
                }]
            }
        })
        .state("realAuthentication", {
            cache: false,
            url: "/realAuthentication",
            templateUrl: 'views/mine/accountSafe/realAuthentication/realAuthentication.html',
            controller: 'realAuthenticationCtrl',
            params: {'step': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/accountSafe/realAuthentication/realAuthenticationCtrl.js')
                }]
            }
        })
        .state("realAuthenticationNext", {
            cache: false,
            url: "/realAuthenticationNext",
            templateUrl: 'views/mine/accountSafe/realAuthentication/realAuthenticationNext.html',
            controller: 'realAuthenticationCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/accountSafe/realAuthentication/realAuthenticationCtrl.js')
                }]
            }
        })
        .state("realAuthenticationLast", {
            cache: false,
            url: "/realAuthenticationLast",
            templateUrl: 'views/mine/accountSafe/realAuthentication/realAuthenticationLast.html',
            controller: 'realAuthenticationCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/accountSafe/realAuthentication/realAuthenticationCtrl.js')
                }]
            }
        })
        .state("order", {
            cache: false,
            url: "/order",
            templateUrl: 'views/mine/accountSafe/order/order.html',
            controller: 'orderCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/accountSafe/order/orderCtrl.js')
                }]
            }
        })
        .state("riskAssessment", {
            cache: false,
            url: "/riskAssessment",
            templateUrl: 'views/mine/bankCards/riskAssessment/riskAssessment.html',
            controller: 'riskAssessmentCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/riskAssessment/riskAssessmentCtrl.js')
                }]
            }
        })
        .state("bankCardList", {
            cache: false,
            url: "/bankCardList",
            templateUrl: 'views/mine/bankCards/bankCardList/bankCardList.html',
            controller: 'bankCardListCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/bankCards/bankCardList/bankCardListCtrl.js')
                }]
            }
        })

        /*----------------设置--------------*/
        .state("setting", {
            cache: false,
            url: "/setting",
            templateUrl: 'views/mine/setting/setting.html',
            controller: 'settingCtrl',
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/settingCtrl.js')
                }]
            }
        })
        .state("setLoginPwd", {
            cache: false,
            url: "/setLoginPwd",
            templateUrl: 'views/mine/setting/setLoginPwd/setLoginPwd.html',
            controller: 'setLoginPwdCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/setLoginPwd/setLoginPwdCtrl.js')
                }]
            }
        })
        .state("checkLoginPwd", {
            cache: false,
            url: "/checkLoginPwd",
            templateUrl: 'views/mine/setting/setGusturePwd/checkLoginPwd.html',
            controller: 'setGusturePwdCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/setGusturePwd/setGusturePwdCtrl.js')
                }]
            }
        })
        .state("setGusturePwd", {
            cache: false,
            url: "/setGusturePwd",
            templateUrl: 'views/mine/setting/setGusturePwd/setGusturePwd.html',
            controller: 'setGusturePwdCtrl',
            params: {'params': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/setGusturePwd/setGusturePwdCtrl.js')
                }]
            }
        })
        .state("setPhoneNum", {
            cache: false,
            url: "/setPhoneNum",
            templateUrl: 'views/mine/setting/setPhoneNum/setPhoneNum.html',
            controller: 'setPhoneNumCtrl',
            params: {'validate': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/setPhoneNum/setPhoneNumCtrl.js')
                }]
            }
        })
        .state("setTradePwd", {
            cache: false,
            url: "/setTradePwd",
            templateUrl: 'views/mine/setting/setTradePwd/setTradePwd.html',
            controller: 'setTradePwdCtrl',
            params: {'validate': null, 'pwdStatus': null, lastUrl: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/setTradePwd/setTradePwdCtrl.js')
                }]
            }
        })
        .state("forgetTradePwd", {
            cache: false,
            url: "/forgetTradePwd",
            templateUrl: 'views/mine/setting/forgetTradePwd/forgetTradePwd.html',
            controller: 'forgetTradePwdCtrl',
            params: {'validate': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/setting/forgetTradePwd/forgetTradePwdCtrl.js')
                }]
            }
        })
        /*----------------商户中心--------------*/
        .state("busCenter", {
            cache: false,
            url: "/busCenter",
            templateUrl: 'views/busCenter/busCenter/busCenter.html',
            controller: 'busCenterCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/busCenter/busCenterCtrl.js')
                }]
            }
        })
        .state("orderTrack", {
            cache: false,
            url: "/orderTrack",
            templateUrl: 'views/busCenter/orderTrack/orderTrack.html',
            controller: 'orderTrackCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/orderTrack/orderTrackCtrl.js')
                }]
            }
        })
        .state("goodsExchange", {
            cache: false,
            url: "/goodsExchange",
            templateUrl: 'views/busCenter/goodsExchange/goodsExchange.html',
            controller: 'goodsExchangeCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/goodsExchange/goodsExchangeCtrl.js')
                }]
            }
        })
        .state("checkUser", {
            cache: false,
            url: "/checkUser",
            templateUrl: 'views/busCenter/checkUser/checkUser.html',
            controller: 'checkUserCtrl',
            params: {'voucher_no': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/checkUser/checkUserCtrl.js')
                }]
            }
        })
        .state("productInfo", {
            cache: false,
            url: "/productInfo",
            templateUrl: 'views/busCenter/productInfo/productInfo.html',
            controller: 'productInfoCtrl',
            params: {'voucher_no': null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/productInfo/productInfoCtrl.js')
                }]
            }
        })
        .state("bill", {
            cache: false,
            url: "/bill",
            templateUrl: 'views/busCenter/bill/bill.html',
            controller: 'billCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/bill/billCtrl.js')
                }]
            }
        })
        .state("busSetting", {
            cache: false,
            url: "/busSetting",
            templateUrl: 'views/busCenter/setting/setting.html',
            controller: 'busSettingCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/setting/settingCtrl.js')
                }]
            }
        })
        .state("busLoginPwd", {
            cache: false,
            url: "/busLoginPwd",
            templateUrl: 'views/busCenter/setting/busLoginPwd/busLoginPwd.html',
            controller: 'busLoginPwdCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/setting/busLoginPwd/busLoginPwdCtrl.js')
                }]
            }
        })
        .state("busPhoneNum", {
            cache: false,
            url: "/busPhoneNum",
            templateUrl: 'views/busCenter/setting/busPhoneNum/busPhoneNum.html',
            controller: 'busPhoneNumCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/setting/busPhoneNum/busPhoneNumCtrl.js')
                }]
            }
        })
        .state("changePwd", {
            cache: false,
            url: "/changePwd",
            templateUrl: 'views/busCenter/changePwd/changePwd.html',
            controller: 'changePwdCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/busCenter/changePwd/changePwdCtrl.js')
                }]
            }
        })
        /*----------------账号--------------*/
        .state("login", {
            url: "/login",
            templateUrl: 'views/account/login/login.html',
            controller: 'loginCtrl',
            cache: false,
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/account/login/loginCtrl.js')
                }]
            }
        })
        .state("loginGesturePwd", {
            cache: false,
            url: "/loginGesturePwd",
            templateUrl: 'views/account/loginGesturePwd/loginGesturePwd.html',
            controller: 'loginGesturePwdCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/account/loginGesturePwd/loginGesturePwdCtrl.js')
                }]
            }
        })
        .state("register", {
            cache: false,
            url: "/register",
            templateUrl: 'views/account/register/register.html',
            controller: 'registerCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/account/register/registerCtrl.js')
                }]
            }
        })

        .state("portrait", {
            cache: false,
            url: "/portrait",
            templateUrl: 'views/mine/userInfo/portrait/portrait.html',
            controller: 'portraitCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/userInfo/portrait/portraitCtrl.js')
                }]
            }
        })
        .state("registerNext", {
            cache: false,
            url: "/registerNext",
            templateUrl: 'views/account/registerNext/registerNext.html',
            controller: 'registerNextCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/account/registerNext/registerNextCtrl.js')
                }]
            }
        })
        .state("registerAgreement", {
            cache: false,
            url: "/registerAgreement",
            templateUrl: 'views/account/registerAgreement/registerAgreement.html',
            controller: 'registerAgreementCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/account/registerAgreement/registerAgreementCtrl.js')
                }]
            }
        })

        .state("helpCenter", {
            cache: false,
            url: "/helpCenter",
            templateUrl: 'views/mine/helpCenter/helpCenter.html',
            controller: 'helpCenterCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/helpCenterCtrl.js')
                }]
            }

        })

        .state("depositsFaq", {
            cache: false,
            url: "/depositsFaq",
            templateUrl: 'views/mine/helpCenter/depositsFaq/depositsFaq.html',
            controller: 'depositsFaqCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/depositsFaq/depositsFaqCtrl.js')
                }]
            }
        })

        .state("coinCertificate", {
            cache: false,
            url: "/coinCertificate",
            templateUrl: 'views/mine/assets/coinCertificate/coinCertificate.html',
            controller: 'coinCertificateCtrl',
            permission: "Lv1",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/coinCertificate/coinCertificateCtrl.js')
                }]
            }
        })

        .state("coinCertificateDetail", {
            cache: false,
            url: "/coinCertificateDetail",
            templateUrl: 'views/mine/assets/coinCertificateDetail/coinCertificateDetail.html',
            controller: 'coinCertificateDetailCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/coinCertificateDetail/coinCertificateDetailCtrl.js')
                }]
            }
        })

        .state("aboutUs", {
            cache: false,
            url: "/aboutUs",
            templateUrl: 'views/mine/helpCenter/aboutUs/aboutUs.html',
            controller: 'aboutUsCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/aboutUs/aboutUsCtrl.js')
                }]
            }
        })

        .state("feedback", {
            cache: false,
            url: "/feedback",
            templateUrl: 'views/mine/helpCenter/feedback/feedback.html',
            controller: 'feedbackCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/feedback/feedbackCtrl.js')
                }]
            }
        })

        .state("lifeQuestion", {
            cache: false,
            url: "/lifeQuestion",
            templateUrl: 'views/mine/helpCenter/lifeQuestion/lifeQuestion.html',
            controller: 'lifeQuestionCtrl',
            params: {type: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/lifeQuestion/lifeQuestionCtrl.js')
                }]
            }
        })

        .state("questionDetails", {
            cache: false,
            url: "/questionDetails",
            templateUrl: 'views/mine/helpCenter/questionDetails/questionDetails.html',
            controller: 'questionDetailsCtrl',
            params: {params: null},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/helpCenter/questionDetails/questionDetailsCtrl.js')
                }]
            }
        })

        .state("financeCommend", {
            cache: false,
            url: "/financeCommend",
            templateUrl: 'views/mine/assets/financeCommend/financeCommend.html',
            controller: "financeCommendCtrl",
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/mine/assets/financeCommend/financeCommendCtrl.js')
                }]
            }
        })
        /*----------------market营销-------------*/

        .state("marketFinanceDetail", {
            cache: false,
            url: "/marketFinanceDetail",
            templateUrl: 'views/market/marketFinanceDetail/marketFinanceDetail.html',
            controller: 'marketFinanceDetailCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/market/marketFinanceDetail/marketFinanceDetailCtrl.js')
                }]
            }
        })
        .state("marketTimeDeposit", {
            cache: false,
            url: "/marketTimeDeposit",
            templateUrl: 'views/market/marketTimeDeposit/marketTimeDeposit.html',
            controller: 'marketTimeDepositCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/market/marketTimeDeposit/marketTimeDepositCtrl.js')
                }]
            }
        })
        .state("marketMetalDetail", {
            cache: false,
            url: "/marketMetalDetail",
            templateUrl: 'views/market/marketMetalDetail/marketMetalDetail.html',
            controller: 'marketMetalDetailCtrl',
            params: {data: ''},
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/market/marketMetalDetail/marketMetalDetailCtrl.js')
                }]
            }
        })
        .state("pub404", {
            cache: false,
            url: "/pub404",
            templateUrl: 'views/home/pub404.html',
            controller: 'pub404Ctrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/home/pub404Ctrl.js')
                }]
            }
        })
        .state("demo", {
            cache: false,
            url: "/demo",
            templateUrl: 'views/demo/diykeyboard.html',
            controller: 'diykeyboardCtrl',
            resolve: {
                deps: ["$ocLazyLoad", function ($ocLazyLoad) {
                    return $ocLazyLoad.load('views/demo/diykeyboardCtrl.js')
                }]
            }
        })
    ;//路由end

    //读取本地广告文件
    var adData = localStorage.getItem(CONFIG.STORAGE_NAME);
    if (!adData) {
        console.log("INFO: 首次进入");
        $urlRouterProvider.otherwise("homeAD");
    } else {
        console.log("INFO: 非首次进入");
        $urlRouterProvider.otherwise("home");
    }

})
;
