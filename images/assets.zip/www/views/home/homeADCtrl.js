/**
 * Created by fengc on 16/4/13.
 启动页
 */

starter.controller("homeADCtrl",
    function ($scope,
              $interval,
              $state,
              $timeout,
              $ionicHistory,
              $rootScope,
              resourceSvc,
              CONFIG) {

        $ionicHistory.clearHistory();
        resourceSvc.setLocal(CONFIG.STORAGE_NAME, 'true');
        $scope.pic = ['images/homeAD/J2_01.png', 'images/homeAD/J2_03.png', 'images/homeAD/J2_05.png'];
        document.addEventListener("deviceready", function () {
            console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
            if (navigator.splashscreen) navigator.splashscreen.hide();
        });
        var swiper = null;
        $timeout(function () {
            swiper = new Swiper('.home-ad', {
                observer: true,
                observeParents: true,
                pagination: '.ad-pagination',
                paginationClickable: true,
                autoplay: 5000,
                loop: false,
                preventClicks: false,
                centeredSlides: true,   //设置活动块居中
                simulateTouch: false  //默认为true，Swiper接受鼠标点击、拖动。
            });
        });
        $scope.$on("$destroy", function () {
            if (swiper && swiper.destroy) swiper.destroy();
        });
    });
