/**
 * Created by kayak on 16/9/18.
 */
starter.controller('inviteRegisterCtrl',
    function ($rootScope, $scope, $state, $location, $timeout, CONFIG, encryptSvc, popupSvc, toolSvc, CONSTANT, homeSvc, $cordovaClipboard, shareApp) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //获取用户信息
        var head_jsessionid;
        //初始化邀请好友人数和券数量
        $scope.conf = {
            total_invited: "0"
            , total_vouchers: "0"
            , shareUrl: ""
            , shareUrlState: false //初始化分享链接状态
            , shareAppTitle: "邀请好友" //分享页面标题 ，如果有活动，显示邀请有奖，无则邀请好友
            , shareAppState: false  //分享页面标题 ，如果有活动，状态为true，无则false
        };
        $scope.outUrl = "";
        //这是一个异步请求，等同于顺序执行中写的最后面。用于获取真实的邀请好友数据
        encryptSvc.then(function (encrypt) {
            head_jsessionid = encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID);
            if (head_jsessionid) {
                homeSvc.invitedNum().then(function (data) {
                    if (data.ret_code == "0000") {
                        $scope.conf.total_invited = data.total_invited;
                        $scope.conf.total_vouchers = data.total_vouchers;
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            }
        });
        //获取活动信息   活动信息获取成功时生成分享链接及二维码
        $scope.getActInfo = function () {
            homeSvc.inviteAction().then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.actionInfo = data;
                    if (data.activity_status == "1") {
                        console.log(data.activity_status)
                        $scope.conf.shareAppState = true;
                        $scope.conf.shareAppTitle = "邀请有奖";
                    }
                    var shareInfo = {
                        activity_id: data.activity_id || "",
                        activity_name: data.activity_name || "",
                        activity_type: data.activity_type || "",
                        product_id: "",
                        product_name: "",
                        product_type: "",
                        share_type: "1", //share_type 1分享应用 2分享理财 3 分享智能存 4分享贵金属
                        record_type: "0"  //0邀请注册，1产品分享
                    };
                    console.log(shareInfo);
                    homeSvc.shareId(shareInfo).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.conf.shareUrl = CONFIG.SHARE_URL + "registerShare/#/registerShare?" + data.record_id;
                            shareApp.qrcode($scope.conf.shareUrl, "#qrcodeCanvas").then(function (data) {
                                $scope.outUrl = data;
                                console.debug($scope.outUrl);
                            });
                            if ($scope.conf.shareUrlState) {
                                $scope.inviteShare();
                                $scope.conf.shareUrlState = false;
                            }
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });

                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        $scope.getActInfo();


        //点击转向手机号码tab
        $scope.viewPhoneList = function () {
            //if (head_jsessionid) {
            $state.go("inviteRecord", {params: {type: '1'}});
            //} else {
            //    $state.go("login");
            //}
        };
        //点击转向兑换券tab
        $scope.viewRewradList = function () {
            //if (head_jsessionid) {
            $state.go("coinCertificate");
            //} else {
            //    $state.go("login");
            //}
        };

        //点击弹出分享弹框
        $scope.inviteShare = function () {
            if (!$scope.outUrl) {
                $scope.conf.shareUrlState = true;
                return;
            }
            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };
        //点击放大二维码
        $scope.showQrcode = function () {
            $scope.share.close();
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //长按复制文字
        if (!CONFIG.DEBUG_ON_CHROME) {
            $scope.copyUrl = function () {
                $cordovaClipboard
                    .copy($scope.outUrl)
                    .then(function () {
                        $scope.share.close();
                        var copySucPopup = popupSvc.alert({
                            title: "复制成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            copySucPopup.close();
                        }, 1000);
                    }, function () {
                        // error
                    });
            };
        }
        //分享APP
        $scope.share2QQ = function () {
            shareApp.share2QQ($scope.outUrl);
        };
        $scope.share2QZone = function () {
            shareApp.share2QZone($scope.outUrl);
        };
        $scope.share2Wechat = function (scene) {
            shareApp.share2Wechat(scene, $scope.outUrl);
        };
        $scope.share2Weibo = function () {
            shareApp.share2Weibo($scope.outUrl);
        };
    }
);