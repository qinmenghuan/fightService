/**
 * Created by kayak on 16/9/18.
 */
starter.controller('productsRecordListCtrl',
    function ($scope, $rootScope, temporarySvc,$state, $location, $stateParams, homeSvc, popupSvc, encryptSvc, CONFIG, $cordovaClipboard) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.params = temporarySvc.get("p1");
        homeSvc.inviteFinancePerson({query_flag:"2",record_id:$scope.params.record_id}).then(function (data) {
            if(data.ret_code == "0000"){
                $scope.phoneList = data.product_recommand_list
            }else{
                showErrorInfo(data.ret_msg);
            }
        })
    }
);