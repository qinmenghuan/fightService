/**
 * Created by kayak on 16/9/18.
 */
starter.controller('inviteRecordCtrl',
    function ($scope, $rootScope, $state, $location, $stateParams, $timeout, homeSvc, popupSvc, encryptSvc, temporarySvc, CONFIG, $cordovaClipboard, shareApp, shortUrlSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //提示弹出，1000ms后消失
        var tipsPop = function (msg) {
            var tipPopup = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                tipPopup.close();
            }, CONFIG.ALERT_DURATION_TIME);
        };
        console.log($stateParams.params);
        //初始化状态tag
        if ($stateParams.params) {
            $scope.select = $stateParams.params.type
        } else {
            $scope.select = homeSvc.type ? homeSvc.type : "1"
        }
        //初始化各列表数组
        $scope.phoneList = [];
        $scope.productList = [];
        $scope.infoList = [];
        $scope.newsList = [];
        //获取分享app记录
        var getPhone = function () {
            //homeSvc.invitePerson({activity_type :"01"}).then(function (data) {
            homeSvc.invitePerson({activity_type: ""}).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.phoneList = data.invited_list;
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };

        //获取分享理财产品记录
        var getProducts = function () {
            //homeSvc.invitePerson({activity_type :"01"}).then(function (data) {
            homeSvc.inviteFinance({record_type: "1"}).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.productList = data.record_list;
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //获取分享分享理财知识记录
        var getInfo = function () {
        };
        //获取分享分享资讯记录
        var getNews = function () {
        };
        //获取用户基本信息，用于生成分享链接及二维码
        //share_type 1分享应用 2分享理财 3 分享智能存 4分享贵金属
        $scope.getShareUrl = function () {
            homeSvc.inviteAction().then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    var shareInfo = {
                        activity_id: data.activity_id || "",
                        activity_name: data.activity_name || "",
                        activity_type: data.activity_type || "",
                        product_id: "",
                        product_name: "",
                        product_type: "",
                        share_type: "1",
                        record_type: "0"  //0邀请注册，1产品分享
                    };
                    console.log(shareInfo);
                    homeSvc.shareId(shareInfo).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.baseUrl = CONFIG.SHARE_URL + "registerShare/#/registerShare?" + data.record_id;
                            shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                                $scope.outUrl = data;
                            });
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });

                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        $scope.showList = function (item) {
            temporarySvc.set("p1", item);
            $state.go("productsRecordList");
        }
        //初始状态展示分享APP记录
        //点击切换按钮，分别展示不同数据
        $scope.changeType = function (flag) {
            switch (flag) {
                case "1":
                    $scope.select = homeSvc.type = "1";
                    getPhone();
                    $scope.getShareUrl();
                    break;
                case "2":
                    $scope.select = homeSvc.type = "2";
                    getProducts();
                    break;
                case "3":
                    $scope.select = homeSvc.type = "3";
                    getInfo();
                    break;
                case "4":
                    $scope.select = homeSvc.type = "4";
                    getNews();
                    break;
            }
        };
        $scope.changeType($scope.select);
        //可拖动tabs,单屏显示3个
        var swiper = new Swiper(".record-tag", {
            pagination: '.swiper-pagination',
            slidesPerView: 3,
            paginationClickable: true,
            spaceBetween: 0
        });
        //离开当前页面时，销毁swiper的事件。节约内存
        $scope.$on("$destroy", function () {
            if (swiper && swiper.destroy) swiper.destroy();
        });
        /*begin 分享弹框*/

        //弹出分享框-分享APp
        $scope.shareApp = function () {
            if (!$scope.outUrl) {
                tipsPop("暂未生成分享链接，请稍后重试");
                $scope.getShareUrl();
                return;
            }
            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };
        
        //弹出分享框-分享理财
        $scope.shareFinance = function (item) {
            $scope.baseUrl = CONFIG.SHARE_URL + "registerShare/#/registerShare?" + item.record_id;
            shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                $scope.outUrl = data;
            });
            if (!$scope.outUrl) {
                tipsPop("暂未生成分享链接，请稍后重试");
                $scope.getActInfo();
                return;
            }
            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };
        //点击放大二维码
        $scope.showQrcode = function () {
            $scope.share.close();
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //长按复制文字
        if (!CONFIG.DEBUG_ON_CHROME) {
            $scope.copyUrl = function () {
                $cordovaClipboard
                    .copy($scope.outUrl)
                    .then(function () {
                        $scope.share.close();
                        var copySucPopup = popupSvc.alert({
                            title: "复制成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            copySucPopup.close();
                        }, 1000);
                    }, function () {
                        // error
                    });
            };
        }
        /*end 分享弹框*/
        //分享APP
        $scope.share2QQ = function () {
            shareApp.share2QQ($scope.outUrl);
        };
        $scope.share2QZone = function () {
            shareApp.share2QZone($scope.outUrl);
        };
        $scope.share2Wechat = function (scene) {
            shareApp.share2Wechat(scene, $scope.outUrl);
        };
        $scope.share2Weibo = function () {
            shareApp.share2Weibo($scope.outUrl);
        };
    }
);