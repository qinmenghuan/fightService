/**
 * Created by kayak on 16/9/18.
 */
starter.controller('bespeakSiteCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              $sce,
              homeSvc,
              $filter,
              encryptSvc,
              CONFIG,
              mapSvc,
              $ionicScrollDelegate,
              $timeout) {
        $scope.mapFlag = true;//让地图延迟显示避免有些标签显示不出来
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var walkingFlag = false, selectSiteFlag = false, dataInfo = $stateParams.params;
        $scope.myLocation = [];//定位当前的经纬度
        $scope.nowClick = null;//点击麻点或银行列表获取到的信息
        $scope.bespeak = {siteMap: ""};//输入查询网点名称
        $scope.selectList = [];//查询当前城市中的网点信息
        $scope.bespeakList = {};//预约成功获取的返回值信息
        $scope.conf = {
            step: (dataInfo && dataInfo.step) ? dataInfo.step : "1"
        };
        if (dataInfo && dataInfo.step) {
            $scope.nowClick = dataInfo;
            $scope.bespeakList = dataInfo;
            $scope.bespeakList.remain_show = $filter("remainTime")(dataInfo.time);
        }
        $scope.onComplete = function (data) {
            $scope.myLocation = data;
            if (dataInfo && dataInfo.step) {
                var data = $scope.nowClick;
                mapSvc.infoWindow({
                    position: [parseFloat(data.lng), parseFloat(data.lat)],
                    name: data.orgname || data.org_name,
                    address: data.address
                });
                if (walkingFlag) {
                    $scope.walkingNavigation(data);
                    walkingFlag = false;
                }
                if (selectSiteFlag) {
                    $scope.selectSite($scope.bespeak.siteMap);
                    selectSiteFlag = false;
                }
            }
        };
        $scope.addCloudLayer = function (data, location) {
            $scope.myLocation = location || $scope.myLocation;
            var distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance(data._location).toFixed(1);
            $scope.nowClick = {
                orgno: data.org_no + "",
                orgname: data._name,
                address: data._address,
                lng: data._location.lng,
                lat: data._location.lat,
                distance: distance
            };
            $scope.$apply();
        };
        //调用mapSvc服务初始化地图
        mapSvc.init('map', $scope.onComplete, $scope.addCloudLayer);

        $scope.goBack = function (type) {
            if (type == 0) {
                $state.go("bespeakCard");
            } else {
                $scope.conf.step = type;
            }
            if (type == 1) {
                $ionicScrollDelegate.scrollTop();
                $timeout(function () {
                    $scope.mapFlag = true;
                }, 300)
            }
        };
        //确认预约
        $scope.onConfirmReserve = function (item) {
            if (!item) return showErrorInfo("请选择银行网点");
            var params = $stateParams.params || {};
            params.org_no = item.orgno;
            params.lng = item.lng;
            params.lat = item.lat;
            params.address = item.address;
            homeSvc.bespeakCard(params).then(function (data) {
                if (data.ret_code === "0000") {
                    $scope.conf.step = "3";
                    $scope.bespeakList = data;
                    $scope.bespeakList.remain_show = $filter("remainTime")(data.sub_date_time);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //查询输入的银行名称
        $scope.selectSite = function (siteMap) {
            if (!$scope.myLocation.length) {
                selectSiteFlag = true;
                return;
            }
            $scope.conf.step = "2";
            $scope.mapFlag = false;
            homeSvc.webSite({orgname: siteMap || ""}).then(function (data) {
                if (data.ret_code === "0000") {
                    data.coordinatelist.map(function (item) {
                        item.distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance([parseFloat(item.lng), parseFloat(item.lat)]).toFixed(1);
                        item.distanceNum = parseFloat(item.distance);
                    });
                    $scope.selectList = data.coordinatelist;
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //列表中选择
        $scope.checkSelected = function (item) {
            mapSvc.infoWindow({
                position: [parseFloat(item.lng), parseFloat(item.lat)],
                name: item.orgname,
                address: item.address
            });
            $scope.nowClick = item;
            $scope.conf.step = "1";
            $ionicScrollDelegate.scrollTop();
            $timeout(function () {
                $scope.mapFlag = true;
            }, 300);
        };
        //导航
        $scope.walkingNavigation = function (nowClick) {
            if (!$scope.myLocation.length) {
                walkingFlag = true;
                return;
            }
            walkingFlag = false;
            var tUrl = 'http://m.amap.com/navi/?start=' + $scope.myLocation[0] + ',' + $scope.myLocation[1] + '&dest=' + nowClick.lng + ',' + nowClick.lat + '&destName=' + nowClick.orgname + '&naviBy=car&key=06f54a9e326e97b16a1eda53dbf58718'
            if (CONFIG.DEBUG_ON_CHROME) {
                $scope.conf.step = "4";
                $scope.tUrl = $sce.trustAsResourceUrl(tUrl);
            } else {
                var config = angular.extend(CONFIG.BROWSER_CONFIG, {title: {staticText: "导航"}});
                cordova.ThemeableBrowser.open(tUrl, '_blank', config);
            }
        };
    }
);