/**
 * Created by kayak on 16/9/18.
 */
starter.controller('cardTypeCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              homeSvc,temporarySvc,
              CONFIG,
              popupSvc,
              $timeout) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.cardKey = 0;
        homeSvc.cardType({
            card_type : temporarySvc.get("p1").card_type,
            page:"0",
            rows:"5"
        }).then(function(data){
            console.log(data);
            if(data.ret_code=="0000") {
                data.card_type_list.map(function(item){
                    item.card_pic_url_id=CONFIG.HTTP_URL+"platform/showimg.json?resource_id="+item.card_aside_url;
                })
                $scope.card_type_list = data.card_type_list;
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.lasCard = function () {
            if($scope.cardKey==0){
                var Popup = popupSvc.alert({
                    title: "当前已是第一张卡",
                    cssClass: "popup-container",
                    buttons: []
                });
                $timeout(function () {
                    Popup.close();
                }, 1000);
            }
            if($scope.cardKey > 0){
                $scope.cardKey--;
            }
        };
        $scope.nextCard = function () {
            if($scope.cardKey==$scope.card_type_list.length-1){
                var Popup = popupSvc.alert({
                    title: "当前已是最后一张卡",
                    cssClass: "popup-container",
                    buttons: []
                });
                $timeout(function () {
                    Popup.close();
                }, 1000);
            }
            if($scope.cardKey <  $scope.card_type_list.length-1){
                $scope.cardKey++;
            }
        };
        $scope.checkCard = function(){
            var params = angular.extend(temporarySvc.get("p1"),{
                card_id : $scope.card_type_list[$scope.cardKey].card_id,
                card_name : $scope.card_type_list[$scope.cardKey].card_name,
                card_kind: $scope.card_type_list[$scope.cardKey].card_kind
            });
            console.log(params);
            temporarySvc.set("p1",params);
            $state.go("bespeakCard");
        };
        $scope.$ionicGoBack = function(){
            $state.go("bespeakCard");
        };
    }
)
;