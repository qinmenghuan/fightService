/**
 * Created by kayak on 16/9/18.
 */
starter.controller('bespeakCardCtrl',
    function ($scope,
              $rootScope,
              $stateParams,
              $state,
              $location,
              CONSTANT,
              util,
              popupSvc,
              CONFIG,
              $timeout,
              temporarySvc,
              homeSvc,
              accountSvc,
              toolSvc,
              $cordovaKeyboard) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.conf = {
            card_type : "1",
            codeState : true,
            codeText : '获取验证码'
        };
        var paramsCard = temporarySvc.get("p1");
        console.log(paramsCard);
        $scope.card = {
            card_type : '1', //卡类型  （1-借记卡  2-信用卡）
            card_kind : paramsCard.card_kind || '', //卡种类（数据字典）
            card_no : paramsCard.card_no || '', // 卡编号
            card_name : paramsCard.card_name || '', //卡名称？
            sub_user_name : paramsCard.sub_user_name || '',//预约人姓名
            sub_user_id_type : 'A',//预约人证件类型
            sub_user_id_code : paramsCard.sub_user_id_code || '',//预约人证件号码
            sub_user_phone : paramsCard.sub_user_phone || '',//预约人手机号
            code : '',//验证码
            code_id : '',//指令序号 短信流水号
            response_date : ''//指令时间
        };

        //提示弹出，1000ms后消失
        var tipsPop = function (msg) {
            var tipPopup = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                tipPopup.close();
            }, CONFIG.ALERT_DURATION_TIME);
        };

        //重写返回
        $scope.$ionicGoBack = function(){
            $state.go("home");
        };
        //初始化参数
        /*var params = temporarySvc.get("p1");
        console.log(params);
        if(params.pageState == "2"){
            $scope.card.card_no = params.id;
            $scope.card.card_name = params.name;
            $scope.card.card_kind = params.card_kind;
        }*/
        //从暂存服务中取出数据
        //转向选择卡类型页
        $scope.checkCard = function(cardType){
            /*选择卡片时将其它数据暂存*/
            temporarySvc.set("p1",$scope.card);
            $state.go("cardType");
        };
        //切换信用卡和借记卡
        $scope.changeType = function(flag){
            $scope.conf.card_type = flag;
            $scope.card.card_type = flag;
        };
        //信用卡暂不提供预约
        $scope.tipPop = function () {
            tipsPop("暂不提供信用卡预约");
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.conf.codeText = '获取验证码';
            $scope.conf.codeState = false;
        }
        //获取验证码
        $scope.getCode = function (phone) {
            //验证手机号是否合规
            var checkTel=toolSvc.checkTel(phone);
            if(checkTel){
                showErrorInfo(checkTel);
                return;
            }
            accountSvc.getCode({mobile: phone, busi_type: "001"}).then(function(data){
                    if(data.ret_code === "0000"){
                        $scope.card.code_id = data.code_id;
                        $scope.card.response_date = data.response_date;
                        $scope.timer = data.valid_time;
                        $scope.conf.codeState = false;
                        //获取当前时间毫秒数
                        var startTime = new Date().getTime();
                        //获取结束时间毫秒数
                        var endTime = startTime+60*1000;
                        $scope.countDown = util.countDown({timer: endTime});
                        $scope.countDown.run(function (s) {
                            $scope.conf.codeText = s + "s后重新获取";
                        }, codeReset);
                    }else {
                        showErrorInfo(data.ret_msg);
                        return false;
                    }
                });
        };
        //短信验证码验证成功，传递卡片信息到网点页。
        $scope.onBespeak = function(cardInfo){
            console.log("cardInfo",cardInfo);

            //验证卡种类是否合规
            var checkCardType=toolSvc.checkCardType(cardInfo.card_type);
            if(checkCardType){
                showErrorInfo(checkCardType);
                return;
            }
            //验证卡种类名称是否合规
            var checkCardTypeName=toolSvc.checkCardType(cardInfo.card_name);
            if(checkCardTypeName){
                showErrorInfo(checkCardTypeName);
                return;
            }
            //验证姓名是否合规
            var checkName=toolSvc.checkName(cardInfo.sub_user_name);
            if(checkName){
                showErrorInfo(checkName);
                return;
            }
            //验证身份证号是否合规
            var checkID=toolSvc.checkID(cardInfo.sub_user_id_code);
            if(checkID){
                showErrorInfo(checkID);
                return;
            }
            //验证手机号是否合规
            var checkTel=toolSvc.checkTel(cardInfo.sub_user_phone);
            if(checkTel){
                showErrorInfo(checkTel);
                return;
            }
            //验证短信验证码是否合规
            var checkSmsCode=toolSvc.checkSmsCode(cardInfo.code);
            if(checkSmsCode){
                showErrorInfo(checkSmsCode);
                return;
            }
            if (CONFIG.DEBUG_ON_CHROME) {
                $state.go("bespeakSite", {params: cardInfo});
            }else {
                if ($cordovaKeyboard.isVisible()) {
                    $cordovaKeyboard.close();
                    $timeout(function () {
                        $state.go("bespeakSite", {params: cardInfo});
                    }, 500)
                } else {
                    $state.go("bespeakSite", {params: cardInfo});
                }
            }
        }
    }
);