/**
 * Created by kayak on 16/9/18.
 */
starter.controller('bespeakRecordCtrl',
    function ($scope,
              homeSvc,
              $state,
              $location,
              $ionicScrollDelegate,
              $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.select = homeSvc.select || "1";
        $scope.currentPage = 1;
        $scope.limit = 10;
        $scope.recordList=[];
        $scope.getPageDate = function (params) {
          return  homeSvc.bespeakRecord(angular.extend({
              card_type : $scope.select,
              page : $scope.currentPage + "",
              rows : $scope.limit + ""
          },params)).then(function (data) {
              if(data.ret_code == "0000"){
                  $scope.islastpage = data.islastpage; //是否最后一页
                  return data;
              }else{
                  showErrorInfo(data.ret_msg);
              }
          })
        };
        $scope.changeType = function(flag){
            $scope.select = flag;
            homeSvc.select = flag;
            $scope.currentPage = 1;
            $scope.recordList=[];
                $scope.getPageDate({}).then(function (data) {
                    if(data){
                            $scope.recordList = data.sub_list;
                            $ionicScrollDelegate.scrollTop();
                    }
                })
        };
        //上拉加载
        $scope.loadMore = function () {
            var scroll = $ionicScrollDelegate.getScrollPosition();
            if (scroll.top !== 0) {
                $scope.currentPage++;
                $scope.getPageDate({}).then(function (data) {
                    if (data) {
                        $scope.recordList = $scope.recordList.concat(data.sub_list);
                        console.log($scope.recordList);
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
            } else {
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }

        };
        //下拉更新
        $scope.doRefresh = function () {
            console.log($scope.select);
            $scope.currentPage = 1;
            $scope.getPageDate({}).then(function (data) {
                //if (data) {
                    $scope.recordList = data.sub_list;
                    $scope.$broadcast('scroll.refreshComplete');
                //}
            });
        };

        $scope.$ionicGoBack = function(){
            $state.go("bespeakCard");
        };
        $scope.checkBespeak = function(item){
            console.log(item);
            var params = {
                step : "3",
                orgno : item.org_no,
                orgname : item.org_name,
                address : item.address,//暂缺
                lng : item.lng,
                lat : item.lat,
                manager_name : item.manager_name,
                manager_phone : item.manager_phone,
                time : item.sub_date_time //暂缺
            };
            $state.go("bespeakSite",{params:params});
        };
        $scope.changeType($scope.select);
    }
);