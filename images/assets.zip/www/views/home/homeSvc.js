/**
 * Created by fusy on 2016/3/28.
 */
starter.factory("homeSvc",
    function (httpSvc, $http, CONSTANT) {
        return {
            //首页方案
            // homePlan : function(){
            //     return httpSvc.post("pub010603.json").then(function (data) {
            //         return data;
            //     })
            // },
            //轮播图
            getBanner: function (params) {
                return httpSvc.post("sys020403.json", params);
                /*return $http.get("data/4.2.2.json").success(function (data) {
                 console.log("banner:", JSON.stringify(data));
                 data = angular.copy(data);
                 if (data.ret_code != "0000000") return;
                 console.log(data);
                 return data;
                 });*/
            },
            //获取数据字典
            getDict: function () {
                return httpSvc.post("sys020408.json", {});
                /*return $http.get("data/4.2.2.json").success(function (data) {
                 console.log("banner:", JSON.stringify(data));
                 data = angular.copy(data);
                 if (data.ret_code != "0000000") return;
                 console.log(data);
                 return data;
                 });*/
            },
            //缓存系统参数
            getParams: function () {
                return httpSvc.post("pub010201.json", {});
                /*return $http.get("data/4.2.2.json").success(function (data) {
                 console.log("banner:", JSON.stringify(data));
                 data = angular.copy(data);
                 if (data.ret_code != "0000000") return;
                 console.log(data);
                 return data;
                 });*/
            },
            //客户设备同步
            synchronizeDevice: function (params) {
                return httpSvc.post("sys020402.json", params).then(function (data) {
                    return data;
                })
            },
            //点击签到
            signDaw: function (params) {
                return httpSvc.post("market080201.json", params).then(function (data) {
                    return data;
                })
            },
            //签到抽奖+签到活动奖品列表信息查询--进入查询
            signInfo: function (params) {
                return httpSvc.post("market080202.json", params).then(function (data) {
                    return data;
                })
            },
            /**
             * 检查抽奖有礼活动状态
             * @param $state
             * @param popupSvc
             * @returns {*} 返回活动状态查询结果{isOpen:true|false,error:''}
             */
            checkActivityStatus: function ($state, popupSvc) {
                return this.signInfo().then(function (data) {
                    var result = {
                        isOpen: true,
                        error: ""
                    };
                    console.log("activity_status:" + data.activity_status);
                    if (data && data.activity_status == "0") {
                        result.isOpen = false;
                        result.error = "活动已结束，敬请期待下次活动！";
                        if (popupSvc) {
                            popupSvc.message(result.error);
                        }
                    } else if (data && data.activity_status == '1') {
                        $state.go('dailySignIn');
                    } else {
                        //其他状态
                    }
                    return result;
                });
            },
            /**
             * 检查注册有礼活动状态
             * @param $state
             * @param popupSvc
             * @returns {*} 返回活动状态查询结果{isOpen:true|false,error:''}
             */
            checkRegisterStatus: function ($state, popupSvc) {
                return this.registAction().then(function (data) {
                    var result = {
                        isOpen: true,
                        error: ""
                    };
                    console.log("activity_status:" + data.activity_status);
                    if (data && data.activity_status == "0") {
                        result.isOpen = false;
                        result.error = "活动已结束，敬请期待下次活动！";
                        if (popupSvc) {
                            popupSvc.message(result.error);
                        }
                    } else if (data && data.activity_status == '1') {
                        $state.go('registerGift');
                    } else {
                        //其他状态
                    }
                    return result;
                });
            },
            //签到活动最近中奖用户查询--进入查询
            winList: function (params) {
                return httpSvc.post("market080205.json", params, false, true).then(function (data) {
                    return data;
                })
            },
            //抽奖
            signInGift: function (params) {
                return httpSvc.post("market080204.json", params).then(function (data) {
                    return data;
                })
            },
            //邀请好友注册活动规则查询
            inviteAction: function (params) {
                return httpSvc.post("market080101.json", params);
            },
            //邀请好友活动累计情况
            invitedNum: function (params) {
                return httpSvc.post("market080102.json", params);
            },
            //邀请记录查询—注册
            invitePerson: function (params) {
                return httpSvc.post("market080106.json", params);
            },
            //邀请记录查询—理财
            inviteFinance: function (params) {
                return httpSvc.post("market080111.json", params);
            },
            //邀请产品分享关系查询
            inviteFinancePerson: function (params) {
                return httpSvc.post("market080105.json", params);
            },
            //兑换券列表查询-用户
            voucherList: function (params) {
                return httpSvc.post("market080501.json", params);
            },
            registAction: function (params) {
                return httpSvc.post("market080203.json", params)
            },
            //预注册   z
            preRegist: function (params) {
                return httpSvc.post("market080103.json", params).then(function (data) {
                    return data;
                })
            },
            //消息
            messageInfo: function (params) {
                return httpSvc.post("msg020001.json", params).then(function (data) {
                    return data;
                });
            },
            //消息读取
            messageRead: function (params) {
                return httpSvc.post("msg020002.json", params).then(function (data) {
                })
            },
            //预约记录
            bespeakRecord: function (params) {
                return httpSvc.post("security040302.json", params);
                //return $http.get("data/bespeakRecord.json").success(function(data){
                //    return data;
                //})
            },
            //卡种类列表查询
            cardType: function (params) {
                return httpSvc.post("market080401.json", params).then(function (data) {
                    return data;
                });
                /* return $http.get("data/cardList.json").success(function (data) {
                 if (data.ret_code != "0000000") return;
                 console.log(data);
                 return data;
                 });*/
            },

            //预约办卡
            bespeakCard: function (params) {
                return httpSvc.post("security040301.json", params).then(function (data) {
                    return data;
                });
            },
            //网点经纬度查询
            webSite: function (params) {
                return httpSvc.post("pub010601.json", params);
                //return $http.get("data/pub010601.json").success(function(data){
                //    return data;
                //})
            },
            //获取短信验证码
            // phoneCode: function(params){
            //     return httpSvc.post("pub010301.json",params ).then(function (data) {
            //         return data;
            //     })
            // },
            //校验短信验证码
            // checkCode: function(params){
            //     return httpSvc.post("security040001.json",params).then(function(data){
            //         return data;
            //     })
            // },
            //理财交易记录
            tradeFinance: function (params) {
                return httpSvc.post("trans060501.json", params)
            },
            //智能存款活期交易记录
            tradeDeposit: function (params) {
                return httpSvc.post("trans060502.json", params)
            },
            //智能存款定期交易记录
            tradeDeposit2: function (params) {
                return httpSvc.post("trans060503.json", params)
            },
            //贵金属交易记录
            tradeMetal: function (params) {
                return httpSvc.post("trans060504.json", params)
            },
            //获取分享ID
            shareId: function (params) {
                return httpSvc.post("market080109.json", params)
            },
            //首页模板查询
            homeTemplateInfo: function (params) {
                return httpSvc.post("sys020410.json", params);
            },
            TEMPLATE_DEFAULT: {
                '1': [{
                    area_type: '1',
                    link_type: '1',
                    link: 'A8',
                    resource_id: 'images/home/A1_icon_01.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '预约办卡'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'A2',
                    resource_id: 'images/home/A1_icon_02.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '交易查询'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'D4',
                    resource_id: 'images/home/A1_icon_03.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '我的资产'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'B11',
                    resource_id: 'images/home/A1_icon_04.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '精选理财'
                }
                ],
                '2': [{
                    area_type: '1',
                    link_type: '1',
                    link: 'A7',
                    resource_id: 'images/home/A1_06.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '注册有礼'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'A4',
                    resource_id: 'images/home/A1_05.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '邀请有礼'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'A6',
                    resource_id: 'images/home/A1_04.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '签到抽奖'
                }],
                '3': [{
                    area_type: '1',
                    link_type: '1',
                    link: 'B11-1',
                    resource_id: 'images/home/A1_09.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '惠理财'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'B21',
                    resource_id: 'images/home/A1_12.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '智能存'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'B21',
                    resource_id: 'images/home/A1_13.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '智能存'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'A6',
                    resource_id: 'images/home/A1_14.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '签到抽奖'
                }, {
                    area_type: '1',
                    link_type: '1',
                    link: 'D451',
                    resource_id: 'images/home/A1_15.png',
                    no: '1',
                    timeStamp: 201479274923,
                    function_value: '积分兑换'
                }]
            }
        };
    });
