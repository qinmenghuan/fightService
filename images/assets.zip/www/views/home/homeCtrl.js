/**
 * Created by kayak on 16/9/18.
 */
starter.controller('homeCtrl',
    function ($scope, $timeout, $ionicScrollDelegate, popupSvc, encryptSvc,
              $state, resourceSvc, $rootScope,
              CONSTANT, CONFIG, temporarySvc,
              homeSvc,
              $cordovaDevice, $cordovaAppVersion, $ionicSlideBoxDelegate) {
        var refresh = false, head_jsessionid,
            //错误提示信息控制
            showErrorInfo = function (info) {
                $rootScope.errorMsg = info;
                $rootScope.tipShow = true;
            };
        $scope.SHOW_IMG = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=";//图片前缀
        popupSvc.loadingShow();
        //初始化模板数据
        $scope.tpInfo = homeSvc.TEMPLATE_DEFAULT;
        $scope.quickMenus = homeSvc.TEMPLATE_DEFAULT['1'];
        //页面初始化轮播图
        $scope.banners = [{imgUrl: 'images/home/A1_09.png', content_url: "", roll_id: ""},
            {imgUrl: 'images/home/A1_14.png', content_url: "", roll_id: ""},
            {imgUrl: 'images/home/A1_15.png', content_url: "", roll_id: ""}];
        $scope.transrate = 0;
        $scope.per = 100;
        $scope.index = 0;
        $scope.$on("$ionicView.afterEnter", function () {
            console.log("INFO: home start !");
            $scope.doRefresh();
        });
        var swiper2 = null;
        $timeout(function () {
            swiper2 = new Swiper('.ad-container', {
                slidesPerView: 1.5,
                initialSlide: 1, //默认显示第二个的下标
                //paginationClickable: true,
                spaceBetween: 0,
                grabCursor: true,
                ventClicksPropagation: false,
                preventClicks: false,
                centeredSlides: true,   //设置活动块居中
                observer: true,
                observeParents: true,
                simulateTouch: false  //默认为true，Swiper接受鼠标点击、拖动。
            });
        });

        $scope.doRefresh = function () {
            popupSvc.loadingHide();
            document.addEventListener("deviceready", function () {
                console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
                if (navigator.splashscreen) navigator.splashscreen.hide();
            });
            $scope.$broadcast('scroll.refreshComplete');
            //homeTemplateInfo();//请求模板数据
            //获取消息条数(只在已登录情况下)
            encryptSvc.then(function (encrypt) {
                head_jsessionid = encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID);
                if (head_jsessionid) {
                    // msg_type 为1
                    homeSvc.messageInfo({msg_type: '1'}).then(function (data) {
                    // homeSvc.messageInfo({msg_type: '2'}).then(function (data) {
                        if (data.ret_code === "0000") {
                            $scope.hasMeg = data.not_read_nm > 0 ? true : false;
                            console.log("消息获取：", data);
                            if (data.msglist.length > 0) {
                                $scope.popUp = data.msglist[0];
                                if ($scope.popUp.msg_read_flag == "1") {
                                    $scope.msgPopup = popupSvc.alert({
                                        templateUrl: "views/home/dialog/gift.html",
                                        scope: $scope,
                                        cssClass: "un-btn home-gift",
                                        buttons: [{
                                            text: '&#xe620;',
                                            type: 'button-default iconfont',
                                            onTap: function (e) {
                                                //右上角X按钮点击
                                                homeSvc.messageRead({msg_id: $scope.popUp.msg_id});
                                            }
                                        }]
                                    });
                                }

                            }

                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                }
            });
            //同步首页轮播图
            homeSvc.getBanner({roll_type: "01"}).then(function (data) {
                if (data.ret_code !== "0000") {
                    return showErrorInfo(data.ret_msg);
                }
                if (data.homecarouselist) {
                    data.homecarouselist.map(function (item) {
                        item.imgUrl = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + item.img_url
                    });
                    $scope.banners = data.homecarouselist;
                    console.log($scope.banners);
                    $timeout(function () {
                        $ionicSlideBoxDelegate.update();
                        $ionicSlideBoxDelegate.$getByHandle("bannerHandle").loop(true);
                    })
                }

            })
            if (!resourceSvc.getLocal(CONSTANT.DICT)) {
                homeSvc.getDict().then(function (data) {
                    if (data.ret_code === "0000") {
                        resourceSvc.setLocal(CONSTANT.DICT, data.data);
                    } else {
                        return showErrorInfo(data.ret_msg);
                    }
                })
            }
            if (!resourceSvc.getLocal(CONSTANT.PARAMS)) {
                homeSvc.getParams().then(function (data) {
                    if (data.ret_code === "0000") {
                        resourceSvc.setLocal(CONSTANT.PARAMS, data.parameterlist);
                    } else {
                        return showErrorInfo(data.ret_msg);
                    }
                })
            }
            if (!resourceSvc.getLocal(CONSTANT.DEVICE)) {
                //客户设备同步参数
                var deviceWidth = document.body.scrollWidth,
                    deviceHeight = document.body.scrollHeight,
                    devicePixels = window.devicePixelRatio;
                encryptSvc.then(function (encrypt) {
                    var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                    var userId = userInfo.query("user_id") || "";
                    if (userId) {
                        $scope.user_id = userId;
                        $scope.mobile = userInfo.query("mobile");
                        console.log('id', $scope.user_id);
                        console.log('mobile', $scope.mobile);
                    } else {
                        $scope.user_id = "";
                        $scope.mobile = "";
                    }
                    if (CONFIG.DEBUG_ON_CHROME) {
                        var syncParams = {
                            head_osnumber: resourceSvc.getLocal(CONSTANT.UUID),
                            user_id: $scope.user_id,
                            model: "华为",
                            mgcf: "Android",
                            app_version: "1.1.1",
                            version: "2.2.2",
                            imei: resourceSvc.getLocal(CONSTANT.UUID),
                            pixels: deviceWidth * devicePixels + "*" + deviceHeight * devicePixels + "",
                            mobile: $scope.mobile,
                            networkoperator: "02"
                        }
                    } else {
                        if ($cordovaDevice && ( ionic.Platform.isAndroid() || ionic.Platform.isIOS())) {
                            console.log($cordovaDevice);
                            syncParams = {
                                head_osnumber: resourceSvc.getLocal(CONSTANT.UUID),
                                user_id: $scope.user_id,
                                model: $cordovaDevice.getModel(),
                                mgcf: $cordovaDevice.getPlatform(),
                                app_version: $cordovaAppVersion.getVersionNumber().then(function (build) {
                                    return build;
                                }, false),
                                version: $cordovaDevice.getVersion(),
                                imei: resourceSvc.getLocal(CONSTANT.UUID),
                                pixels: deviceWidth * devicePixels + "*" + deviceHeight * devicePixels + "",
                                mobile: $scope.mobile,
                                networkoperator: "02"
                            };
                        }
                    }
                    //客户设备同步
                    homeSvc.synchronizeDevice(syncParams).then(function (data) {
                        if (data.ret_code === "0000") {
                            console.log('设备信息', data);
                            resourceSvc.setLocal(CONSTANT.DEVICE, syncParams);
                        } else {
                            return showErrorInfo(data.ret_msg);
                        }
                    });
                });
            }
        };

        /**
         * 重要消息弹框按钮点击读取消息
         */
        $scope.onMessageRead = function (popUp) {
            if ($scope.msgPopup) {
                $scope.msgPopup.close();
            }
            homeSvc.messageRead({msg_id: $scope.popUp.msg_id});
            if (popUp.special_type == "1") {
                homeSvc.messageRead({msg_id: popUp.msg_id});
                $state.go("coinCertificate");
            } else if (popUp.special_type == "0") {
                temporarySvc.set("p5", {
                    slideBox: 0,
                    prod_code: popUp.special_relationid
                });
                $state.go("inviteRecord", {params: {type: '2'}});
            }
        };
        $scope.go = function (index) {
            $ionicSlideBoxDelegate.slide(index);
        };
        $scope.go_changed = function (index) {
        };
        //离开当前页面时，销毁swiper的事件。节约内存
        $scope.$on("$destroy", function () {
            if (swiper2 && swiper2.destroy) swiper2.destroy();
        });
        $scope.imgLoadErr = function (el) {
            refresh = true;
        };
        //当滑动距离大于200px时，header背景显示
        $scope.scrollComplete = function () {
            var position = $ionicScrollDelegate.getScrollPosition().top;
            if (position <= 40) {//小于等于40像素时隐藏标题
                $scope.transrate = 0;
            } else if (position <= 200) {//大于40、小于200时显示标题栏，并设置透明度
                $scope.transrate = position / 200;
                $scope.per = 200 - position + 20;
            } else {
                $scope.transrate = 1;
                $scope.per = 20;
            }
            $scope.$apply();
        };
        //点击首页轮播图页面跳转
        $scope.goJump = function (item) {
            if (CONFIG.DEBUG_ON_CHROME == false && item.content_url) {
                cordova.ThemeableBrowser.open('http://' + item.content_url, '_blank', CONFIG.BROWSER_CONFIG);
            }
        };


        /**
         * 首页模板信息查询
         */
        $scope.homeTemplateInfo = function () {
            homeSvc.homeTemplateInfo().then(function (data) {
                console.log("首页模板数据：", data);
                $scope.tpInfo = data.apptemplateinfo;
                console.log($scope.SHOW_IMG + $scope.tpInfo['3'][0].resource_id);
            })
        };
        $scope.homeTemplateInfo();

        /**
         * 菜单项点击
         * @param menu
         */
        $scope.menuClick = function (menu) {
            // 测试热更新
            var hotpushes = new HotPush({
                src: 'http://10.5.1.131:8889/',
                versionFileName: 'version.json',
                type: HotPush.HOTPUSH_TYPE.REPLACE,
                archiveURL: 'http://10.5.1.131:8889/assets.zip'
            });

            hotpushes.loadWaitingLocalFiles()
                .then(hotpushes.check)
                .then(function (result)  {
                if (result === HotPush.UPDATE.FOUND) {
                    hotpushes.udpate().then( function () {
                        location.reload()
                    })
                    .catch(hotpushes.loadLocalFiles)
                } else {
                    hotpushes.loadLocalFiles()
                }
            }).catch(hotpushes.loadLocalFiles);
            return;

            if (menu && menu.link_type) {
                //有数据
            } else {
                return;
            }
            if (menu.link_type == '1') {
                //内部链接
                switch (menu.link) {
                    case 'A8':
                        //预约办卡
                        temporarySvc.set("p1", {pageState: '1'});
                        $state.go("bespeakCard");
                        break;
                    case 'A2':
                        //交易查询
                        $state.go('tradeQuery');
                        break;
                    case 'D4':
                        //我的资产
                        $state.go('assets');
                        break;
                    case 'B11':
                        //投资-惠理财
                        $state.go('investList', {data: {slideBox: '0'}});
                        break;
                    case 'B21':
                        //投资-智能存
                        $state.go('investList', {data: {slideBox: '1'}});
                        break;
                    case 'B31':
                        //投资-贵金属
                        $state.go('investList', {data: {slideBox: '2'}});
                        break;
                    case 'A52':
                        //理财分享
                        $state.go('financeCommend');
                        break;
                    case 'A4':
                        //邀请好友

                        encryptSvc.then(function (encrypt) {
                            if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                                $state.go('login');
                            } else {
                                $state.go('inviteRegister');
                            }
                        });

                        break;
                    case 'A6':
                        //签到抽奖

                        encryptSvc.then(function (encrypt) {
                            if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                                $state.go('login');
                            } else {
                                homeSvc.checkActivityStatus($state, popupSvc);
                            }
                        });
                        break;
                    case 'D451':
                        //积分兑换
                        $state.go('integral');
                        break;
                    case 'A7':
                        //注册有礼
                        homeSvc.checkRegisterStatus($state, popupSvc);
                        break;
                    default:
                        break;
                }
            } else if (menu.link_type == '2') {
                //外部链接，跳浏览器
                if (CONFIG.DEBUG_ON_CHROME == false) {
                    cordova.ThemeableBrowser.open(menu.link, '_blank', CONFIG.BROWSER_CONFIG);
                }
            }
        };
    });