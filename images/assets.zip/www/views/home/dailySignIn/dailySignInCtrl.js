/**
 * Created by kayak on 16/9/18.
 */
starter.controller('dailySignInCtrl',
    function ($rootScope, $scope, $state, $location, $interval, $timeout, homeSvc, popupSvc, CONFIG) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //获取当前日期
        var DailyDate = Time();
        $scope.showDate = DailyDate.getFullYear()+"年"+(DailyDate.getMonth()+1)+"月"+DailyDate.getDate()+"日";
        console.log($scope.showDate);
        //初始化签到次数
        $scope.number = 0;
        //初始化签到状态
        $scope.signed = "";
        //初始化interval
        var timer;
        //离开时，清除定时任务
        $scope.$on("$destroy", function(){
            if(timer) $interval.cancel(timer);
        });
        //获取抽奖页面抽奖次数及奖品信息，包括转盘所需要的目标索引。
        $scope.getSignInfo = function () {
            homeSvc.signInfo().then(function (data) {
                if(data.ret_code == "0000"){
                    $scope.number = data.prize_draw_times;
                    $scope.signed = data.today_sign;//是否已签到。
                    $scope.giftList = data.voucher_list;
                    for(var i=0;i<$scope.giftList.length;i++){
                        $scope.giftList[i].gift_url=CONFIG.HTTP_URL+"platform/showimg.json?resource_id="+$scope.giftList[i].voucher_pic_url;
                    }
                    //当奖品数量不足时，使用未中奖信息补充转盘
                    while($scope.giftList.length <8){
                        $scope.giftList.push({gift_url : "images/home/A11-sign-fail.png",voucher_name : "再来一次",goods_id :"1" })
                    }
                    //打乱奖品列表信息
                    $scope.giftList.sort(function () {
                        return Math.random() >0.3;
                    });

                    console.log($scope.giftList);
                    //获取未中奖信息的索引值，用于给to随机赋值
                    $scope.num = [];
                    var leng = $scope.giftList.length;
                    for(var i=0; i<leng; i++){
                        if($scope.giftList[i].goods_id == "1"){
                            $scope.num.push(i);
                        }
                    }
                    console.log($scope.num)
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //获取最近中奖用户查询
        $scope.getWin = function () {
            homeSvc.winList({activity_type : "03"}).then(function(data){
                console.log(111);
               if(data.ret_code =="0000"){
                   $scope.winList = data.win_list;
               }else{
                   showErrorInfo(data.ret_msg);
               }
            });
        };
        //抽中时弹框
        $scope.signIn = function () {
            popupSvc.alert({
                templateUrl:"views/home/dialog/signIn.html",
                scope:$scope,
                cssClass:"un-btn sign-in",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                        roundabout[form].className = "";
                        $scope.getSignInfo();
                        $scope.getWin();
                    }
                }]
            })
        };
        //未抽中时弹框
        $scope.signFail = function () {
            popupSvc.alert({
                templateUrl:"views/home/dialog/signFail.html",
                scope:$scope,
                cssClass:"un-btn sign-fail",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                        roundabout[form].className = "";
                        $scope.getSignInfo();
                        $scope.getWin();
                    }
                }]
            })
        };
        //抽奖机会已用完时弹框
        $scope.noSign = function () {
            popupSvc.alert({
                templateUrl:"views/home/dialog/signFail.html",
                scope:$scope,
                cssClass:"un-btn sign-fail",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                        roundabout[form].className = "";
                    }
                }]
            })
        };
        //完成操作时弹框提示，1S后自动消失
        $scope.tipsPopup = function (msg) {
            var signedPopup = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                signedPopup.close();
            }, 1000);
        };
        //初始化页面信息。
        $scope.getSignInfo();
        $scope.getWin();
        //中奖名单定时刷新
        timer = $interval(function () {
            $scope.getWin();
        },10000);
        //签到操作
        $scope.sign = function(){
            if($scope.signed == "1"){
                $scope.tipsPopup("已签到，请明天再试");
                return false;
            }else{
                homeSvc.signDaw().then(function (data) {
                    if(data.ret_code == "0000"){
                        $scope.tipsPopup("签到成功!");
                        $scope.number = data.prize_draw_times;
                        console.log(data);
                        $scope.signed = "1";//1为已签到，0为未签到。
                    }else{
                        showErrorInfo(data.ret_msg);
                    }
                })
            }
        };
        //点击抽奖
        var roundabout = [],
            form = 0,	//起始值
            to = 0,		//步长
            prev = 0,
            isRun = false;	//当前是否正在转盘
        var animation = new _utils.Animation({
            duration : 4000,	//动画时间
            progress : function(i){
                i = (i|0) % 8;
                roundabout[prev].className = '';
                roundabout[i].className = 'current';
                prev = i;
            },
            end : function(){
                form = (form+to) % 8;
                roundabout[prev].className = '';
                roundabout[form].className= 'current';
                isRun = false;
                $timeout(function () {
                    if($scope.draw == "1"){
                        $scope.signIn();
                    }else{
                        $scope.noStart = false;
                        $scope.signFail();
                    }
                },200);
            }
        });

        for(var i=0; i<9; i++){
            //按转盘顺序添加到列表中
            roundabout.push(document.getElementById('roundabout-index-' + i));
        }
        $scope.start = function(){
            if($scope.number < 1){
                $scope.noStart = true;
                $scope.noSign();
                return;
            }
            if(isRun) return;
            /*var data = {};
            data.draw_flag = "0";*/
            homeSvc.signInGift().then(function (data) {
                if(data.ret_code == "0000"){
                    $scope.draw = data.draw_flag;//是否中奖，1中奖，0未中奖
                    if($scope.draw == "1"){
                        for(var i=0; i<$scope.giftList.length; i++){
                            if($scope.giftList[i].goods_id == data.voucher_list[0].goods_id){
                                to = i;
                            }
                        }
                        $scope.giftInfo = data.voucher_list[0];
                        $scope.giftInfo.gift_url=CONFIG.HTTP_URL+"platform/showimg.json?resource_id="+$scope.giftInfo.voucher_pic_url;
                    }else{
                        to = $scope.num[Math.ceil(Math.random()*$scope.num.length)-1];
                        console.log(to);
                    }
                    /*
                     to这个指可能是后端传过来的，控制转盘的结果, 范围是0~7，对应转盘的顺序
                     */
                    //to = 0;		//如果要转到第5个
                    to = Math.floor(Math.random() * 4 + 3) * 8 + to - form;	// 3轮~6轮
                    //目标 = (form + to) % 7
                    animation.config({
                        form : form,
                        to : to
                    });
                    animation.start();
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });


        }

    }
);