/**
 * Created by kayak on 16/9/18.
 */
starter.controller('pub404Ctrl',
    function ($scope,homeSvc) {
        $scope.reLoad = function () {
            if(homeSvc.getBanner()) {
                $scope.$ionicGoBack();
            }
        }
    });