/**
 * Created by kayak on 16/9/18.
 */
starter.controller('messageCtrl',
    function ($scope, $rootScope,
              $state, temporarySvc,
              homeSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        // $scope.numObj={
        //     coupon_money:"50",
        //     coupon_time:"20161008",
        //     coupon_goods:"金龙鱼调和油5L装一桶"
        // };
        console.log($scope.select);
        $scope.changeType = function (flag) {
            console.log(flag);
            $scope.select = flag;
            homeSvc.messageInfo({msg_type: flag}).then(function (data) {
                if (data.ret_code == "0000") {
                    $scope.messageList = data;
                    console.log($scope.messageList.msglist);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            })
        };
        $scope.changeType('0');

        /*$scope.loadMore=function(){
         console.log("loadMore");
         };*/
        $scope.read = function (item) {
            if (item.msg_read_flag == "1") {
                homeSvc.messageRead({msg_id: item.msg_id});
            }
            $state.go("messageDetail", {params: item});
        };
        //特殊消息读取，1兑换券，跳转到兑换券列表页，0理财邀请，跳转到购买产品页，传递产品ID
        $scope.speRead = function (item) {
            if (item.msg_read_flag == "1") {
                homeSvc.messageRead({msg_id: item.msg_id});
            }
            if (item.special_type == "1") {
                $state.go("coinCertificate");
            } else if (item.special_type == "0") {
                temporarySvc.set("p5", {slideBox: 0, prod_code: item.special_relationid});
                $state.go("inviteRecord", {params: {type: '2'}});
            }
        };
    }
);