/**
 * Created by kayak on 16/9/18.
 */
starter.controller('messageDetailCtrl',
    function ($scope,
              $stateParams) {
        $scope.detailObj = $stateParams.params;
        console.log($scope.detailObj);

    }
);