/**
 * Created by kayak on 16/9/18.
 */
starter.controller('registerGiftCtrl',
    function ($scope,$rootScope,
              $state,
              $timeout,
              toolSvc,
              $q,
              homeSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.register_status = "0";
        $scope.submitDisabled = true;
        $scope.conf={};
        //获取注册有礼活动信息
        homeSvc.registAction().then(function(data){
            if(data.ret_code == "0000"){
                $scope.actionInfo = data;
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
        /*$scope.actionInfo.coupon_time = toolSvc.dateEnd($scope.actionInfo.activity_time);*/
        $scope.changeBtn = function () {
            //验证手机号是否合规
            var checkTel=toolSvc.checkTel($scope.conf.phone);
            if(checkTel){
                showErrorInfo(checkTel);
                return;
            }
            $scope.submitDisabled = false;
        };
        /*$scope.$watchGroup(["conf.phone"], function (newValue, oldValue, scope) {
            if (newValue !== oldValue) {
                if($scope.conf.phone) {
                    $scope.submitDisabled = false;
                } else {
                    $scope.submitDisabled = true;
                }
            }
        });*/
        //领取奖励  ---验证手机是否已注册
        $scope.inviteFriends = function (phone) {
            console.log($scope.actionInfo.activity_id);
            //验证手机号是否合规
            var checkTel=toolSvc.checkTel(phone);
            if(checkTel){
                showErrorInfo(checkTel);
                return;
            }
            var params ={
                invited_user_phone : phone,
                activity_id : $scope.actionInfo.activity_id,
                user_id : "",
                register_channel : "0"
            };
            homeSvc.preRegist(params).then(function (data) {
                if(data.ret_code == "0000"){
                    params = {
                        phone : phone,
                        register_status : data.register_status,
                        market_price: $scope.actionInfo.market_price,
                        voucher_name : $scope.actionInfo.voucher_name
                    };
                    $state.go("rewardRegister",{params : params})
                }else{
                    showErrorInfo(data.ret_msg);
                }

            });
        };
    }
);