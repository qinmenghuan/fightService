/**
 * Created by kayak on 16/9/18.
 */
starter.controller('rewardRegisterCtrl',
    function ($scope,
              $state,
              $location,
              temporarySvc,
              $stateParams) {
        console.log($stateParams.params);
        $scope.registerUser = $stateParams.params;

        $scope.goRegister = function (phone) {
            temporarySvc.set("p1", {login_name: phone})
            $state.go('register')
        };
    }
);