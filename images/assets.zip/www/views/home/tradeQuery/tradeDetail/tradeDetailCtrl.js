/**
 * Created by kayak on 16/9/18.
 */
starter.controller('tradeDetailCtrl',
    function ($scope, $state, $location, $stateParams, temporarySvc) {

        $scope.tradeInfo = $stateParams.params;
        console.log($scope.tradeInfo);
        var url;
        $scope.goProducts = function(){
            $state.go(url);
        };
        
        switch ($scope.tradeInfo.type){
            case "2":
                url = "financeDetail";
                temporarySvc.set("p5",{prod_code: $scope.tradeInfo.prod_code,slideBox:'0'});
                break;
            case "3":
                url = "timeDeposit";
                temporarySvc.set("p5",{prod_code: $scope.tradeInfo.prod_code,slideBox:'1'});
                break;
            case "4":
                url = "metalDetail";
                temporarySvc.set("p5",{prod_code: $scope.tradeInfo.prod_code,slideBox:'2'});
                break;
            case "5":
                url = "home";
                break;
        }
    }
);