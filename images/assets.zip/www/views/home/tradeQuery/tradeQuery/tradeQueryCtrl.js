/**
 * Created by kayak on 16/9/18.
 */
starter.controller('tradeQueryCtrl',
    function ($scope,$rootScope,
              $state,
              $location, $ionicScrollDelegate,  homeSvc, temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.selected_type = "2";
        $scope.currentPage = 1;
        $scope.limit = 10;
        $scope.tradeList = [];

        $scope.getPageDate = function (params) {
            switch ($scope.selected_type){
                case "1":
                    break;
                case "2":
                    return homeSvc.tradeFinance(angular.extend({
                        //query_begin_line: ($scope.currentPage - 1) * $scope.limit +1+ "",
                        page: $scope.currentPage + "",
                        rows: $scope.limit + ""
                    }, params)).then(function (data) {
                        if (data.ret_code === "0000") {
                            $scope.islastpage = data.islastpage; //是否最后一页  0-不是  1-是
                        }
                        return data;
                    });
                    break;
                case "3":
                    return homeSvc.tradeDeposit2(angular.extend({
                        page: $scope.currentPage + "",
                        rows: $scope.limit + ""
                    }, params)).then(function (data) {
                        if (data.ret_code === "0000") {
                            $scope.islastpage = data.islastpage;
                        }
                        return data;
                    });
                    break;
                case "4":
                    return homeSvc.tradeMetal(angular.extend({
                        page: $scope.currentPage + "",
                        rows: $scope.limit + ""
                    }, params)).then(function (data) {
                        if (data.ret_code === "0000") {
                            $scope.islastpage = data.islastpage;
                        }
                        return data;
                    });
                    break;
                case "5":
                    return homeSvc.tradeDeposit(angular.extend({
                        page: $scope.currentPage + "",
                        rows: $scope.limit + ""
                    }, params)).then(function (data) {
                        if (data.ret_code === "0000") {
                            $scope.islastpage = data.islastpage;
                        }
                        return data;
                    });
                    break;
            }
        }
        $scope.changeType=function(flag){
            $scope.selected_type = flag;
            $scope.currentPage = 1;
            $scope.tradeList = [];
           //if($scope.getPageDate({})){
               $scope.getPageDate({}).then(function (data) {
                   if (data.ret_code === "0000") {
                       $scope.tradeList = data.loglist;
                       $ionicScrollDelegate.scrollTop();
                   }else{
                       showErrorInfo(data.ret_msg);
                   }
               })
           //}
            /*$scope.getPageDate({})*/
        };
        //上拉加载
        $scope.loadMore = function () {
            var scroll = $ionicScrollDelegate.getScrollPosition();
            if (scroll.top !== 0) {
                $scope.currentPage++;
                $scope.getPageDate({}).then(function (data) {
                    if (data) {
                        $scope.tradeList = $scope.tradeList.concat(data.loglist);
                         console.log($scope.tradeList);
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
            } else {
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }

        };
        //下拉更新
        $scope.doRefresh = function () {
            console.log($scope.selected_type);
            $scope.currentPage = 1;
            $scope.getPageDate({}).then(function (data) {
                if (data) {
                    $scope.tradeList = data.loglist;
                    $scope.$broadcast('scroll.refreshComplete');
                }
            });
        };

        $scope.read = function (item){
            item.type = $scope.selected_type;
            $state.go("tradeDetail",{params:item});
        };
        $scope.changeType($scope.selected_type);
    }
);