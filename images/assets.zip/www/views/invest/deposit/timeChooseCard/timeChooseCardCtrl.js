/**
 * Created by kayak on 16/9/18.
 */
starter.controller('timeChooseCardCtrl',
    function ($scope,
              $state,
              $stateParams,
              investSvc,
              $rootScope,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        console.log($stateParams);
        var data = {
            prod_orgno: temporarySvc.get("p3").crt_orgno,
            prod_type: '1'
        };
        investSvc.depositBankCardList(data).then(function (data) {
            if (data.ret_code == '0000') {
                $scope.cardList = data.card_list;
                if ($scope.cardList.length > 0) {
                    $scope.hasCard = true;
                } else {
                    $scope.hasCard = false;
                }
            } else {
                showErrorInfo(data.ret_msg)
            }
        });


        $scope.chooseCardItem = function (item) {
            console.log(item);
            var data = {
                sub_branch_code: item.sub_branch_code,
                /*acct_no和card_no字段有可能会清除，卡号显示更换为card_no*/
                /*acct_no: item.acct_no,
                 card_no: item.card_no,*/
                card_no: item.card_no,
                bankcard_id: item.bankcard_id,
                prod_orgno: temporarySvc.get("p3").crt_orgno
            };
            temporarySvc.set('p4', data);
            $state.go('timeDepositBuy');
        };
        $scope.addCard = function () {
            var tempData = {
                title: "timeChooseCard"
            };
            temporarySvc.set('p1', tempData);
            $state.go('addBankCard2');
        }

    }
);