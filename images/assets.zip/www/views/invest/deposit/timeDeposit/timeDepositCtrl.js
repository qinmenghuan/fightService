/**
 * Created by kayak on 16/9/19.
 */
starter.controller('timeDepositCtrl',
    function ($scope,
              $state,
              $stateParams,
              $timeout,
              investSvc,
              homeSvc,
              encryptSvc,
              CONFIG,
              mineSvc,
              CONSTANT,
              popupSvc,
              tryCounter,
              shareApp,
              $rootScope, $ionicSlideBoxDelegate, $cordovaClipboard,
              temporarySvc,
              $location) {
        document.addEventListener("deviceready", function () {
            console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
            if (navigator.splashscreen) navigator.splashscreen.hide();
        });
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //提示
        var tips = function (msg) {
            var tipPop = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                tipPop.close();
            }, 1000);
        };
        //从跳转地址或路由中获取传参（产品ID\返回state\分享ID）
        var url = window.location.hash; //获取url中"?"符后的字串,分享出去的H5传回
        var url_info = url.split("?")[1] || "";
        var params = temporarySvc.get("p5") || {}; //获取列表页存储的当前产品数据
        console.log(params);
        $scope.conf = {
            record_id: ''
            , prod_code: ''
            , slideBox: ''
        };
        if (url_info) {
            var pro_params = url_info.split("&");
            var data={};
            for(var i=0;i<pro_params.length;i++){
                var tmp=pro_params[i].split("=");
                data[tmp[0]]=tmp[1];
            }
            $scope.conf.record_id = data.ret_id;
            $scope.conf.prod_code = data.pro_id;
            $scope.conf.slideBox = data.pro_code;
        } else {
            $scope.conf.record_id = params.record_id ? params.record_id : "";
            $scope.conf.prod_code = params.prod_code;
            $scope.conf.slideBox = params.slideBox;
        }
        temporarySvc.set("p5", $scope.conf);
        //初始化试算各参数
        $scope.counter = {
            time: "",
            money: "",
            level: ""
        };
        //初始化按钮状态为登录
        $scope.buyStatus = 1;
        //初始化营销数据
        $scope.activity = [];
        //初始化营销分享按钮状态
        $scope.shareBtn = false;
        //初始化分享链接\分享状态
        $scope.outUrl = "";
        //初始化分享flag,分享链接需要通过请求里的分享ID生成，如果链接未生成时，二维码弹框及社会化分享不应执行，通过flag来控制其什么时候执行
        $scope.config = {
            flagQrcode: false
            , flagQQ: false
            , flagQzone: false
            , flagWechat: false
            , rateMoney: ''//试算收益
            , rateBank: ''//银行收益
            , CounterMoneyName: '定期智能存款收益'
            , CounterBankName: '银行定期存款收益'
        };
        //初始化用户信息
        var user_info;
        encryptSvc.then(function (encrypt) {
            user_info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            console.log(user_info);
        });
        //后退返回相应slide
        //初始化智能存定期产品信息
        $scope.timeDetail = {};
        /*$scope.inviteRecordMarket = function () {
         $state.go("inviteRecordMarket", {params: {prod_code: prod_code}});
         };*/
        //获取智能存定期产品信息
        investSvc.timeDepositDetail({prod_code: $scope.conf.prod_code}).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            $scope.timeDetail = data;
            $scope.timeDetail.record_id = $scope.conf.record_id;
            console.log("timeDetail:",$scope.timeDetail);
            //console.log($scope.timeDetail.prod_lifecycle);
            //判断按钮状态
            encryptSvc.then(function (encrypt) {
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        } else {
                            $scope.buyStatus = 5; // 购买
                        }
                    })
                }
            });
            // 智能存定期活动说明：14  购买有礼15 智能存款加息16  产品分享
            //14  购买有礼
            var activityPopupGift = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/investGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            //15 智能存款加息
            var activityPopupRate = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/friendProfit.html",
                    scope: $scope,
                    cssClass: "hide-btn friend-profit",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            //16  产品分享
            var activityPopupShare = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/financeGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift finance-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            if (data.cycle_list.length > 0) {
                //获取当前营销活动信息
                $scope.activity = data.cycle_list;
                for (var i = 0; i < $scope.activity.length; i++) {
                    if ($scope.activity.activity_type == "16") {
                        $scope.shareBtn = true;
                        $scope.shareItem = item; //获取营销活动类型为16的信息
                        return;
                    }
                }
                //获取当前营销活动基本信息
                $scope.showPopup = function (act) {
                    if (!investSvc.checkActivityStatus(act, popupSvc)) {
                        return;
                    }
                    if (act.activity_type == "14") {
                        activityPopupGift();
                    }
                    if (act.activity_type == "15") {
                        activityPopupRate();
                    }
                    if (act.activity_type == "16") {
                        activityPopupShare();
                    }
                    //获取营销基本活动
                    $scope.giftBaseInfo = act;
                    //获取营销规则
                    investSvc.activityInfo({
                        activity_type: act.activity_type,
                        activity_id: act.activity_id
                    }).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.activityDetailInfo = data.prize_rule_list;
                            for (var i = 0; i < $scope.activityDetailInfo.length; i++) {
                                $scope.activityDetailInfo[i].voucher_url = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.activityDetailInfo[i].voucher_pic_url;
                            }
                            $ionicSlideBoxDelegate.update();
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });


                    if (user_info) {
                        var shareInfo = {
                            activity_id: act.activity_id,
                            activity_name: act.activity_name,
                            activity_type: act.activity_type,
                            product_id: $scope.timeDetail.prod_code,
                            product_name: $scope.timeDetail.prod_name,
                            product_type: "3",//s_product_type从列表页可传参过来
                            share_type: "3",
                            record_type: "1"  //0邀请注册，1产品分享
                        };
                        console.log(shareInfo);
                        homeSvc.shareId(shareInfo).then(function (data) {
                            if (data.ret_code == "0000") {
                                $scope.baseUrl = CONFIG.SHARE_URL + "timeDepositShare/#/timeDepositShare?" + data.record_id;
                                shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                                    $scope.outUrl = data;
                                });
                                if ($scope.config.flagQrcode == true) {
                                    $scope.showQrcode();
                                    $scope.config.flagQrcode = false;
                                }
                                if ($scope.config.flagQQ == true) {
                                    $scope.share2QQ();
                                    $scope.config.flagQQ = false;
                                }
                                if ($scope.config.flagQzone == true) {
                                    $scope.share2QZone();
                                    $scope.config.flagQzone = false;
                                }
                                if ($scope.config.flagWechat == true) {
                                    $scope.share2Wechat($scope.config.weChat);
                                    $scope.config.flagWechat = false;
                                }
                            } else {
                                showErrorInfo(data.ret_msg);
                            }
                        });
                    }
                };
            }
            //获取当前时间
            var DailyDate = Time();
            $scope.begin_time = DailyDate.getFullYear() + "." + (DailyDate.getMonth() + 1) + "." + DailyDate.getDate();
            //获取兑付时间
            //$scope.end_time = $scope.begin_time + data.inc_due;  //data.inc_due表示1年等期限，需要处理
            $scope.end_time = $scope.begin_time;
        });

        //点击弹出活动分享
        $scope.sharePopup = function (act) {
            var shareInfo = {
                activity_id: act.activity_id,
                activity_name: act.activity_name,
                activity_type: act.activity_type,
                product_id: $scope.timeDetail.prod_code,
                product_name: $scope.timeDetail.prod_name,
                product_type: "3",//s_product_type从列表页可传参过来
                share_type: "3",
                record_type: "1"  //0邀请注册，1产品分享
            };
            console.log(shareInfo);
            homeSvc.shareId(shareInfo).then(function (data) {
                if (data.ret_code == "0000") {
                    $scope.baseUrl = CONFIG.SHARE_URL + "timeDepositShare/#/timeDepositShare?" + data.record_id;
                    shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                        $scope.outUrl = data;
                    });
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };

        //点击放大二维码
        $scope.showQrcode = function () {
            $scope.share.close();
            console.log($scope.outUrl);
            if (!user_info) {
                tips("分享产品需要先登录");
                return;
            }
            if ($scope.outUrl == "") {
                $scope.config.flagQrcode = true;
                return;
            }
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //长按复制文字
        $scope.copyUrl = function () {
            $cordovaClipboard
                .copy($scope.outUrl)
                .then(function () {
                    $scope.share.close();
                    tips("复制成功");
                }, function () {
                    // error
                });
        };
        //点击购买有礼的“立即购买”按钮，关闭弹框
        $scope.btnClose = function () {
            $scope.share.close();
        };
        //分享APP
        if (!CONFIG.DEBUG_ON_CHROME) {
            $scope.share2QQ = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQQ = true;
                    return;
                }
                shareApp.share2QQ($scope.outUrl);
            };
            $scope.share2QZone = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQzone = true;
                    return;
                }
                shareApp.share2QZone($scope.outUrl);
            };
            $scope.share2Wechat = function (scene) {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.weChat = scene;
                    $scope.config.flagWechat = true;
                    return;
                }
                shareApp.share2Wechat(scene, $scope.outUrl);
            };
            $scope.share2Weibo = function () {
                shareApp.share2Weibo($scope.outUrl);
            };
        }
        //未登录时，去登录  url: 'prod_detail'?什么意思
        $scope.goLogin = function () {

            //$state.go('login', {params: {url: 'timeDeposit'}})
            $state.go('login')
        };
        //点击购买
        $scope.depositBuy = function () {
            /*var data = {
             prod_subclass: $scope.timeDetail.prod_subclass,
             prod_code: $scope.timeDetail.prod_code,
             prod_name: $scope.timeDetail.prod_name,
             crt_orgno: $scope.timeDetail.crt_orgno
             };*/

            var params = temporarySvc.get("p5") || {}; //获取列表页存储的当前产品数据
            $scope.timeDetail.activity_desc=params.activity_desc;
            temporarySvc.set("p2", $scope.timeDetail);
            $state.go("timeDepositBuy");
        }
        //试算
        $scope.popTryCounter = function () {
            popupSvc.alert({
                templateUrl: "views/invest/investDialog/tryCounter.html",
                scope: $scope,
                cssClass: "hide-btn try-counter",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                    }
                }]
            });
            $scope.counter = tryCounter.init();
            getTryscope();
        };
        var getTryscope = function (params) {
            var data = angular.extend({
                prod_code: $scope.conf.prod_code,
                znck_trlday: $scope.counter.time,
                znck_trlamt: $scope.counter.money,
                znck_cstlvl: $scope.counter.level
            }, params);
            console.log(data);
            investSvc.timeDepositCounter(data).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.config.rateMoney = data.trl_intamt;
                    $scope.config.rateBank = data.curr_intamt;

                }
            })
        };
        //加载详情页，即显示默认的10万，1年，普卡的试算结果
        getTryscope({
            znck_trlday: "365",
            znck_trlamt: "100000",
            znck_cstlvl: "1"
        });
        $scope.speedyChoose = function (type, str, $index) {
            tryCounter.speedyChoose(type, str, $index, getTryscope);
        }
    }
);