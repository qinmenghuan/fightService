/**
 * Created by kayak on 16/9/18.
 */
starter.controller('demandDepositCtrl',
    function ($scope,
              $state,
              encryptSvc,
              $rootScope,
              investSvc,
              mineSvc,
              CONSTANT,
              tryCounter,
              temporarySvc,
              popupSvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //后退返回相应slide,由我的资产进入智能存继续签约后返回页面不对，故注释掉
        //$scope.goBack = function () {
        //    $state.go('investList')
        //};
        $scope.config = {
            rateMoney: '',//试算收益
            rateBank: '',//银行收益
            CounterMoneyName: '活期智能存款收益',
            CounterBankName: '银行活期存款收益'
        };
        //初始化试算各参数
        $scope.counter = {
            time: "",
            money: "",
            level: ""
        };
        $scope.list = {
            list: {},
            checked: [],
            prod_no: '',
            prod_orgno: '',
            prod_name: '',
            check: function (val, $index) {
                for (var i = 0; i < $scope.list.checked.length; i++) {
                    $scope.list.checked[i] = false;
                }
                console.log(val);
                $scope.list.prod_no = val.product_no;
                $scope.list.prod_orgno = val.prod_orgno;
                $scope.list.prod_name = val.prod_name;
                $scope.list.checked[$index] = true;
                console.log($scope.list.prod_name);
                getTryscope({
                    znck_trlday: "365",
                    znck_trlamt: "100000",
                    znck_cstlvl: "1"
                });
            }
        };

        var data = {
            page: '1',
            rows: '10'
        };
        investSvc.demandDepositList(data).then(function (data) {
            if (data.ret_code == '0000') {
                $scope.list.list = data.prod_list;
                $scope.list.check($scope.list.list[0], 0);
                //加载详情页，即显示默认的10万，1年，普卡的试算结果
                /*getTryscope({znck_trlday:"365",
                 znck_trlamt:"100000",
                 znck_cstlvl:"1"});*/
                encryptSvc.then(function (encrypt) {
                    if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                        $scope.buyStatus = 1; //登录
                    } else {
                        mineSvc.queryAccountStatus().then(function (data) {
                            if (data.ret_code == '0000') {
                                if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                                    $scope.buyStatus = 2; //安全认证
                                } else {
                                    $scope.buyStatus = 5; // 购买                    }
                                }
                            } else {
                                showErrorInfo(data.ret_msg);
                            }
                        })
                    }
                })
            } else {
                showErrorInfo(data.ret_msg);
            }
        });

        $scope.goNext = function () {
            var data = {
                product_no: $scope.list.prod_no,
                prod_orgno: $scope.list.prod_orgno,
                prod_name: $scope.list.prod_name
            };
            console.log($scope.list.prod_name);
            temporarySvc.set("p5", data);
            $state.go('demandChooseCard')
        };
        //试算
        $scope.popTryCounter = function () {
            if (!$scope.list.prod_no) {
                showErrorInfo("请先选择需要试算的产品！");
                return;
            }
            popupSvc.alert({
                templateUrl: "views/invest/investDialog/tryCounter.html",
                scope: $scope,
                cssClass: "hide-btn try-counter",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                    }
                }]
            });
            $scope.counter = tryCounter.init();
            getTryscope();
        };
        var getTryscope = function (params) {
            var data = angular.extend({
                prod_code: $scope.list.prod_no,
                znck_trlday: $scope.counter.time,
                znck_trlamt: $scope.counter.money,
                znck_cstlvl: $scope.counter.level
            }, params);
            console.log(data);
            investSvc.demandCounter(data).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.config.rateMoney = data.trl_intamt;
                    $scope.config.rateBank = data.curr_intamt;
                } else {
                    showErrorInfo(data.ret_msg);
                }
            })
        };

        $scope.speedyChoose = function (type, str, $index) {
            tryCounter.speedyChoose(type, str, $index, getTryscope);
        }
    }
);