/**
 * Created by kayak on 2016/10/18.
 */
starter.controller('demandDepositSuccessCtrl',
    function ($scope,
              $state,
              $stateParams) {
        $scope.goAssets = function () {
            $state.go('assets', {lastUrl: "demandDepositSuccess"});
        };

        console.log($stateParams);
        $scope.detail = $stateParams.data;


        $scope.godetail = function () {
            $state.go('productDetail', {code: $scope.detail.prod_code});
        };
    });