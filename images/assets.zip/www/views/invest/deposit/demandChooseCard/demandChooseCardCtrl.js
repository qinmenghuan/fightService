/**
 * Created by kayak on 16/9/19.
 */
starter.controller('demandChooseCardCtrl',
    function ($scope,
              $state,
              $stateParams,
              $rootScope,
              keyboardSvc,
              $timeout,
              popupSvc,
              mineSvc,
              paySvc,
              investSvc,
              $ionicHistory,
              temporarySvc,
              util) {
        var swiperPromise, kid, action, encryptedInputValue;

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        var params = temporarySvc.get("p5");
        console.log("p5:", params);
        $scope.goBack = function () {
            if (params.slideBox == 1) {
                $state.go('investList')
            } else {
                $ionicHistory.goBack(-1);
            }
        };


        $scope.checked = {
            checked1: false,
            checked2: true
        };
        $scope.aa = function () {
            $scope.checked.checked2 != $scope.checked.checked2;
            console.log($scope.checked.checked2);
        }
        $scope.signDetail = {
            checked: [],
            prod_no: params.product_no,
            prod_orgno: params.prod_orgno,
            prod_name: params.prod_name,
            /*card_no: '',
             acct_no: '',
             sub_branch_code: ''*/
            bankcard_id: ''
        };
        $scope.hasCard = true;
        $scope.chooseCard = function (val, $index) {
            for (var i = 0; i < $scope.signDetail.checked.length; i++) {
                $scope.signDetail.checked[i] = false;
            }
            /*$scope.signDetail.card_no = val.card_no;
             $scope.signDetail.acct_no = val.acct_no;
             $scope.signDetail.sub_branch_code = val.sub_branch_code;*/
            $scope.signDetail.bankcard_id = val.bankcard_id;
            $scope.signDetail.checked[$index] = true;
            $scope.checked.checked1 = true;
        };
        var data = {
            prod_orgno: params.prod_orgno,
            prod_type: '0'
        };
        investSvc.depositBankCardList(data).then(function (data) {
            if (data.ret_code == '0000') {
                $scope.cardList = data.card_list;
                console.log($scope.cardList);
            } else {
                showErrorInfo(data.msg);
            }
        });


        $scope.signed = function () {
            $scope.keyboardMsg = "签约成功";
            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        if (swiper.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal();
                            }, 1000)
                        }
                    },
                    hideModalCallback: hideModalCallback
                });
            });
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };

        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            if (encryptedInputValue.errorCode == CFCA_OK) {
                $rootScope.tip = false;
                $scope.errorText = "";
                swiperPromise.then(function (swiper) {
                    swiper.slideNext();
                    var data = {
                        pwd_type: "T",
                        client_random: encryptedInputValue.encryptedClientRandom,
                        server_random: keyboardSvc.getServerRandom(),
                        new_pwd: encryptedInputValue.encryptedInputValue,
                        keyboard_type: 'C'
                    };


                    mineSvc.checkTradePwd(data).then(function (data) {
                        if (data.ret_code == '0000') {
                            $scope.data = {
                                prod_code: $scope.signDetail.prod_no,
                                product_id: $scope.signDetail.prod_no,
                                prod_name: $scope.signDetail.prod_name,
                                sign_orgno: $scope.signDetail.prod_orgno,
                                /*acct_no: $scope.signDetail.acct_no,
                                 card_no: $scope.signDetail.card_no,
                                 sub_branch_code: $scope.signDetail.sub_branch_code,*/
                                bankcard_id: $scope.signDetail.bankcard_id,
                                record_id: util.getRecordId($scope, temporarySvc),
                                activity_desc: params.activity_desc
                            };
                            console.log($scope.data);
                            investSvc.demandDepositSign($scope.data).then(function (data) {
                                if (data.ret_code == "0000") {
                                    swiper.slideNext();
                                    setTimeout(function () {
                                        $state.go("demandDepositSuccess", $scope.data);
                                    }, 1000);
                                } else {
                                    action.close();
                                    setTimeout(function () {
                                        console.log(data);
                                        angular.extend(data, {title: 'qianyue'})
                                        $state.go("buyFailed", {data: data});
                                    }, 500  );
                                }
                            })
                        } else {
                            action.close();
                            var errorPopup = popupSvc.alert({
                                title: data.ret_msg,
                                cssClass: "popup-container",
                                buttons: []
                            });
                            $timeout(function () {
                                errorPopup.close();
                            }, 2000);
                        }
                    });

                });
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码";
            }
            // encryptedInputValue = keyboardSvc.getEncrypt(id);
            // console.info("加密输入数据:", encryptedInputValue);
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

        $scope.addCard = function () {
            var tempData = {
                title: "demandChooseCard"
            };
            temporarySvc.set('p1', tempData);
            $state.go('bankCardList');
        };

        $scope.$on("$destroy", function () {
            if (action) {
                action.close();
            }
        })
    });
