/**
 * Created by kayak on 16/9/19.
 */
starter.controller('timeDepositBuyCtrl',
    function ($scope,
              $state,
              $stateParams,
              investSvc,
              temporarySvc,
              mineSvc,
              $rootScope,
              keyboardSvc,
              $timeout,
              popupSvc,
              toolSvc,
              pageJumpSvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var swiperPromise, kid, action, encryptedInputValue;

        console.log($stateParams);
        $scope.checked = {
            checked1: false,
            checked2: true,
            ifBtn: false
        };

        $scope.aa = function () {
            $scope.checked.checked2 != $scope.checked.checked2;
            console.log($scope.checked.checked2);
        };

        //获取传参，从智能存定期
        $scope.paramsTimeDeposit = temporarySvc.get("p2") || {};
        //获取传参，从卡列表页
        console.log(temporarySvc.get("p10"));
        $scope.cardInfo = temporarySvc.get("p4") || {};
        console.log($scope.paramsTimeDeposit);
        console.log($scope.cardInfo);
        if ($scope.cardInfo.card_no) {
            $scope.card_no_show = $scope.cardInfo.card_no;
            // $scope.bankCardShow = true;
        }
        console.log($scope.card_no_show);
        $scope.timeBuy = {
            prod_subclass: $scope.paramsTimeDeposit.prod_subclass,
            prod_code: $scope.paramsTimeDeposit.prod_code,
            prod_name: $scope.paramsTimeDeposit.prod_name,
            min_deposit_amt: $scope.paramsTimeDeposit.min_deposit_amt,
            step_amt: $scope.paramsTimeDeposit.step_amt,
            max_hold_amt: $scope.paramsTimeDeposit.max_hold_amt,
            crt_orgno: $scope.paramsTimeDeposit.crt_orgno || $scope.cardInfo.prod_orgno,
            cycle_list: $scope.paramsTimeDeposit.cycle_list,
            rush_list: $scope.paramsTimeDeposit.rush_list
    };

        /*console.log(temporarySvc.get('p1'));
         var aaa = temporarySvc.get('p1');*/

        for (var i = 0; i < $scope.timeBuy.cycle_list.length; i++) {
            if ($scope.timeBuy.cycle_list[i].activity_type == '14') {
                $scope.ifCycle = {
                    activity_type: $scope.timeBuy.cycle_list[i].activity_type,
                    activity_id: $scope.timeBuy.cycle_list[i].activity_id
                };
            }
        }

        $scope.goTimeChooseCard = function () {
            console.log($scope.paramsTimeDeposit.crt_orgno);
            console.log($scope.cardInfo.prod_orgno);
            temporarySvc.set("p3", {crt_orgno: $scope.paramsTimeDeposit.crt_orgno || $scope.cardInfo.prod_orgno});
            $state.go('timeChooseCard');
        };
        /*console.log(temporarySvc.get('p1'));*/
        $scope.data = {
            prod_subclass: $scope.timeBuy.prod_subclass,
            prod_name: $scope.timeBuy.prod_name,
            prod_code: $scope.timeBuy.prod_code,
            product_id:$scope.timeBuy.prod_code,
            min_deposit_amt: $scope.timeBuy.min_deposit_amt,
            step_amt: $scope.timeBuy.step_amt,
            record_id: $scope.timeBuy.record_id,
            crt_orgno: $scope.timeBuy.crt_orgno,
            /*sub_branch_code: $scope.cardInfo.sub_branch_code,
             acct_no: $scope.cardInfo.acct_no,
             card_no: $scope.cardInfo.card_no,*/
            bankcard_id: $scope.cardInfo.bankcard_id
        };


        //temporarySvc.set('p1', $scope.timeBuy);
        console.log($scope.data);


        if ($scope.checked.checked2 == true && $scope.card_no_show == true && $scope.timeBuy.account != '') {
            $scope.checked.ifBtn = true;
        }

        $scope.timeBuyBuy = function () {
            var checkMoney;
            checkMoney = toolSvc.checkMoney($scope.timeBuy.account, parseFloat($scope.timeBuy.min_deposit_amt), parseFloat($scope.timeBuy.step_amt), parseFloat($scope.timeBuy.max_hold_amt));
            if (checkMoney) {
                showErrorInfo(checkMoney);
                return;
            }
            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        if (swiper.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal();
                            }, 1000)
                        }
                    },
                    hideModalCallback: hideModalCallback
                });
            });
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };

        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            swiperPromise.then(function (swiper) {
                swiper.slideNext();
                var data = {
                    pwd_type: "T",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom(),
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: 'C'
                };

                mineSvc.checkTradePwd(data).then(function (data) {
                    if (data.ret_code == '0000') {
                        console.log($stateParams);
                        var data1 = angular.extend($scope.data, {buy_amt: $scope.timeBuy.account});
                        if ($scope.ifCycle) {
                            angular.extend(data1, $scope.ifCycle);
                        }
                        console.log(data1);

                        if ($scope.paramsTimeDeposit.market) {
                            angular.extend(data1, {
                                activity_type: $scope.timeBuy.rush_list[0].activity_type,
                                activity_id: $scope.timeBuy.rush_list[0].activity_id
                            });
                            investSvc.marketTimeDepositBuy(data1).then(function (data) {
                                if (data.ret_code == "0000") {
                                    swiper.slideNext();
                                    setTimeout(function () {
                                        var params = temporarySvc.get("p2") || {};
                                        var data = {
                                            activity_desc: params.activity_desc
                                        };
                                        $state.go("paySuccess", {data: data});
                                        pageJumpSvc.nextPageGoBack({
                                            nextState: "paySuccess",
                                            currentState: "timeDepositBuy",
                                            goBack: -2
                                        })
                                    }, 1000);
                                } else {
                                    action.close();
                                    setTimeout(function () {
                                        console.log(data);
                                        $state.go("buyFailed", data);
                                        pageJumpSvc.nextPageGoBack({
                                            nextState: "buyFailed",
                                            currentState: "timeDepositBuy",
                                            goBack: -2
                                        })
                                    }, 1000);
                                }
                            })
                        } else {
                            investSvc.timeDepositBuy(data1).then(function (data) {
                                if (data.ret_code == "0000") {
                                    swiper.slideNext();
                                    setTimeout(function () {




                                        $state.go("paySuccess");
                                        pageJumpSvc.nextPageGoBack({
                                            nextState: "paySuccess",
                                            currentState: "timeDepositBuy",
                                            goBack: -2
                                        })
                                    }, 1000);
                                } else {
                                    action.close();
                                    setTimeout(function () {
                                        console.log(data);
                                        $state.go("buyFailed", data);
                                        pageJumpSvc.nextPageGoBack({
                                            nextState: "buyFailed",
                                            currentState: "timeDepositBuy",
                                            goBack: -2
                                        })
                                    }, 1000);
                                }
                            })
                        }
                    } else {
                        action.close();
                        var errorPopup = popupSvc.alert({
                            title: data.ret_msg,
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            errorPopup.close();
                        }, 2000);

                    }
                });

            });
            // encryptedInputValue = keyboardSvc.getEncrypt(id);
            // console.info("加密输入数据:", encryptedInputValue);
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

        $scope.$on("$destroy", function () {
            if (action) {
                action.close();
            }
        })


    }
);