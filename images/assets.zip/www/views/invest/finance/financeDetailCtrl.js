/**
 * Created by kayak on 16/9/19.
 */
starter.controller('financeDetailCtrl',
    function ($scope,
              $state,
              $stateParams,
              $ionicLoading,
              $ionicPopup,
              $timeout,
              investSvc,
              homeSvc,
              popupSvc,
              CONSTANT,
              encryptSvc,
              CONFIG,
              mineSvc,
              temporarySvc,
              shareApp,
              $ionicScrollDelegate,
              $ionicSlideBoxDelegate,
              $cordovaClipboard,
              $interval,
              $rootScope,
              shortUrlSvc,
              $q,
              pdfSvc,
              $filter) {
        document.addEventListener("deviceready", function () {
            console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
            if (navigator.splashscreen) navigator.splashscreen.hide();
        });
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //提示
        var tips = function (msg) {
            var tipPop = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                tipPop.close();
            }, 1000);
        };
        //从跳转地址或路由中获取传参（产品ID和返回state）
        var url = window.location.hash; //获取url中"?"符后的字串
        var url_info = url.split("?")[1] || "";
        console.log(url_info);
        var params = temporarySvc.get("p5") || {};
        console.log(params);
        $scope.conf = {
            record_id: ''
            , prod_code: ''
            , slideBox: ''
        };
        if (url_info) {
            var pro_params = url_info.split("&");
            var data = {};
            for (var i = 0; i < pro_params.length; i++) {
                var tmp = pro_params[i].split("=");
                data[tmp[0]] = tmp[1];
            }
            $scope.conf.record_id = data.ret_id;
            $scope.conf.prod_code = data.pro_id;
            $scope.conf.slideBox = data.pro_code;
            /*$scope.conf.record_id = pro_params[1];
             $scope.conf.prod_code = pro_params[2];
             $scope.conf.slideBox = pro_params[0];*/
        } else {
            $scope.conf.record_id = params.record_id ? params.record_id : "";
            $scope.conf.prod_code = params.prod_code;
            $scope.conf.slideBox = params.slideBox;
        }
        temporarySvc.set("p5", $scope.conf);
        // var user = kkStorageService.getAesObject('user');
        // console.log(user);
        // var mineObj = kkStorageService.getAesObject('mineObj');
        //初始化用户信息
        var user_info = {};
        encryptSvc.then(function (encrypt) {
            user_info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            console.log(user_info);
        });
        $scope.isPull = false;

        console.log($stateParams.data);
        //初始化营销活动数组
        $scope.activity = [];
        //初始化营销分享按钮状态
        $scope.shareBtn = false;
        //初始化分享链接、分享状态
        $scope.outUrl = "";
        $scope.baseUrl = "";
        $scope.config = {
            flagQrcode: false,
            flagQQ: false,
            flagQzone: false,
            flagWechat: false
        };


        //上拉下拉
        console.log($scope.isPull);
        document.getElementById("content").addEventListener("touchstart", function () {
            $scope.$apply();
        });
        //上拉
        $scope.loadPull = function () {
            $timeout(function () {
                console.log($scope.isPull);
                $scope.isPull = true;
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $ionicScrollDelegate.scrollTop();
            }, 500);
        };

        //下拉返回
        $scope.backPull = function () {
            $timeout(function () {
                $scope.isPull = false;
                $scope.$broadcast('scroll.refreshComplete');
            }, 500);
        };
        console.log($scope.isPull);
        $scope.step = 0;
        //选项卡
        $scope.changeTab = function (index) {
            var a = document.getElementById('sub_header_list').getElementsByTagName('a');
            for (var i = 0; i < 4; i++) {
                a[i].className = "tab-item ";
            }
            a[index].className = "tab-item sub_button_select";
            $scope.step = index;
        };
        var data = {
            prod_code: $scope.conf.prod_code
        };
        //获取惠理财详情
        investSvc.financeDetail(data).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            $scope.item = data;
            $scope.item.record_id = $scope.conf.record_id;
            //angular.extend($scope.item, data);
            //$scope.item.is_buy 1为已买过，0为未买过
            console.log($scope.item);
            encryptSvc.then(function (encrypt) {
                console.log(encrypt.aesDeObjectL(CONSTANT.ACCOUNT_INFO));
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        }
                        else if (data.acctstep_list[2].flag == '1' && ($scope.item.prod_lifecycle == 8 ) || $scope.item.prod_lifecycle == 7) {
                            $scope.buyStatus = '3';  //已完结
                        } else if ($scope.item.prod_lifecycle == 5 || $scope.item.prod_lifecycle == 4) {
                            $scope.buyStatus = '7';  //收益中
                        } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount == 0) {
                            $scope.buyStatus = '4';  //已售罄
                        } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount != 0) {
                            $scope.buyStatus = '5'; // 购买
                        }
                    })
                }
            });


            var value_date = +new Date($filter('formatDay1')($scope.item.value_date));
            var sys_date = +new Date($filter('formatDay1')($scope.item.sys_date));
            console.log(value_date, sys_date);
            $scope.item.remain_value_date = (value_date - sys_date) / 1000 / 60 / 60 / 24;

            //剩余金额进度条
            var money_width = document.getElementsByClassName('line-main')[0].offsetWidth;
            console.log(money_width);
            $scope.item.percent_money = 1 - ( $scope.item.remain / $scope.item.total_quota);
            console.log($scope.item.percent_money);
            document.getElementById('line_move').style.width = money_width * $scope.item.percent_money + 'px';


            // 惠理财活动说明：14  购买有礼16  产品分享
            // activityPopupGift   14  购买有礼
            // activityPopupShare  16  产品分享
            var activityPopupGift = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/investGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };

            var activityPopupShare = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/financeGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift finance-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            //获取分享链接 + 获取14 购买有礼的基本信息
            /*获取当前页是否有营销活动  14 购买有礼 “买理财，享收益，赢奖品”营销活动。
             * 16  产品分享  “呼唤好友理财，赢取丰厚奖品”
             * */

            if (data.cycle_list && data.cycle_list.length > 0) {
                $scope.activity = data.cycle_list;
                console.log($scope.activity);
                $scope.activity.map(function (item) {
                    if (item.activity_type == "16") {
                        $scope.shareBtn = true;
                        $scope.shareItem = item; //获取营销活动类型为16的信息
                    }
                });
                $scope.showPopup = function (act) {
                    if (!investSvc.checkActivityStatus(act, popupSvc)) {
                        return;
                    }
                    if (act.activity_type == "14") {
                        activityPopupGift();
                    }
                    if (act.activity_type == "16") {
                        activityPopupShare();
                    }
                    //获取营销基本信息
                    $scope.giftBaseInfo = act;
                    console.log(act);
                    //获取营销规则
                    investSvc.activityInfo({
                        activity_type: act.activity_type,
                        activity_id: act.activity_id
                    }).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.activityDetailInfo = data.prize_rule_list;
                            for (var i = 0; i < $scope.activityDetailInfo.length; i++) {
                                $scope.activityDetailInfo[i].voucher_url = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.activityDetailInfo[i].voucher_pic_url;
                            }
                            $ionicSlideBoxDelegate.update();
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                    if (user_info) {
                        var shareInfo = {
                            activity_id: act.activity_id,
                            activity_name: act.activity_name,
                            activity_type: act.activity_type,
                            product_id: $scope.item.prod_code,
                            product_name: $scope.item.prod_name,
                            product_type: "1",//s_product_type从列表页可传参过来
                            share_type: "2",
                            record_type: "1"  //0邀请注册，1产品分享
                        };
                        console.log(shareInfo);
                        homeSvc.shareId(shareInfo).then(function (data) {
                            if (data.ret_code == "0000") {
                                $scope.baseUrl = CONFIG.SHARE_URL + "financeShare/#/financeShare?" + data.record_id;
                                shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                                    $scope.outUrl = data;
                                });
                                if ($scope.config.flagQrcode == true) {
                                    $scope.showQrcode();
                                    $scope.config.flagQrcode = false;
                                }
                                if ($scope.config.flagQQ == true) {
                                    $scope.share2QQ();
                                    $scope.config.flagQQ = false;
                                }
                                if ($scope.config.flagQzone == true) {
                                    $scope.share2QZone();
                                    $scope.config.flagQzone = false;
                                }
                                if ($scope.config.flagWechat == true) {
                                    $scope.share2Wechat($scope.config.weChat);
                                    $scope.config.flagWechat = false;
                                }
                            } else {
                                showErrorInfo(data.ret_msg);
                            }
                        });
                    }

                };

            }
        });
        $scope.goLogin = function () {
            //$state.go('login', {params: {url: 'finance'}})
            $state.go('login')
        };
        $scope.accountSafe = function () {
            //$state.go('accountSafe', {params: {url: 'finance'}})
            $state.go('accountSafe')
        };
        $scope.goBuy = function () {
            mineSvc.queryRiskLv().then(function (data) {
                if ($scope.item.risk_level > data.risk_level) {
                    $state.go("buyFailed", data);
                } else {
                    temporarySvc.set("p2", $scope.item);
                    $state.go('buy');
                }
            })

        };
        //点击上滑出活动分享
        $scope.sharePopup = function (act) {

            if (user_info) {
                var shareInfo = {
                    activity_id: act.activity_id,
                    activity_name: act.activity_name,
                    activity_type: act.activity_type,
                    product_id: $scope.item.prod_code,
                    product_name: $scope.item.prod_name,
                    product_type: "1",//s_product_type从列表页可传参过来
                    share_type: "2",
                    record_type: "1"  //0邀请注册，1产品分享
                };
                console.log(shareInfo);
                homeSvc.shareId(shareInfo).then(function (data) {
                    if (data.ret_code == "0000") {
                        $scope.baseUrl = CONFIG.SHARE_URL + "financeShare/#/financeShare?" + data.record_id;
                        shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                            $scope.outUrl = data;
                        });
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            }

            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };
        //点击放大二维码
        $scope.showQrcode = function () {
            $scope.share.close();
            console.log($scope.outUrl);
            if (!user_info) {
                tips("分享产品需要先登录");
                return;
            }
            if ($scope.outUrl == "") {
                $scope.config.flagQrcode = true;
                return;
            }
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //长按复制文字
        $scope.copyUrl = function () {
            $cordovaClipboard
                .copy($scope.outUrl)
                .then(function () {
                    $scope.share.close();
                    tips("复制成功");
                }, function () {
                    // error
                });
        };
        //点击购买有礼的“立即购买”按钮，关闭弹框
        $scope.btnClose = function () {
            $scope.share.close();
        };

        //begin 社会化分享
        //分享APP
        if (!CONFIG.DEBUG_ON_CHROME) {
            $scope.share2QQ = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQQ = true;
                    return;
                }
                shareApp.share2QQ($scope.outUrl);
            };
            $scope.share2QZone = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQzone = true;
                    return;
                }
                shareApp.share2QZone($scope.outUrl);
            };
            $scope.share2Wechat = function (scene) {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.weChat = scene;
                    $scope.config.flagWechat = true;
                    return;
                }
                shareApp.share2Wechat(scene, $scope.outUrl);
            };
            $scope.share2Weibo = function () {
                shareApp.share2Weibo($scope.outUrl);
            };
        }

        //查看pdf文档
        var address, title;
        if (!CONFIG.DEBUG_ON_CHROME) {
            document.addEventListener("deviceready", function () {
                $scope.downPdf = function (val) {
                    if (val == 0) {
                        address = $scope.item.prod_txt_inter_path;
                        title = "购买说明";
                    } else if (val == 1) {
                        address = $scope.item.prod_txt_exp_path;
                        title = "产品说明书";
                    } else if (val == 2) {
                        address = $scope.item.prod_txt_risk_path;
                        title = "风险提示";
                    }
                    var url = CONFIG.HTTP_URL + 'platform/downloadfile?resource_id=' + address;
                    console.log(url);
                    // window.open(url, '_blank', 'location=yes');
                    // var ref = cordova.InAppBrowser.open(url, '_blank', 'location=no');
                    //$rootScope.jumpOut(url, title);
                    pdfSvc.readPDF(url, title);
                }

            }, false)
        }
    }
);