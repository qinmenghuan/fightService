/**
 * Created by kayak on 2016/10/27.
 */
starter.controller('financeFilterCtrl',
    function ($scope,
              $state,
              temporarySvc,
              resourceSvc) {

        $scope.goBack = function () {
            $state.go("investList");
        };
        var dict = resourceSvc.getLocalObj('dict') || '';

        $scope.financeFilter = {
            prod_days_list: [],
            min_subs_p_list: [],
            income_type_list: []
        };
        var blank_all = {
            itemval: '全部',
            itemkey: ''
        };
        dict.forEach(function (e) {
            if (e.dict == 'prod_days') {
                $scope.financeFilter.prod_days_list.push(e);
            }
        });


        dict.forEach(function (e) {
            if (e.dict == 'min_subs_p') {
                $scope.financeFilter.min_subs_p_list.push(e);
            }
        });
        dict.forEach(function (e) {
            if (e.dict == 'income_type') {
                $scope.financeFilter.income_type_list.push(e);
            }
        });
        $scope.financeFilter.prod_days_list.unshift(blank_all);
        $scope.financeFilter.min_subs_p_list.unshift(blank_all);
        $scope.financeFilter.income_type_list.unshift(blank_all);
        console.log($scope.financeFilter);

        $scope.emptyAll = function () {
            $scope.idxArr = [0, 0, 0];
        };

        // 根据缓存默认选中情况赋值
        if (resourceSvc.getLocalObj('prodFilter') == {}) {
            console.log(resourceSvc.getLocalObj('prodFilter'));
            $scope.idxArr = resourceSvc.getLocalObj('prodFilter');
        } else {
            $scope.idxArr = [0, 0, 0];
        }


        $scope.checkLimit = function (idx) {
            $scope.idxArr[0] = idx;
            console.log(idx);
        };

        $scope.checkMoney = function (idx) {
            $scope.idxArr[1] = idx;
            console.log(idx);

        };

        $scope.checkType = function (idx) {
            $scope.idxArr[2] = idx;
            console.log(idx);

        };

        $scope.filterList = function () {
            var data = {
                prod_days: $scope.financeFilter.prod_days_list[$scope.idxArr[0]].itemkey,
                min_subs_p: $scope.financeFilter.min_subs_p_list[$scope.idxArr[1]].itemkey,
                income_type: $scope.financeFilter.income_type_list[$scope.idxArr[2]].itemkey
            };
            console.log(data);
            resourceSvc.setLocal('prodFilter', $scope.idxArr);
            temporarySvc.set('p1', data);
            $state.go('investList');
        };
    })