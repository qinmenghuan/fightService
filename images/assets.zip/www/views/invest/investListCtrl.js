/**
 * Created by kayak on 16/9/18.
 */
starter.controller('investListCtrl',
    function ($scope,
              $timeout,
              $state,
              $stateParams,
              $ionicSlideBoxDelegate,
              $ionicScrollDelegate,
              investSvc,
              $filter,
              CONSTANT,
              $document,
              encryptSvc,
              mineSvc,
              $q,
              temporarySvc,
              homeSvc,
              CONFIG,
              $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.invest = {
            slide: '',
            slideIndex: '',
            slideHeight: '',
            financeList: [],
            metalList: [],
            timeDepositList: [],
            demandDepositDetail: [],
            searchFinanceName: '',
            getFinanceList: function (name) {
                var defer = $q.defer();
                var financeFilter = temporarySvc.get('p1');
                var data = {
                    page: '',
                    rows: ''
                };
                if (name) {
                    data.prod_name = name || '';
                    financeFilter = {};
                } else if (financeFilter && financeFilter.prod_days != undefined && !name) {
                    console.log(financeFilter);
                    angular.extend(data, financeFilter);
                }
                investSvc.financeList(data).then(function (data) {
                    if (data.ret_code == '0000') {
                        $scope.invest.financeList = data.prod_list;
                        defer.resolve($scope.invest.financeList)
                    } else {
                        showErrorInfo(data.ret_msg);
                        defer.reject(data.ret_msg)
                    }
                });
                return defer.promise;
            },
            getMetalList: function (name) {
                console.log(name);
                var metalFilter = temporarySvc.get('p2');
                console.log(metalFilter);
                var data = {
                    page: '',
                    rows: ''
                };
                if (name) {
                    data.prod_name = name || '';
                    metalFilter = {};
                } else if (metalFilter && metalFilter.company_supplier_list != undefined && !name) {
                    angular.extend(data, metalFilter);
                }
                return investSvc.metalList(data).then(function (data) {
                    if (data.ret_code == '0000') {
                        $scope.invest.metalList = data.prod_list;
                    }
                    else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            },
            // getTimeDepositList: function (obj) {
            //     investSvc.timeDepositList(obj).then(function (data) {
            //         if (data.ret_code == '0000') {
            //             $scope.invest.changeHeightDeposit++;
            //             $scope.invest.timeDepositList = data.prod_list;
            //         } else {
            //             showErrorInfo(data.ret_msg);
            //         }
            //     });
            // },
            // getDemandDepositDetail: function (obj) {
            //     investSvc.demandDepositList(obj).then(function (data) {
            //         if (data.ret_code == '0000') {
            //             $scope.invest.changeHeightDeposit++;
            //             $scope.invest.demandDepositAccount = data.acount;
            //             $scope.invest.demandDepositDetail = data.prod_list[0];
            //         } else {
            //             showErrorInfo(data.ret_msg);
            //         }
            //     });
            // }
        };


        // $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        //     if ($scope.slideIndex == 0) {
        //         console.log(document.getElementById('finance').offsetHeight);
        //         $scope.invest.slideHeight = document.getElementById('finance').offsetHeight + 'px';
        //
        //     } else if ($scope.slideIndex == 1) {
        //         console.log(document.getElementById('deposit').offsetHeight);
        //         $scope.invest.slideHeight = document.getElementById('deposit').offsetHeight + 'px';
        //
        //     } else if ($scope.slideIndex == 2) {
        //         console.log(document.getElementById('metal').offsetHeight);
        //         $scope.invest.slideHeight = document.getElementById('metal').offsetHeight + 'px';
        //
        //     }
        //
        //
        //     // console.log(document.getElementById('finance').offsetHeight);
        //     // console.log($scope.slideIndex);
        // });

        console.log(temporarySvc.get('p5'));
        if (temporarySvc.get('p5') && temporarySvc.get('p5').slideBox) {
            $scope.slideIndex = temporarySvc.get('p5').slideBox
        } else {
            if ($stateParams.data.slideBox) {
                $scope.slideIndex = $stateParams.data.slideBox;
            } else {
                $scope.slideIndex = $scope.invest.slide ? $scope.invest.slide : "0"
            }
        }


        $scope.getHeight = function () {
            // if (this.$first) {
            //     var line_height = document.getElementsByClassName('product-item')[0].offsetHeight;
            var line_height = $('.product-item').eq(0).height();
            for (var i = 0; i < $scope.invest.financeList.length; i++) {
                $scope.invest.financeList[i].line_height = (1 - $scope.invest.financeList[i].per_amount ) * line_height + 'px';
            }
            // }
        };
        //$scope.slideIndex = $stateParams.data.slideBox ? $stateParams.data.slideBox : "0";
        // console.log(document.querySelector('product-item'));

        $scope.slidesChanged = function (index) {
            $ionicScrollDelegate.scrollTop();
            getBanners(index);//获取轮播图
            // $scope.invest.slideHeight = '800' + 'px';
            console.log(index);
            if (index == 0) {
                $scope.invest.slide = 0;
                $scope.slideIndex = 0;
                console.log('slide 0');

                $q.when($scope.invest.getFinanceList())
                    .then(function (data) {
                        $scope.getHeight()
                    });


            } else if (index == 1) {
                $scope.invest.slide = 1;
                $scope.slideIndex = 1;
                $scope.invest.searchFinanceName = ''; //清除理财产品查询记录
                console.log('slide 1');
                var data = {
                    page: '1',
                    rows: '1'
                };
                var data2 = {
                    page: '',
                    rows: ''
                };
                $q.all([investSvc.timeDepositList(), investSvc.demandDepositList()]).then(function (args) {
                    console.log("args:", args);
                    if (args[0].ret_code == '0000') {
                        $scope.invest.changeHeightDeposit++;
                        $scope.invest.timeDepositList = args[0].prod_list;
                    } else {
                        showErrorInfo(args[0].ret_msg);
                    }
                    if (args[1].ret_code == '0000') {
                        $scope.invest.changeHeightDeposit++;
                        $scope.invest.demandDepositAccount = args[1].acount;
                        $scope.invest.demandDepositDetail = args[1].prod_list[0];
                    } else {
                        showErrorInfo(args[1].ret_msg);
                    }
                });


            } else if (index == 2) {
                $scope.invest.slide = 2;
                $scope.slideIndex = 2;
                $scope.invest.searchFinanceName = ''; //清除理财产品查询记录

                console.log('slide 2');
                $scope.metal.sort(1);// 初始化贵金属排序销量
                $q.all($scope.invest.getMetalList()).then(function () {
                    if (document.getElementById('slide')) {
                        var height = document.getElementById('metal').offsetHeight;
                        console.log(document.getElementById('metal').offsetHeight);
                        console.warn('警告');
                        // $scope.invest.slideHeight = height + 'px';
                    }
                });

            }
        };
        $scope.aaa = true;
        $scope.metal = {
            current: '1',
            sort: function (val) {
                if ($scope.slideIndex == 2) {
                    $scope.metal.current = val;
                    if (val == 1) {
                        console.log($scope.test);
                        $scope.metalOrder = '-prod_sales';
                        $scope.test = 1;
                        // $scope.metalOrder2 = false;
                    } else if (val == 2) {
                        console.log($scope.test);
                        $scope.metalOrder = '-upd_datetime';
                        $scope.test = 2;
                        // $scope.metalOrder2 = false;
                    } else if (val == 3) {
                        console.log($scope.test);
                        if ($scope.test != 3) {
                            $scope.metalOrder = 'fixed_price';
                        }
                        else if ($scope.test == 3) {
                            if ($scope.aaa) {
                                $scope.metalOrder = '-fixed_price';
                            } else {
                                $scope.metalOrder = 'fixed_price';
                            }
                            $scope.aaa = !$scope.aaa;
                        }
                        $scope.test = 3;
                    }
                }
            }
        };


        $scope.activeSlide = function (index) {
            $ionicSlideBoxDelegate.slide(index);
            $ionicScrollDelegate.scrollTop();
            //$scope.slidesChanged(index);
        };
        $scope.slidesChanged($scope.slideIndex);


        // for (i = 0; i < $scope.productList.length; i++) {
        //     $scope.productList[i].array = new Array($scope.productList[i].hot);
        // }
        //
        // $scope.doRefresh = function () {
        //     $timeout(function () {
        //         $scope.productList.push($scope.productList[0]);
        //         $scope.$broadcast('scroll.refreshComplete');
        //     }, 1000);
        // }

        //finance惠理财营销分三种：抢购（限时、限量），分享有礼，购买有礼
        $scope.goFinanceDetail = function (item) {
            console.log(item);
            var data4 = {
                prod_code: item.prod_code,
                slideBox: 0
            };
            temporarySvc.set("p5", data4);
            if (item.activity_list.length > 0) {
                for (var i = 0; i < item.activity_list.length; i++) {
                    console.log(item.activity_list[i]);
                    if (item.activity_list[i].activity_type == "13") {
                        $state.go('marketFinanceDetail');
                        break;
                    } else {
                        $state.go('financeDetail');
                    }
                }
            } else {
                $state.go('financeDetail');
            }

        };
        //deposit智能存活期 无营销活动
        $scope.goDemandDeposit = function () {
            var data = {
                slideBox: 1
            };
            temporarySvc.set("p5", data);
            $state.go('demandDeposit')
        };
        //deposit智能存定期营销分四种：抢购（限时、限量），分享有礼，购买有礼，加息
        $scope.goTimeDeposit = function (item) {
            var activity_desc = "";
            var activitylist = item.activity_list;
            var length = activitylist.length;
            if (length) {
                for (var i = 0; i < length; i++) {
                    if (activitylist[i].activity_type == "14") {
                        activity_desc = activitylist[i].activity_desc;
                    }
                }
            }

            var data = {
                prod_code: item.prod_code,
                slideBox: 1,
                activity_desc: activity_desc
            };
            temporarySvc.set("p5", data);
            if (item.activity_list.length > 0) {
                for (var i = 0; i < item.activity_list.length; i++) {
                    console.log(item.activity_list[i]);
                    if (item.activity_list[i].activity_type == "13") {
                        $state.go('marketTimeDeposit');
                        break;
                    } else {
                        $state.go('timeDeposit');
                    }
                }
            } else {
                $state.go('timeDeposit')
            }
        };


        $scope.goSign = function () {
            encryptSvc.then(function (encrypt) {
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $state.go('login');
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $state.go('accountSafe');
                        } else {
                            console.log("demandDepositDetail:", $scope.invest.demandDepositDetail);
                            var activity_desc = "";
                            var activitylist = $scope.invest.demandDepositDetail.activity_list;
                            var length = activitylist.length;
                            if (length) {
                                for (var i = 0; i < length; i++) {
                                    if (activitylist[i].activity_type == "14") {
                                        activity_desc = activitylist[i].activity_desc;
                                    }
                                }
                            }

                            var data = {
                                product_no: $scope.invest.demandDepositDetail.product_no,
                                prod_orgno: $scope.invest.demandDepositDetail.prod_orgno,
                                prod_name: $scope.invest.demandDepositDetail.prod_name,
                                slideBox: 1,
                                activity_desc: activity_desc
                            };
                            temporarySvc.set("p5", data);
                            $state.go('demandChooseCard')
                        }
                    })
                }
            });
        };

        //metal
        $scope.goMetalDetail = function (item) {
            var data8 = {
                prod_code: item.prod_sub_id,
                slideBox: 2
            };
            temporarySvc.set("p5", data8);
            if (item.activity_list.length > 0) {
                for (var i = 0; i < item.activity_list.length; i++) {
                    console.log(item.activity_list[i]);
                    if (item.activity_list[i].activity_type == "13") {
                        $state.go('marketMetalDetail');
                        break;
                    } else {
                        $state.go('metalDetail');
                    }
                }
            } else {
                $state.go('metalDetail')
            }

        };


        //android 输入框获取焦点时隐藏下方导航栏
        window.addEventListener('native.keyboardshow', function () {
            document.body.classList.add('keyboard-open');
        });


        $scope.banners = [];

        /**
         * 获取轮播图图片
         */
        function getBanners(index) {
            var rollType = '02';
            switch (index) {
                case 0:
                    rollType = "02";
                    break;
                case 1:
                    rollType = "03";
                    break;
                case 2:
                    rollType = "04";
                    break;
            }
            homeSvc.getBanner({roll_type: rollType}).then(function (data) {
                console.log("获取轮播图", data);
                if (data.ret_code !== "0000") {
                    return showErrorInfo(data.ret_msg);
                }
                if (data.homecarouselist) {
                    data.homecarouselist.map(function (item) {
                        item.imgUrl = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + item.img_url
                    });
                    $scope['banners' + index] = data.homecarouselist;
                }
            });
        }

    });
