/**
 * Created by kayak on 2016/10/6.
 */
starter.factory("investSvc", function ($http, httpSvc, CONFIG) {
    return {

        //理财产品列表
        financeList: function (params) {
            return httpSvc.post("prod050103.json", params).then(function (data) {
                return data;
            });
        },
        //存款活期列表
        demandDepositList: function (params) {
            return httpSvc.post("prod050204.json", params).then(function (data) {
                return data;
            });
        },
        //存款定期列表
        timeDepositList: function (params) {
            return httpSvc.post("prod050202.json", params).then(function (data) {
                return data;
            });
        },
        //贵金属列表
        metalList: function (params) {
            return httpSvc.post("prod050301.json", params).then(function (data) {
                return data;
            });
        },
        //理财产品详情
        financeDetail: function (params) {
            return httpSvc.post("prod050104.json", params).then(function (data) {
                return data;
            });
        },
        //贵金属详情
        metalDetail: function (params) {
            return httpSvc.post("prod050302.json", params).then(function (data) {
                return data;
            });
        },
        //智能存款可签约银行卡列表
        depositBankCardList: function (params) {
            return httpSvc.post("bank040507.json", params).then(function (data) {
                return data;
            })
        },
        //智能存款活期签约
        demandDepositSign: function (params) {
            return httpSvc.post("trans060201.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //智能存款定期详情
        timeDepositDetail: function (params) {
            return httpSvc.post("prod050203.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //智能存款定期购买
        timeDepositBuy: function (params) {
            return httpSvc.post("trans060204.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //智能存款定期抢购
        marketTimeDepositBuy: function (params) {
            return httpSvc.post("trans060209.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //贵金属购买
        metalBuy: function (params) {
            return httpSvc.post("trans060301.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //贵金属抢购
        marketMetalBuy: function (params) {
            return httpSvc.post("trans060309.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //邀请产品分享关系查询
        investRecord: function (params) {
            return httpSvc.post("market080105.json", params);
        },
        //营销活动规则查询
        activityInfo: function (params) {
            return httpSvc.post("market080302.json", params);
        },
        //智能存款活期收益试算
        demandCounter: function (params) {
            return httpSvc.post("trans060206.json", params);
        },
        //智能存款定期收益试算
        timeDepositCounter: function (params) {
            return httpSvc.post("trans060207.json", params);
        },
        /**
         * 检查活动状态
         * @param activity 活动数据
         * @returns {boolean} 是否进行中
         */
        checkActivityStatus: function (activity, popupSvc) {
            if (activity && activity.activity_status && activity.time_stat) {
                switch (activity.activity_status) {
                    case '2':
                    //进行中
                    case '1': {
                        //已发布
                        switch (activity.time_stat) {
                            case '1':
                                //未开始
                                showError('活动未开始');
                                break;
                            case '2':
                                //已结束
                                showError('活动已结束');
                                break;
                            case '3':
                                //已开始
                                return true;
                        }
                        break;
                    }
                    case '3':
                        //已结束
                        showError('活动已结束');
                        break;
                    case '0':
                        //已暂停
                        showError('活动已暂停');
                        break;
                }
            } else {
                //数据异常
            }
            /**
             * 显示错误提示
             * @param error
             */
            function showError(error) {
                popupSvc.error(error);
            }

            return false;
        }
    }
});
