/**
 * Created by kayak on 16/9/19.
 */
starter.controller('metalBuyCtrl',
    function ($scope,
              $state,
              investSvc,
              keyboardSvc,
              $timeout,
              popupSvc,
              mineSvc,
              paySvc,
              encryptSvc,
              CONSTANT,
              temporarySvc,
              $rootScope,
              $ionicHistory,
              pageJumpSvc,
              $stateParams) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        $scope.goBack = function () {
            console.log($ionicHistory);
            $ionicHistory.goBack(-1);
        }
        var swiperPromise, kid, action, openDetail, openChangeCard, encryptedInputValue;
        var paramsMetal = temporarySvc.get("p2");
        console.log(paramsMetal);
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            $scope.user_name = userInfo.query("user_name");
            console.log($scope.user_name);
            $scope.buyDetail.invoice = $scope.buyDetail.invoice_type == '0' ? $scope.user_name : '';
        });
        $scope.buyDetail = {
            prod_sub_id: paramsMetal.prod_sub_id,
            product_id: paramsMetal.prod_sub_id,
            buy_sum: paramsMetal.number + '',
            nowPrice: paramsMetal.nowPrice,
            buy_amt: paramsMetal.number * paramsMetal.nowPrice + '',
            prod_name: paramsMetal.prod_name,
            record_id: paramsMetal.record_id,
            delivery: '',
            invoice_flag: '2',
            invoice_type: '0',
            invoice: '',
            orgname: paramsMetal.orgname || '',
            // org_no: paramsMetal.orgno || '',
            org_no: '000002',
            address: paramsMetal.address || '',
            tel: "",
            lng: paramsMetal.lng || '',
            lat: paramsMetal.lat || '',
            give_mode: '1'
        };
        if (paramsMetal.cycle_lis && paramsMetal.cycle_list.length > 0) {
            for (var i = 0; i < paramsMetal.cycle_list.length; i++) {
                if (paramsMetal.cycle_list[i].activity_type == '14') {
                    $scope.buyDetail.activity_type = paramsMetal.cycle_list[i].activity_type;
                    $scope.buyDetail.activity_id = paramsMetal.cycle_list[i].activity_id;
                }
            }
        }
        if (paramsMetal.rush_list && paramsMetal.rush_list.length > 0) {
            $scope.buyDetail.activity_type = paramsMetal.rush_list[0].activity_type;
            $scope.buyDetail.activity_id = paramsMetal.rush_list[0].activity_id;
        }
        console.log($scope.buyDetail);
        $scope.buyDetail.delivery = true;
        console.log($scope.buyDetail.delivery);

        /*var aaa = temporarySvc.get('p1');
         if (temporarySvc.get('p1').cycle_list) {
         for (var i = 0; i < aaa.cycle_list.length; i++) {
         if (aaa.cycle_list[i].activity_type == '14') {
         $scope.ifCycle = {
         activity_type: aaa.cycle_list[i].activity_type,
         activity_id: aaa.cycle_list[i].activity_id
         };
         }
         }
         }
         if(temporarySvc.get('p1').rush_list){
         if(aaa.rush_list.length>0){
         $scope.ifCycle = {
         activity_type: aaa.cycle_list[0].activity_type,
         activity_id: aaa.cycle_list[0].activity_id
         };
         }
         }
         console.log($scope.ifCycle);*/
        //  获取提货地址


        $scope.data = {
            prod_sub_id: $scope.buyDetail.prod_sub_id,
            buy_sum: $scope.buyDetail.buy_sum,
            nowPrice: $scope.buyDetail.nowPrice,
            buy_amt: $scope.buyDetail.buy_amt,
            prod_name: $scope.buyDetail.prod_name,
            activity_type: $scope.buyDetail.activity_type,
            activity_id: $scope.buyDetail.activity_id,
        };


        /*temporarySvc.set('p1', $scope.buyDetail);*/


        /*mineSvc.queryBankCardList().then(function (data) {
         if (data.ret_code == '0000') {
         $scope.cardList = data.acct_list;
         $scope.buy.acct_no = data.acct_list[0].acct_no;
         $scope.buy.card_no = data.acct_list[0].card_no;
         }
         });*/
        /*贵金属购买银行卡的查询，更换为接口040507，详见接口文档*/
        investSvc.depositBankCardList({prod_orgno: "", prod_type: "3"}).then(function (data) {
            if (data.ret_code == '0000') {
                $scope.cardList = data.card_list;
                $scope.buy.card_no = $scope.cardList[0].card_no;
                $scope.buy.bankcard_id = $scope.cardList[0].bankcard_id;
                console.log($scope.cardList);
                console.log($scope.buy.bankcard_id)
            } else {
                showErrorInfo(data.ret_msg);
            }
        });

        $scope.filterList = function (list) {
            var result = {};
            angular.forEach(list, function (value, key) {
                if (value.invest_status != '2') {
                    result[key] = value;
                }
            });
            console.log(result);
            return result;
        };

        $scope.chooseCard = function (obj) {
            /*$scope.buy.acct_no = obj.acct_no;
             $scope.buy.card_no = obj.card_no;*/
            /*贵金属购买修改接口，要求上送字段变为bankcard_id*/
            $scope.buy.bankcard_id = $scope.cardList[0].bankcard_id;
            openChangeCard.close();
        };

        $scope.buy = {
            payDetail: function () {
                console.log($scope.buyDetail);
                if (($scope.buyDetail.invoice_flag == '1') && (!$scope.buyDetail.invoice)) {
                    showErrorInfo("请输入发票抬头");
                    return;
                }
                openDetail = popupSvc.action({
                    templateUrl: "views/pay/buy/payDetail.html",
                    scope: $scope
                })
            },
            closePayDetail: function () {
                openDetail.close();
            },
            changeCard: function () {
                openChangeCard = popupSvc.action({
                    templateUrl: "views/pay/buy/changeCard.html",
                    scope: $scope
                })
            },
            closeChangeCard: function () {
                openChangeCard.close();
            }
        };
        $scope.buybuy = function () {

            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        if (swiper.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal();
                            }, 1000)
                        }
                    },
                    hideModalCallback: hideModalCallback
                });
            });
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };

        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            if (encryptedInputValue.errorCode == CFCA_OK) {
                $rootScope.tip = false;
                $scope.errorText = "";
                swiperPromise.then(function (swiper) {
                    swiper.slideNext();
                    var data = {
                        pwd_type: "T",
                        client_random: encryptedInputValue.encryptedClientRandom,
                        server_random: keyboardSvc.getServerRandom(),
                        new_pwd: encryptedInputValue.encryptedInputValue,
                        keyboard_type: 'C'
                    };


                    mineSvc.checkTradePwd(data, false, true).then(function (data) {
                        if (data.ret_code == '0000') {
                            var data1 = {
                                /*acct_no: $scope.buy.acct_no,
                                 card_no: $scope.buy.card_no*/
                                bankcard_id: $scope.buy.bankcard_id
                            };
                            //angular.extend(data1, $scope.buyDetail);

                            angular.extend(data1, $scope.buyDetail);
                            console.log(data1);
                            /*if ($scope.ifCycle) {
                             angular.extend(data1, $scope.ifCycle);
                             }
                             console.log(data1);*/
                            if (paramsMetal.market) {
                                investSvc.marketMetalBuy(data1, false, true).then(function (data) {
                                    if (data.ret_code == "0000") {
                                        openDetail.close();
                                        swiper.slideNext();
                                        setTimeout(function () {
                                            action.close();
                                            $state.go("paySuccess", {data: $scope.buyDetail});

                                        }, 1000);
                                    } else {
                                        openDetail.close();
                                        $state.go("buyFailed", data);
                                    }
                                })
                            } else {
                                investSvc.metalBuy(data1, false, true).then(function (data) {
                                    if (data.ret_code == "0000") {
                                        openDetail.close();
                                        swiper.slideNext();
                                        setTimeout(function () {
                                            action.close();
                                            $state.go("paySuccess", {data: $scope.buyDetail});

                                        }, 1000);
                                    } else {
                                        openDetail.close();
                                        $state.go("buyFailed", data);
                                    }
                                })
                            }
                        } else {
                            action.close();
                            openDetail.close();
                            var errorPopup = popupSvc.alert({
                                title: data.ret_msg,
                                cssClass: "popup-container",
                                buttons: []
                            });
                            $timeout(function () {
                                errorPopup.close();
                            }, 2000);

                        }
                    }, function () {

                    }, function () {
                        openDetail.close();
                        $state.go("buyFailed");
                    });

                });
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码";
            }
            // encryptedInputValue = keyboardSvc.getEncrypt(id);
            // console.info("加密输入数据:", encryptedInputValue);
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

        $scope.webSite = function () {
            $state.go("choosePick")
        };

        $scope.goAddCard = function () {
            openDetail.close();
            openChangeCard.close();
            temporarySvc.set("p1", {title: 'add'});
            $state.go('addBankCard2');
        };

        $scope.$on("$destroy", function () {
            if (action) {
                action.close();
            }
            if (openChangeCard) {
                openChangeCard.close();
            }
            if (openDetail) {
                openDetail.close();
            }
        })
    });