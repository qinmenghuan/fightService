/**
 * Created by kayak on 16/9/19.
 */
starter.controller('metalFilterCtrl',
    function ($scope,
              $state,
              temporarySvc,
              resourceSvc) {

        $scope.goBack = function () {
            var data = {
                slideBox: 2
            };
            $state.go("investList", {data: data});
        };
        var dict = resourceSvc.getLocalObj('dict');

        $scope.metalFilter = {
            prod_series_list: [],
            prod_kind_list: [],
            company_supplier_list: [],
            prod_weight_list: []
        };
        var blank_all = {
            itemval: '全部',
            itemkey: ''
        };
        dict.forEach(function (e) {
            if (e.dict == 'prod_series') {
                $scope.metalFilter.prod_series_list.push(e);
            }
        });
        dict.forEach(function (e) {
            if (e.dict == 'prod_kind') {
                $scope.metalFilter.prod_kind_list.push(e);
            }
        });
        dict.forEach(function (e) {
            if (e.dict == 'company_supplier') {
                $scope.metalFilter.company_supplier_list.push(e);
            }
        });
        dict.forEach(function (e) {
            if (e.dict == 'prod_weight') {
                $scope.metalFilter.prod_weight_list.push(e);
            }
        });
        $scope.metalFilter.prod_series_list.map(function (item) {
            item.itemkey = item.itemval;
        });
        $scope.metalFilter.company_supplier_list.map(function (item) {
            item.itemkey = item.itemval;
        });

        $scope.metalFilter.prod_series_list.unshift(blank_all);
        $scope.metalFilter.prod_kind_list.unshift(blank_all);
        $scope.metalFilter.company_supplier_list.unshift(blank_all);
        $scope.metalFilter.prod_weight_list.unshift(blank_all);

        console.log($scope.metalFilter);
        $scope.emptyAll = function () {
            $scope.idxArr = [0, 0, 0, 0];
        };

        // 根据缓存默认选中情况赋值
        if (resourceSvc.getLocalObj('metalFilter') == {}) {
            $scope.idxArr = resourceSvc.getLocalObj('metalFilter');
            // console.log($scope.idxArr);
        } else {
            $scope.idxArr = [0, 0, 0, 0];
        }


        $scope.screen = function (idx, str) {
            $scope.idxArr[str] = idx;
            console.log(idx);
        };

        $scope.checkMoney = function (idx) {
            $scope.idxArr[1] = idx;
            console.log(idx);

        };

        $scope.checkType = function (idx) {
            $scope.idxArr[2] = idx;
            console.log(idx);
        };

        $scope.filterList = function () {
            var data = {
                prod_series: $scope.metalFilter.prod_series_list[$scope.idxArr[0]].itemkey,
                prod_kind: $scope.metalFilter.prod_kind_list[$scope.idxArr[1]].itemkey,
                company_supplier: $scope.metalFilter.company_supplier_list[$scope.idxArr[2]].itemkey,
                prod_weight: $scope.metalFilter.prod_weight_list[$scope.idxArr[3]].itemkey
            };
            console.log(data);
            temporarySvc.set('p2', data);
            resourceSvc.setLocal('metalFilter', $scope.idxArr);

            var data1 = {
                slideBox: 2
            };
            $state.go('investList', {data: data1});
        };
    })