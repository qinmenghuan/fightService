/**
 * Created by kayak on 16/9/19.
 */
starter.controller('metalDetailCtrl',
    function ($scope,
              $state,
              $stateParams,
              investSvc,
              $rootScope,
              popupSvc,
              encryptSvc,
              CONFIG,
              CONSTANT,
              $ionicSlideBoxDelegate,
              $cordovaClipboard,
              mineSvc,
              homeSvc,
              temporarySvc,
              shareApp,
              $timeout) {
        document.addEventListener("deviceready", function () {
            console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
            if (navigator.splashscreen) navigator.splashscreen.hide();
        });
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //统一的操作提示
        var tips = function (msg) {
            var tipPop = popupSvc.alert({
                title: msg,
                cssClass: "popup-container",
                buttons: []
            });
            $timeout(function () {
                tipPop.close();
            }, 1000);
        };
        //从跳转地址或路由中获取传参（产品ID和返回state）
        var prod_sub_id, lastUrl, record_id;
        var url = window.location.hash; //获取url中"?"符后的字串
        var url_info = url.split("?")[1] || "";
        var params = temporarySvc.get("p5") || {};
        console.log(params);
        $scope.conf = {
            record_id: ''
            , prod_code: ''
            , slideBox: ''
        };
        if (url_info) {
            var pro_params = url_info.split("&");
            var data={};
            for(var i=0;i<pro_params.length;i++){
                var tmp=pro_params[i].split("=");
                data[tmp[0]]=tmp[1];
            }
            $scope.conf.record_id = data.ret_id;
            $scope.conf.prod_code = data.pro_id;
            $scope.conf.slideBox = data.pro_code;
        } else {
            $scope.conf.record_id = params.record_id ? params.record_id : "";
            $scope.conf.prod_code = params.prod_code;
            $scope.conf.slideBox = params.slideBox;
        }
        temporarySvc.set("p5", $scope.conf);

        //初始化购物车数量加减,获取分享ID
        $scope.item = {
            number: 1,
            record_id: $scope.conf.record_id
        };
        //初始化营销数据
        $scope.activity = [];
        //初始化分享链接、分享状态
        $scope.outUrl = "";
        $scope.config = {
            flagQrcode: false,
            flagQQ: false,
            flagQzone: false,
            flagWechat: false
        };
        //初始化用户基本信息
        var user_info = {};
        encryptSvc.then(function (encrypt) {
            user_info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            console.log(user_info);
        });
        //商品数量增减
        $scope.minus = function () {
            if ($scope.item.number != 0) {
                $scope.item.number -= 1;
            }
        };
        $scope.plus = function () {
            $scope.item.number += 1;
        };

        var data = {
            prod_sub_id: $scope.conf.prod_code
        };
        investSvc.metalDetail(data).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            angular.extend($scope.item, data);
            console.log($scope.item);
            $scope.item.nowPrice = $scope.item.discount_flag == '1' ? $scope.item.discount_price : $scope.item.fixed_price;

            encryptSvc.then(function (encrypt) {
                console.log(encrypt.aesDeObjectL(CONSTANT.ACCOUNT_INFO));
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        } else {
                            $scope.buyStatus = '5'; // 购买
                        }
                    })

                }
            });
            // 贵金属活动说明：14  购买有礼16  产品分享
            //14  购买有礼-广告弹框
            var activityPopupGift = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/investGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            //16  产品分享-广告弹框
            var activityPopupShare = function () {
                $scope.share = popupSvc.alert({
                    templateUrl: "views/invest/investDialog/financeGift.html",
                    scope: $scope,
                    cssClass: "hide-btn invest-gift finance-gift",
                    buttons: [{
                        text: '&#xe620;',
                        type: 'button-default iconfont',
                        onTap: function (e) {
                        }
                    }]
                })
            };
            console.log(data);
            if (data.cycle_list.length > 0) {
                //获取当前营销活动类型
                $scope.activity = data.cycle_list;
                //获取当前营销活动基本信息

                $scope.showPopup = function (act) {
                    if (!investSvc.checkActivityStatus(act, popupSvc)) {
                        return;
                    }
                    if (act.activity_type == "14") {
                        activityPopupGift();
                    }
                    if (act.activity_type == "16") {
                        activityPopupShare();
                    }
                    //获取营销基本信息
                    $scope.giftBaseInfo = act;
                    //获取营销规则
                    investSvc.activityInfo({
                        activity_type: act.activity_type,
                        activity_id: act.activity_id
                    }).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.activityDetailInfo = data.prize_rule_list;
                            for (var i = 0; i < $scope.activityDetailInfo.length; i++) {
                                $scope.activityDetailInfo[i].voucher_url = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.activityDetailInfo[i].voucher_pic_url;
                            }
                            $ionicSlideBoxDelegate.update();
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });


                    if (user_info) {
                        var shareInfo = {
                            activity_id: act.activity_id,
                            activity_name: act.activity_name,
                            activity_type: act.activity_type,
                            product_id: $scope.item.prod_sub_id,
                            product_name: $scope.item.prod_name,
                            product_type: "4",//s_product_type从列表页可传参过来
                            share_type: "4",
                            record_type: "1"  //0邀请注册，1产品分享
                        };
                        console.log(shareInfo);
                        homeSvc.shareId(shareInfo).then(function (data) {
                            if (data.ret_code == "0000") {
                                $scope.baseUrl = CONFIG.SHARE_URL + "metalShare/#/metalShare?" + data.record_id;
                                shareApp.qrcode($scope.baseUrl, "#qrcodeCanvas").then(function (data) {
                                    $scope.outUrl = data;
                                });
                                if ($scope.config.flagQrcode == true) {
                                    $scope.showQrcode();
                                    $scope.config.flagQrcode = false;
                                }
                                if ($scope.config.flagQQ == true) {
                                    $scope.share2QQ();
                                    $scope.config.flagQQ = false;
                                }
                                if ($scope.config.flagQzone == true) {
                                    $scope.share2QZone();
                                    $scope.config.flagQzone = false;
                                }
                                if ($scope.config.flagWechat == true) {
                                    $scope.share2Wechat($scope.config.weChat);
                                    $scope.config.flagWechat = false;
                                }
                            } else {
                                showErrorInfo(data.ret_msg);
                            }
                        });
                    }
                };
            }
        });

        //点击放大二维码
        $scope.showQrcode = function () {
            $scope.share.close();
            console.log($scope.outUrl);
            if (!user_info) {
                tips("分享产品需要先登录");
                return;
            }
            if ($scope.outUrl == "") {
                $scope.config.flagQrcode = true;
                return;
            }
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //长按复制文字
        $scope.copyUrl = function () {
            $cordovaClipboard
                .copy($scope.outUrl)
                .then(function () {
                    $scope.share.close();
                    tips("复制成功");
                }, function () {
                    // error
                });
        };
        //点击弹出活动分享
        $scope.sharePopup = function () {
            $scope.share = popupSvc.action({
                templateUrl: "views/invest/investDialog/shareOut.html",
                scope: $scope,
                cssClass: "share-out",
                closeByDocument: true
            })
        };
        //点击购买有礼的“立即购买”按钮，关闭弹框
        $scope.btnClose = function () {
            $scope.share.close();
        };
        //分享APP
        if (!CONFIG.DEBUG_ON_CHROME) {
            $scope.share2QQ = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQQ = true;
                    return;
                }
                shareApp.share2QQ($scope.outUrl);
            };
            $scope.share2QZone = function () {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.flagQzone = true;
                    return;
                }
                shareApp.share2QZone($scope.outUrl);
            };
            $scope.share2Wechat = function (scene) {
                if (!user_info) {
                    tips("分享产品需要先登录");
                    return;
                }
                if ($scope.outUrl == "") {
                    $scope.config.weChat = scene;
                    $scope.config.flagWechat = true;
                    return;
                }
                shareApp.share2Wechat(scene, $scope.outUrl);
            };
            $scope.share2Weibo = function () {
                shareApp.share2Weibo($scope.outUrl);
            };
        }
        $scope.metalBuy = function () {
            var data = $scope.item;
            console.log(data);
            temporarySvc.set("p2", data);
            $state.go('metalBuy')
        };
        $scope.goLogin = function () {

            $state.go('login')
            //$state.go('login', {params:{url: 'metal'}})
        };

    });