/**
 * Created by kayak on 16/9/19.
 */
starter.controller('metalOrderDetailCtrl',
    function ($scope,
              $state,
              $stateParams,
              temporarySvc) {
        $scope.buyDetail=$stateParams.params||temporarySvc.get("p2")||{};
        $scope.webSite=function () {
            $scope.buyDetail.step='3';
            temporarySvc.set("p2",$scope.buyDetail);
            $state.go("choosePick");
        };
        $scope.$ionicGoBack=function () {
            $state.go("metalOrder");
        }
});