/**
 * Created by kayak on 16/9/19.
 */
starter.controller('metalOrderCtrl', ["$scope", "$state", "assetsSvc", 'temporarySvc', '$rootScope', '$ionicScrollDelegate', '$q',
    function ($scope,
              $state,
              assetsSvc,
              temporarySvc,
              $rootScope,
              $ionicScrollDelegate,
              $q) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = {
            page: '0',
            rows: '10'
        };

        $scope.conf = {
            hasData: true
        };
        $scope.items = [];
        var get = function () {
            var def = $q.defer();
            params.page = +params.page + 1 + '';
            assetsSvc.getGJSList(params).then(function (data) {
                if (data.ret_code !== '0000') {
                    $scope.conf.hasData = false;
                    return;
                }
                $scope.items = $scope.items.concat(data.list);
                def.resolve(1);
            });
            return def.promise;
        };

        get();

        $scope.loadMoreData = function () {
            get().then(function () {
                console.log(1);
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        };

        $scope.goDetails = function (data) {
            $state.go("metalOrderDetail",{params:data});
        };
        $scope.$ionicGoBack=function () {
            $state.go("assets");
        }
    }]);