/**
 * Created by fei on 2016/12/10.
 */
starter.controller('diykeyboardCtrl',
    function ($scope,
              $state,
              $q,
              mineSvc,
              kkDIYKeyboardService) {
        $scope.tradePwdMode = 'diy';
        // $scope.getRandom = function () {
        //     mineSvc.getRandom('pub010401.json').then(function (data) {
        //         if (data.ret_code == "0000") {
        //             $scope.server_random = data.server_random;
        //         }
        //     })
        // };
        // $scope.getDiyKey = function () {
        //     mineSvc.getDiyKey("pub010402.json").then(function (data) {
        //         if (data.ret_code == "0000") {
        //             $scope.publicKey = data.publicKey;
        //         }
        //     })
        //
        // };
        // $scope.getRandom();
        // $scope.getDiyKey();
        $q.all([mineSvc.getDiyKey(), mineSvc.getRandom()]).then(function (args) {
            if (args[0].ret_code == '0000' && args[1].ret_code == '0000') {
                var pwdss = kkDIYKeyboardService.submit(args[0].publicKey, args[1].server_random, '524212');
                console.log(pwdss);
            }
        });
        $scope.test= function (list) {
            console.log("listvalue:",list.join(""));
        };



        // $scope.payTradePwd = function () {
        //     console.log($scope.purchase.money);
        //
        //     ngDialog.closeAll();
        //     $scope.pwdKey();
        //
        // };
        // $scope.pwdKey = function () {
        //     $scope.xiaoyushowKeyBoard3();
        //     $scope.$watch("pwdResult", function (newValue) {
        //         if ($scope.pwdResult == "" || $scope.pwdResult == undefined) {
        //             return false
        //         } else if ($scope.pwdResult != '') {
        //             $scope.pwd1 = newValue;
        //             var timer = $timeout(function () {
        //                 if ($scope.pwdResult = '' || $scope.pwdResult.length != 6) {
        //                     showErrorInfo(accountTips.PASSWORD_VALID_ERROR);
        //                     $scope.initKeyBoard3();
        //                     return false;
        //                 } else {
        //                     $scope.initKeyBoard3();
        //                     var diypwd1 = kkDIYKeyboardService.submit($scope.publicKey, $scope.server_random1, $scope.pwd1);
        //                     var data = {
        //                         pwd: diypwd1[2],
        //                         pwd_type: "T",
        //                         client_random: diypwd1[1],
        //                         server_random: diypwd1[0]
        //                     };
        //                     //发送原密码请求
        //                     console.log(data);
        //                     kkHttpService.postRequest('feedback030302.json', '030302', data).then(
        //                         function (result) {
        //                             if (result.head_ret_code == "0000") {
        //
        //                                 var payData = {
        //                                     acct_no: $scope.purchase.bankCard,
        //                                     prod_code: $scope.purchase.prod_code,
        //                                     buy_amt: $scope.purchase.money.toString(),
        //                                     pay_amt: $scope.purchase.money.toString()
        //                                 };
        //                                 console.log($scope.purchase);
        //
        //                                 kkHttpService.postRequest('fnc560101.json', '560101', payData).then(
        //                                     function (result) {
        //
        //                                         if (result.head_ret_code == "0000") {
        //                                             kkStorageService.setAes(user.userInfo.user_id + 'defaultBankCard', $scope.purchase.bankCard);
        //                                             var data = angular.extend($scope.purchase, result);
        //                                             $state.go('buySuccess', {result: data});
        //                                         } else {
        //                                             ngDialog.closeAll();
        //                                             var alertPopup = $ionicPopup.alert({
        //                                                 title: result.head_ret_msg,
        //                                                 okText: '确定',
        //                                                 okType: 'button-assertive'
        //                                             });
        //                                             alertPopup.then(function () {
        //                                                 //$state.reload($state.current);
        //                                             });
        //                                             //showErrorInfo(result.head_ret_msg);
        //                                             return false;
        //                                         }
        //                                     }, function (err) {
        //                                         console.log(err);
        //                                     }
        //                                 );
        //                             } else if (result.head_ret_code == "2002") {
        //                                 var alertPopup = $ionicPopup.alert({
        //                                     title: result.head_ret_msg + ",还有" + result.remain_loginpwd_times + "次机会",
        //                                     okText: '确定',
        //                                     okType: 'button-assertive'
        //                                 });
        //                                 alertPopup.then(function () {
        //                                     //$state.reload($state.current);
        //                                 });
        //                                 // showErrorInfo(result.head_ret_msg + ",还有" + result.remain_loginpwd_times + "次机会");
        //                                 return false;
        //                             } else if (result.head_ret_code == "3009") {
        //                                 var alertPopup = $ionicPopup.alert({
        //                                     title: result.head_ret_msg + ",还有" + result.trans_password_locktime + "秒解锁",
        //                                     okText: '确定',
        //                                     okType: 'button-assertive'
        //                                 });
        //                                 alertPopup.then(function () {
        //                                     //$state.reload($state.current);
        //                                 });
        //                                 // showErrorInfo(result.head_ret_msg + ",还有" + result.trans_password_locktime + "秒解锁");
        //                                 return false;
        //                             }
        //
        //                         }, function (err) {
        //                             console.log(err);
        //                         }
        //                     );
        //
        //                 }
        //             }, 200)
        //         }
        //
        //     });
        //
        // };
    }
);