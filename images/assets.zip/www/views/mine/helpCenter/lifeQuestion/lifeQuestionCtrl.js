/**
 * Created by admin on 2016/9/30.
 */
starter.controller('lifeQuestionCtrl',
    function ($scope, $state, $stateParams, mineSvc, $rootScope,temporarySvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        console.log($stateParams.type);

        var faq_type = "";
        $scope.questionList = [];


        if ($stateParams.type == "生活服务问题") {
            $scope.title = "生活服务问题";
            faq_type = "6";
        }

        if ($stateParams.type == "贵金属问题") {
            $scope.title = "贵金属问题";
            faq_type = "5";
        }

        if ($stateParams.type == "惠理财问题") {
            $scope.title = "惠理财问题";
            faq_type = "2";
        }
        if ($stateParams.type == "账号·积分问题") {
            $scope.title = "账号·积分问题";
            faq_type = "1";
        }

        mineSvc.question({faq_type: faq_type}).then(function (data) {
            console.log(data);

            if (data.ret_code == "0000") {

                for (var i = 0; i < data.faqlist.length; i++) {

                    $scope.questionList.push(data.faqlist[i])

                }
                console.log($scope.questionList);
            }else{
                showErrorInfo(data.ret_msg);
            }
        });

        //常见问题点击
        $scope.clQuestion = function (item) {
            for (var i = 0; i < $scope.questionList.length; i++) {
                var params = {
                    title: item.faq_title,
                    ans: item.faq_ans
                };
                temporarySvc.set("p9", params);
                $state.go('questionDetails');
                console.log(item.faq_ans);
            }

        }


    });