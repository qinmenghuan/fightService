/**
 * Created by admin on 2016/10/9.
 */
starter.controller('questionDetailsCtrl',
    function ($scope, $stateParams,temporarySvc) {
        var params = temporarySvc.get('p9');
        $scope.name = params.title;
        $scope.ans = params.ans;
    });