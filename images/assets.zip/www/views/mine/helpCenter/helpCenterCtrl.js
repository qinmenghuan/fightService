/**
 * Created by admin on 2016/9/20.
 */
starter.controller('helpCenterCtrl', function ($rootScope,$scope, $state, mineSvc,temporarySvc) {
    //错误提示信息控制
    var showErrorInfo = function (info) {
        $rootScope.errorMsg = info;
        $rootScope.tipShow = true;
    };
    $scope.hotList = [];
    mineSvc.question({faq_type: "",is_hot:"1"}).then(function (data) {
        console.log(data);

        if (data.ret_code == "0000") {

            for (var i = 0; i < data.faqlist.length; i++) {
                if (data.faqlist[i].is_hot == "1") {
                    $scope.hotList.push(data.faqlist[i])
                }
            }
            console.log($scope.hotList);
        }else{
            showErrorInfo(data.ret_msg);
        }
    });

    //热门问题点击
    $scope.hotQuestion = function (item) {
        for (var i = 0; i < $scope.hotList.length; i++) {
            var params = {
                title: item.faq_title,
                ans: item.faq_ans
            };
            temporarySvc.set("p9", params);
            $state.go('questionDetails');
            console.log(item.faq_ans);
        }

    }

    $scope.gridList = [
        {src: "icon-yijianfankui iconfont ", title: "意见反馈"}, {src: "icon-zuanshi iconfont ", title: "账号·积分问题"},
        {src: "icon-qiandai iconfont ", title: "惠理财问题"}, {src: "icon-cika iconfont ", title: "智能存问题"},
        {src: "icon-yousejinshu2 iconfont ", title: "贵金属问题"}, {src: "icon-shenghuo iconfont ", title: "生活服务问题"},
    ];

    $scope.chooseGridItem = function (item) {
        for (i = 0; i < $scope.gridList.length; i++) {

            if (item.title == "智能存问题") {
                $state.go('depositsFaq');
            } else if (item.title == "意见反馈") {
                $state.go('feedback');
            } else if (item.title == "账号·积分问题") {
                $state.go('lifeQuestion', {type: '账号·积分问题'});
            } else if (item.title == "惠理财问题") {
                $state.go('lifeQuestion', {type: '惠理财问题'});
            } else if (item.title == "贵金属问题") {
                $state.go('lifeQuestion', {type: '贵金属问题'});
            } else if (item.title == "生活服务问题") {
                $state.go('lifeQuestion', {type: '生活服务问题'});
            }
        }


    };

    $scope.aboutUs = function () {
        $state.go('aboutUs');
    }
});