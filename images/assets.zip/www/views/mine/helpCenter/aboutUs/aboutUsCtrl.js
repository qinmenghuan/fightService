/**
 * Created by admin on 2016/9/20.
 */
starter.controller('aboutUsCtrl', function ($scope, $state, mineSvc, CONFIG, popupSvc, updateSvc, $rootScope) {
    //错误提示信息控制
    var showErrorInfo = function (info) {
        $rootScope.errorMsg = info;
        $rootScope.tipShow = true;
    };
    $scope.url = "";
    $scope.phone = "";
    $scope.time = "";
    $scope.versionUpdate = function () {
        updateSvc.checkForUpdate();
    };
    mineSvc.aboutUs().then(function (data) {
        console.log(data);
        if (data.ret_code == "0000") {
            $scope.url = data.officialwebsite;
            $scope.phone = data.servicetel;
            $scope.time = data.serviceofficehours;

        } else {
            showErrorInfo(data.ret_msg);
        }
    });
});

