/**
 * Created by admin on 2016/9/20.
 */
starter.controller('feedbackCtrl', function ($scope, $rootScope, encryptSvc, CONSTANT, mineSvc, popupSvc, $timeout, $state, CONFIG, $cordovaDevice, $cordovaAppVersion) {
    //错误提示信息控制
    var showErrorInfo = function (info) {
        $rootScope.errorMsg = info;
        $rootScope.tipShow = true;
    };
    //浏览器调试 DEBUG_ON_CHROME 设置为true 打包app设置为false
    console.log(CONFIG.DEBUG_ON_CHROME);
    if (CONFIG.DEBUG_ON_CHROME == true) {
        $scope.bodyParams = {
            model: "huawei",
            mgcf: "android",
            version: "6.0",
            app_version: "1.0.0"
        };
    } else if (CONFIG.DEBUG_ON_CHROME == false) {
        var model = $cordovaDevice.getModel(),
            platform = $cordovaDevice.getPlatform(),
            version = $cordovaDevice.getVersion();
        $cordovaAppVersion.getVersionCode().then(function (build) {
            var appVersionCode = build;
            $scope.bodyParams = {
                model: model,
                mgcf: platform,
                version: version,
                app_version: appVersionCode
            };
        }, false);
    }
    //获取用户名
    encryptSvc.then(function (encrypt) {
        var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
        $scope.user_name = userInfo.query("user_name");
    });
    $scope.idea = {
        text: ''
    };

    $scope.textLen = 0;
    $scope.$watch('idea.text', function (val) {
        $scope.textLen = 500 - val.length;
    });

    $scope.ideaSubmit = function (idea) {
        if (idea == "") {
            showErrorInfo(CONSTANT.FEEDBACK_NULL);
            return false
        }
        console.log(idea);
        $scope.bodyParams.feedback_content = idea;

        //意见反馈
        mineSvc.feedback($scope.bodyParams).then(function (data) {
            console.log(data);
            if (data.ret_code == "0000") {
                var setSucPopup = popupSvc.alert({
                    title: "反馈成功",
                    cssClass: "popup-container",
                    buttons: []
                });
                $timeout(function () {
                    setSucPopup.close();

                    $state.go('helpCenter');

                }, 500);
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
    }

});