/**
 * Created by admin on 2016/9/20.
 */

starter.controller('depositsFaqCtrl', function ($scope, $state, mineSvc, $rootScope,temporarySvc) {
    //错误提示信息控制
    var showErrorInfo = function (info) {
        $rootScope.errorMsg = info;
        $rootScope.tipShow = true;
    };
    var faq_type = "";
    $scope.tittleStatus = true;
    $scope.inviteRecord = function () {
        $scope.tittleStatus = true;
        faq_type = "3";
        console.log($scope.tittleStatus)
        $scope.checkBtn(faq_type);

    };
    $scope.myReward = function () {
        $scope.tittleStatus = false;
        faq_type = "4";
        console.log($scope.tittleStatus);
        $scope.checkBtn(faq_type);

    };

    $scope.currentList = [];

    mineSvc.question({faq_type: "3"}).then(function (data) {
        console.log(data);
        if (data.ret_code == "0000") {
            for (var i = 0; i < data.faqlist.length; i++) {
                $scope.currentList.push(data.faqlist[i])
            }
            console.log($scope.currentList);
        }else{
            showErrorInfo(data.ret_msg);
        }
    });

    $scope.checkBtn = function (faq_type) {
        mineSvc.question({faq_type: faq_type}).then(function (data) {
            console.log(data);
            $scope.currentList = [];
            if (data.ret_code == "0000") {

                for (var i = 0; i < data.faqlist.length; i++) {

                    $scope.currentList.push(data.faqlist[i])

                }
                console.log($scope.currentList);
            }
        });
    };

    //常见问题点击
    $scope.clQuestion = function (item) {
        var params = {
            title: item.faq_title, 
            ans: item.faq_ans
        };
        temporarySvc.set("p9", params);
        $state.go('questionDetails');
    }
});