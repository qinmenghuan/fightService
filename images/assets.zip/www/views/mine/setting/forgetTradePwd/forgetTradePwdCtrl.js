/**
 * Created by mazh on 2016/4/6
 */
starter.controller('forgetTradePwdCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              mineSvc,
              popupSvc,
              $timeout,
              util,
              appInitSvc,
              accountSvc,
              keyboardSvc,
              $ionicHistory,
              CONSTANT,
              busCenterSvc,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.obj = {
            step: 1,
            tittle: "身份验证"
        };
        $scope.checkModel = {};

        //查询安全状态，若已绑卡，走A流程；若未绑卡，走B流程
        mineSvc.queryAccountStatus().then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.obj.mobile = data.user_info.mobile;
                    if (data.acctstep_list[1].flag == 1) {
                        $scope.obj.flag = "A";
                        mineSvc.queryBankList().then(function (data) {
                            console.log(data);
                            if (data.ret_code == "0000") {
                                $scope.thisDecryptData = data.acct_list;
                                $scope.thisDecryptData[0].last = true;
                            } else {
                                showErrorInfo(data.ret_msg);
                            }
                        })
                    }
                    else if (data.acctstep_list[1].flag == 0) {
                        $scope.obj.flag = "B";
                        $scope.getCode($scope.obj.mobile);
                    }
                    console.log($scope.obj);
                }
            }
        );
        $scope.changeLast = function (item) {
            for (var i in $scope.thisDecryptData) {
                $scope.thisDecryptData[i].last = false;
            }
            item.last = true;
        };


//A流程
        $scope.nextStepA = function () {
            $scope.obj.step = 2;
            //找出被选中的卡
            for (var o in $scope.thisDecryptData) {
                if ($scope.thisDecryptData[o].last == true) {
                }
                $scope.cardItem = $scope.thisDecryptData[o];

            }
        };
        $scope.thirdStepA = function (checkModel) {
            console.log(checkModel);
            //验证身份证号是否合规
            var checkID = toolSvc.checkID(checkModel.id_code);
            if (checkID) {
                showErrorInfo(checkID);
                return;
            }
            if (checkModel.card_no === undefined) {
                showErrorInfo(CONSTANT.CARD_NO_EMPTY);
                return false;
            }
            if (!/^(\d{16}|\d{19})$/.test(checkModel.card_no)) {
                showErrorInfo(CONSTANT.CARD_UNVALID);
                return false;
            }
            mineSvc.checkCard(checkModel).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.obj.step = 3;
                    $scope.obj.tittle = "设置新交易密码";
                } else {
                    showErrorInfo(data.ret_msg);
                }
            })

        };
        $scope.fourthStepA = function () {
            var setSucPopup = popupSvc.alert({
                title: "修改成功",
                buttons: []
            });
            $timeout(function () {
                setSucPopup.close();

                $state.go('setting');

            }, 500);
        };
//B流程
// 设置获取验证码按钮默认状态
        $scope.phoneInvalid = true;
//设置验证码是否获取状态
        $scope.ifCode = false;
        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function (phone) {

            accountSvc.getCode({
                mobile: phone,
                busi_type: '007'
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.phoneInvalid = false;
                    $scope.ifCode = true;
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime + 60 * 1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                    $scope.obj.code_id = data.code_id;
                    $scope.obj.response_date = data.response_date;
                } else {
                    showErrorInfo(data.ret_msg);
                    return false;
                }

            })

        }
//重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = true;
        }

        $scope.nextStepB = function () {
            console.log($scope.obj);
            //验证验证码
            busCenterSvc.oldPhone($scope.obj).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.obj.step = 3;
                    $scope.obj.tittle = "设置新交易密码";
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };

        var encryptedInputValue = "";

//默认参数,一个页面模版,相同变量,这里先定义.
        var public = {
            title: "设置交易密码",
            buttonText: "下一步",
            kid: "box" + new Date().getTime(),
            thirdStepB: function () {
            },
            tip: false,
            errorText: "",
            showForgetBtn: false
        };


        $scope.thirdStepB = public.thirdStepB = function () {
            encryptedInputValue = keyboardSvc.getEncrypt(public.kid);
            if (encryptedInputValue.errorCode == CFCA_OK) {
                //修改交易密码
                mineSvc.changeTradePwd({
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: "C",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom()
                }).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        var setSucPopup = popupSvc.alert({
                            title: "设置交易密码成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            setSucPopup.close();
                            $ionicHistory.goBack(-2);
                        }, 500);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码"
            }
        };
// 配置键盘
        $scope.config = {
            doneCallback: function () {
                encryptedInputValue = keyboardSvc.getEncrypt(public.kid);
                console.info("加密输入数据:", encryptedInputValue);
                public.thirdStepB();
            },
            validateCallback: function () {
                $rootScope.tip = false;
                $scope.errorText = ""
            },
            serverRandomPromise: appInitSvc.synServerRandom()
        };

        $scope.public = public;
//$scope.thirdStepA = function (obj) {
//    console.log($scope.obj.user_name);
//    if ($scope.obj.user_name === undefined) {
//        showErrorInfo(accountTips.NAME_NULL);
//        return false;
//    }
//    if ($scope.obj.id_code === undefined) {
//        showErrorInfo(accountTips.ID_NO_EMPTY);
//        return false;
//    }
//    if ($scope.obj.card_no === undefined) {
//        showErrorInfo(accountTips.CARD_NO_EMPTY);
//        return false;
//    }
//    if (!(/^[\u4e00-\u9fa5]{1,15}$/).test($scope.obj.user_name)) {
//        showErrorInfo(accountTips.NAME_UNREAL);
//        return false
//    }
//    if (!/^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test($scope.obj.id_code)) {
//        showErrorInfo(accountTips.ID_UNVALID);
//        return false;
//    }
//
//    console.log(obj);
//    //验证银行卡信息请求
//    var bankInfoParams = {
//        id_code: $scope.obj.id_code,
//        card_no: $scope.obj.card_no,
//        user_name: $scope.obj.user_name,
//        card_cust_no: $scope.card_cust_no
//    };
//    kkHttpService.postRequest('password030303.json', '030303', bankInfoParams).then(
//        function (result) {
//            console.log(result);
//            if (result.head_ret_code == "0000") {
//                $scope.obj.step = 3;
//                $scope.obj.tittle = "设置交易密码";
//                //请求服务器随机数
//                kkHttpService.postRequest('feedback000301.json', '000301').then(
//                    function (result) {
//                        if (result.head_ret_code == "0000") {
//                            $scope.server_randomA = result.server_random;
//                            var configPwdA = {
//                                server_random: $scope.server_randomA,
//                                inputId: "forgetPayPwdA",
//                                keyboardId: "numberKeyboardForgetPay",
//                                minLength: parseInt('6'),
//                                maxLength: parseInt('6'),
//                                matchRegex: "^\\d{6}$",
//                                inputType: "number"
//                            };
//                            kkCfcaKeyboardService.initInput(configPwdA);
//                            kkCfcaKeyboardService.doClearInput(configPwdA);
//                        } else {
//                            showErrorInfo(result.head_ret_msg);
//                            return false;
//                        }
//                    }, function (err) {
//                        console.log(err);
//                    }
//                );
//            } else {
//                showErrorInfo(result.head_ret_msg);
//                return false;
//            }
//        }, function (err) {
//            console.log(err);
//        }
//    );
//};
//$scope.fourthStepA = function (str) {
//    var configPwd2A = {
//        inputId: str,
//        server_random: $scope.server_randomA,
//        inputType: "number"
//    };
//    console.log(configPwd2A);
//    //获取正则匹配结果
//    var regResult = kkCfcaKeyboardService.getCheckRegexResult(configPwd2A);
//    console.log(regResult)
//    if (regResult == false) {
//        kkCfcaKeyboardService.doClearInput(configPwd2A);
//        showErrorInfo(accountTips.PASSWORD_VALID_ERROR);
//        return false;
//    } else {
//        //获取加密结果
//        var encryptData1 = kkCfcaKeyboardService.getEncrypt(configPwd2A);
//        var loginParams1 = {
//            new_pwd: encryptData1.password,
//            pwd_type: "T",
//            pwd_flag: "S",
//            client_random: encryptData1.client_random,
//            server_random: encryptData1.server_random
//        };
//        //设置新密码请求
//        kkHttpService.postRequest('feedback030301.json', '030301', loginParams1).then(
//            function (result) {
//                if (result.head_ret_code == "0000") {
//                    ngDialog.open({
//                        template: "forgetDialog.html",
//                        className: 'custom-dialog-center set-pwd-dialog',
//                        showClose: false,
//                        scope: $scope
//                    });
//                    $timeout(function () {
//                        ngDialog.close();
//                        $state.go('setting');
//                    }, 500);
//                } else {
//                    showErrorInfo(result.head_ret_msg);
//                    kkCfcaKeyboardService.doClearInput(configPwd2A);
//                    return false;
//                }
//            }, function (err) {
//                console.log(err);
//            }
//        );
//
//    }
//}
////b流程
//$scope.thirdStepB = function () {
//    //验证验证码是否输入
//    if (typeof $scope.obj.smsCode === 'undefined' || !/^\d{6}$/.test($scope.obj.smsCode + '')) {
//        showErrorInfo(commonTips.VALID_CODE_ERROR);
//        return false;
//    }
//    //验证验证码请求
//    var codeParams = {
//        mobile: $scope.obj.mobile,
//        busi_type: '007',
//        code: $scope.obj.smsCode
//    };
//    kkHttpService.postRequest('validcode000202.json', '000202', codeParams).then(
//        function (result) {
//            console.log(result);
//            if (result.head_ret_code == "0000") {
//                $scope.obj.step = 3;
//                $scope.obj.tittle = "设置新交易密码";
//                //请求服务器随机数
//                kkHttpService.postRequest('feedback000301.json', '000301').then(
//                    function (result) {
//                        if (result.head_ret_code == "0000") {
//                            $scope.server_randomB = result.server_random;
//                            var configPwdB = {
//                                server_random: $scope.server_randomB,
//                                inputId: "forgetPayPwdB",
//                                keyboardId: "numberKeyboardForgetPay",
//                                minLength: parseInt('6'),
//                                maxLength: parseInt('6'),
//                                matchRegex: "^\\d{6}$",
//                                inputType: "number"
//                            };
//                            kkCfcaKeyboardService.initInput(configPwdB);
//                            kkCfcaKeyboardService.doClearInput(configPwdB);
//                        } else {
//                            showErrorInfo(result.head_ret_msg);
//                            return false;
//                        }
//                    }, function (err) {
//                        console.log(err);
//                    }
//                );
//            } else {
//                showErrorInfo(result.head_ret_msg);
//                return false;
//            }
//        }, function (err) {
//            console.log(err);
//        }
//    );
//
//};
//$scope.lastStepB = function (str) {
//    var configPwd2B = {
//        inputId: str,
//        server_random: $scope.server_randomB,
//        inputType: "number"
//    };
//    console.log(configPwd2B);
//    //获取正则匹配结果
//    var regResult = kkCfcaKeyboardService.getCheckRegexResult(configPwd2B);
//    console.log(regResult)
//    if (regResult == false) {
//        kkCfcaKeyboardService.doClearInput(configPwd2B);
//        showErrorInfo(accountTips.PASSWORD_VALID_ERROR);
//        return false;
//    } else {
//        //获取加密结果
//        var encryptData1 = kkCfcaKeyboardService.getEncrypt(configPwd2B);
//        // 验证密码是否太简单
//        var checkPwdLv = {
//            pwd: encryptData1.password,
//            client_random: encryptData1.client_random,
//            server_random: encryptData1.server_random
//        };
//        kkHttpService.postRequest('password030305.json', '030305', checkPwdLv).then(
//            function (result) {
//                console.log(result);
//                if (result.head_ret_code == "0000") {
//                    var loginParams1 = {
//                        new_pwd: encryptData1.password,
//                        pwd_type: "T",
//                        pwd_flag: "S",
//                        client_random: encryptData1.client_random,
//                        server_random: encryptData1.server_random
//                    };
//                    //设置新密码请求
//                    kkHttpService.postRequest('feedback030301.json', '030301', loginParams1).then(
//                        function (result) {
//                            if (result.head_ret_code == "0000") {
//                                ngDialog.open({
//                                    template: "forgetDialog.html",
//                                    className: 'custom-dialog-center set-pwd-dialog',
//                                    showClose: false,
//                                    scope: $scope
//                                });
//                                $timeout(function () {
//                                    ngDialog.close();
//                                    $state.go('setting');
//                                }, 500);
//
//                            } else {
//                                showErrorInfo(result.head_ret_msg);
//                                kkCfcaKeyboardService.doClearInput(configPwd2B);
//                                return false;
//                            }
//                        }, function (err) {
//                            console.log(err);
//                        }
//                    );
//
//                } else {
//                    showErrorInfo(result.head_ret_msg);
//                    kkCfcaKeyboardService.doClearInput(configPwd2B);
//
//                }
//            })
//
//
//    }
//};
    })
;
