/**
 * Created by kayak on 16/9/18.
 */
starter.controller("settingCtrl",
    function ($scope,
              $rootScope,
              $state,
              popupSvc,
              mineSvc,
              $timeout,
              encryptSvc,
              resourceSvc,
              CONSTANT,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        //获取registrationid
        var registrationid = resourceSvc.getLocal('registrationid');

        $scope.item = {text: "手势密码"};

        //从缓存获取手势密码是否设置
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            var user_id = userInfo.query("user_id");
            var gesturePwdName = user_id + "gesturePwd";
            if (encrypt.aesDeObjectL(gesturePwdName) == null) {
                $scope.item.checked = false;
            } else {
                $scope.item.checked = true;
            }
        });
        $scope.toggleChange = function (item) {
            if (item.checked == true) {
                $state.go('checkLoginPwd');
            }
            if (item.checked == false) {
                //提示是否确认清除手势密码
                popupSvc.alert({
                    title: "关闭手势密码将清除您已设置的手势",
                    cssClass: "popup-container",
                    buttons: [
                        {
                            text: '<b>确定</b>',
                            type: 'button-positive',
                            onTap: function (e) {
                                encryptSvc.then(function (encrypt) {
                                    var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                                    var user_id = userInfo.query("user_id"),
                                        gesturePwd = encrypt.aesDeObjectL(user_id + "gesturePwd");
                                    resourceSvc.removeLocal(user_id + "gesturePwd");
                                    //gesturePwd.clear();

                                });
                                $scope.item.checked = false;
                            }
                        },
                        {
                            text: '<b>取消</b>',
                            type: 'button-positive',
                            onTap: function (e) {
                                $scope.item.checked = true;
                            }
                        }
                    ]
                });

            }
            $scope.isPopup = false;
        };
        //获取head_jsessionid后判断是否完成实名认证，未完成则终止流程
        mineSvc.queryAccountStatus().then(function (data) {
            if (data.ret_code == "0000") {
                $scope.account_safe_status = data.acctstep_list;
            } else {
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.goSetLoginPwd=function(){
            $state.go('setLoginPwd')
        };
        $scope.checkSafeStatus = function (i) {
            // console.log($scope.account_safe_status.substring(0, 2) == "11",i);
            if ($scope.account_safe_status[1].flag == "1") {
                if (i == "phone") {
                    $state.go('setPhoneNum', {validate: 3});
                } else if (i == "tradPwd") {
                    var tempData = {
                        fromUrl: "setting",
                        pwdStatus: "hasTradPwd",
                        lastUrl: "setting"
                    };
                    temporarySvc.set('p1', tempData);
                    $state.go('setTradePwd');
                }
            } else {
                if (i == "phone") {
                    $state.go('validate', {validate: "phone"});
                }
                if (i == "tradPwd") {
                    $state.go('validate', {validate: "tradPwd"});
                }
            }
        };
        $scope.quit = function () {
            //提示是否退出
            popupSvc.alert({
                title: "是否确认退出登录?",
                cssClass: "popup-container",
                buttons: [
                    {
                        text: '<b>确定</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            mineSvc.quit({
                                registrationid: registrationid
                            }).then(function (data) {
                                console.log(data);
                                if (data.ret_code == "0000") {
                                    encryptSvc.then(function (encrypt) {
                                        var user_Info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                                        user_Info.clear();
                                        resourceSvc.clearSession();
                                        resourceSvc.removeLocal(CONSTANT.HEAD_JSESSIONID);
                                        resourceSvc.removeLocal(CONSTANT.ACCOUNT_INFO);
                                    });
                                    var setSucPopup = popupSvc.alert({
                                        title: "已注销登录",
                                        cssClass: "popup-container",
                                        buttons: []
                                    });
                                    $timeout(function () {
                                        setSucPopup.close();
                                        $state.go('home');
                                    }, 500);
                                } else {
                                    showErrorInfo(data.ret_msg);
                                }
                            })
                        }
                    },
                    {text: '取消'}
                ]
            });
        };
    });