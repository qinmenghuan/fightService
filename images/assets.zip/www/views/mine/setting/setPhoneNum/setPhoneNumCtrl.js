/**
 * Created by mazh on 2016/4/5
 */
starter.controller('setPhoneNumCtrl',
    function ($scope,
              util,
              $state,
              $stateParams,
              $rootScope,
              encryptSvc,
              CONSTANT,
              mineSvc,
              $timeout,
              $validation,
              popupSvc,
              appInitSvc,
              keyboardSvc,
              accountSvc,
              CONFIG) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        $scope.obj = {};
        $scope.obj.validate = 3;
        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = true;
        //设置验证码是否获取状态
        $scope.ifCode = false;
        $scope.phoneModel = {};
        //$scope.obj.validate = $stateParams.validate;
        if ($scope.obj.validate == 3) {
            $scope.obj.title = "身份验证";
        }
        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function (phone) {
            console.log(phone);
            //判断手机号是否符合格式
            if (!/^1\d{10}$/.test(phone)) {
                showErrorInfo(CONSTANT.PHONE_ERROR);
                return false;
            } else {
                //判断该手机号是否注册(写在这是因为失去焦点事件点击按钮不会触发)
                var registerParams = {
                    login_name: phone
                };

                accountSvc.isRegister(registerParams).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        if (data.is_regist == "0") {
                            accountSvc.getCode({
                                mobile: phone,
                                busi_type: '005'
                            }).then(function (data) {
                                console.log(data);
                                if (data.ret_code == "0000") {
                                    $scope.phoneInvalid = false;
                                    $scope.ifCode = true;
                                    //获取当前时间毫秒数
                                    var startTime = new Date().getTime();
                                    //获取结束时间毫秒数
                                    var endTime = startTime + 60 * 1000;
                                    $scope.countDown = util.countDown({timer: endTime});
                                    $scope.countDown.run(function (s) {
                                        $scope.codeText = s + "s后重新获取";
                                    }, codeReset);
                                    $scope.phoneModel.code_id = data.code_id;
                                    $scope.phoneModel.response_date = data.response_date;
                                } else {
                                    showErrorInfo(data.ret_msg);
                                    return false;
                                }

                            })
                        } else {
                            showErrorInfo(CONSTANT.PHONE_ALREADY)
                        }

                    } else {
                        showErrorInfo(data.ret_msg);
                        return false;
                    }

                });
            }
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = true;
        }

        $scope.submit = function (phoneForm, phoneModel) {
            //获取原手机号
            encryptSvc.then(function (encrypt) {
                var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                phoneModel.mobile = userInfo.query("mobile");
                console.log(phoneModel);
                mineSvc.changeMobile(phoneModel).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        //更改缓存中的手机号
                        userInfo.save({mobile: phoneModel.new_mobile});
                        console.log(userInfo);
                        var setSucPopup = popupSvc.alert({
                            title: "操作成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            setSucPopup.close();

                            $state.go('setting');

                        }, 1000);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                })
            });

        };
        var encryptedInputValue = "";

        //默认参数,一个页面模版,相同变量,这里先定义.
        var public = {
            title: "设置交易密码",
            buttonText: "下一步",
            kid: "box" + new Date().getTime(),
            nextStep: function () {
            },
            tip: false,
            errorText: "",
            showForgetBtn: false
        };


        console.log("setPayPassword");
        $scope.nextStep = public.nextStep = function () {
            encryptedInputValue = keyboardSvc.getEncrypt(public.kid);
            if (encryptedInputValue.errorCode == CFCA_OK) {

                mineSvc.checkTradePwd({
                    pwd_type: "T",
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: "C",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom()
                }).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        $scope.obj = {
                            title: "身份验证",
                            validate: 4
                        };
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码"
            }
        };


        // 配置键盘
        $scope.config = {
            doneCallback: function () {
                encryptedInputValue = keyboardSvc.getEncrypt(public.kid);
                console.info("加密输入数据:", encryptedInputValue);
                public.nextStep();
            },
            validateCallback: function () {
                $scope.tip = false;
                $scope.errorText = ""
            },
            serverRandomPromise: appInitSvc.synServerRandom()
        };

        $scope.public = public;
    });
