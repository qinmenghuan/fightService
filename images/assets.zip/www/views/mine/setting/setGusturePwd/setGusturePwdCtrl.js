/**
 * Created by kayak on 16/9/18.
 */
starter.controller("setGusturePwdCtrl",
    function ($scope,
              $state,
              $stateParams,
              CONSTANT,
              $gestureLock,
              popupSvc,
              GestureLockService,
              $window,
              $timeout,
              $rootScope,
              resourceSvc,
              encryptSvc,
              mineSvc,
              pageJumpSvc,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.obj = {
            title: "设置手势密码",
            step: 1,
            lastUrl: ""
        };
        if ($stateParams.params) {
            angular.extend($scope.obj, $stateParams.params);
        }

        $scope.skipDialog = function () {
            //提示是否退出
            popupSvc.alert({
                title: "是否跳过手势密码设置，您可进入【我的-设置-手势密码】中再次设置",
                cssClass: "popup-setGus",
                buttons: [
                    {
                        text: '确定',
                        onTap: function (e) {
                            $state.go('home')
                        }
                    }, {
                        text: '取消'
                    }
                ]
            })
        };

        //确认跳过
        $scope.reallySkip = function () {
            $state.go('home');
            //ngDialog.close();
        };
        //取消跳过
        $scope.cancelSkip = function () {
            //ngDialog.close();
        };
        $scope.nextStep = function (new_pwd) {
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(new_pwd);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }

            // 登录参数
            var checkLoginParams = {
                pwd_type: "L",
                new_pwd: new_pwd
            };
            //验证登录密码请求
            mineSvc.checkTradePwd(checkLoginParams).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $state.go('setGusturePwd');
                } else {
                    showErrorInfo(data.ret_msg);

                }
            })

        };
        var isValidate = true;
        $scope.title = "绘制图案设置锁";

        var passwords = [2];
        var count = 1;
        if (!isValidate) {
            $scope.title = "请输入原密码";
        }
        $scope.$on('$ionicView.enter', function () {
            $scope.$broadcast('canvas.init');
        });


        var setPwdCount = 0,
            pwd1 = '';
        $scope.gesturePwd = [false, false, false, false, false, false, false, false, false];
        $scope.chooseFn = function () {
        };
        $scope.touchend = function (gesture) {
            setPwdCount++;
            var pwd = gesture.orders.join('');
            //第一次设置密码
            if (setPwdCount === 1) {
                if (pwd.length < 4) {
                    $scope.title = "请至少选择四个圆！";
                    setPwdCount = 0;
                    $timeout(function () {
                        gesture.clear();
                    }, 500);
                    return;
                }
                pwd1 = pwd;
                $scope.title = '再次设置手势密码';
                gesture.matrixs.forEach(function (li, i) {
                    $scope.gesturePwd[i] = !!li;
                });
                console.log($scope.gesturePwd);
                setTimeout(function () {
                    gesture.clear();
                }, 500);
            }
            //第二次设置密码
            if (setPwdCount === 2) {

                //如果两次密码相同
                if (pwd1 === pwd) {
                    gesture.successStatus();
                    //获取user_id
                    encryptSvc.then(function (encrypt) {
                        var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                        $scope.obj.user_id = userInfo.query("user_id");
                        localStorage.setItem($scope.obj.user_id + "gesturePwd", pwd);
                        encrypt.aesEnObjectL($scope.obj.user_id + "gesturePwd", pwd);
                        popupSvc.alert({
                            title: "设置成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            if ($scope.obj.lastUrl == 'registerNext') {
                                $state.go('home');
                            } else {
                                $state.go('setting');
                                pageJumpSvc.nextPageGoBack({
                                    nextState: "setting",
                                    currentState: "setGusturePwd",
                                    goBack: "mine"
                                })
                            }
                        }, 1000);
                        /*if($scope.obj.user_id){
                         var resEnLocalTemp = resourceSvc.localTemp("gesture");
                         var obj = {};
                         obj[$scope.obj.user_id] = {
                         gesturePwd :pwd
                         }
                         resEnLocalTemp.save(obj);
                         popupSvc.alert({
                         title: "设置成功",
                         cssClass: "popup-container",
                         buttons: []
                         });
                         $timeout(function () {
                         if ($scope.obj.lastUrl == 'registerNext') {
                         $state.go('home');
                         } else {
                         $state.go('setting');
                         }
                         }, 1000);
                         }*/
                    });
                } else {
                    $scope.title = '两次设置不一致，请重新设置';
                    $scope.obj.title = "设置手势密码";
                    setPwdCount = 0;
                    gesture.errorStatus();
                    $timeout(function () {
                        gesture.clear();
                    }, 500);
                }
            }

        };
    });