/**
 * Created by mazh on 2016/9/27
 */
starter.controller('setTradePwdCtrl',
    function ($scope,
              $state,
              CONSTANT,
              $rootScope,
              $ionicHistory,
              popupSvc,
              $timeout,
              encryptSvc,
              appInitSvc,
              keyboardSvc,
              mineSvc,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        //获取temporarySvc  里边的 fromUrl值
        var fromUrl = temporarySvc.get('p1').fromUrl;

        $scope.goback = function () {
            switch (fromUrl) {
                case "setting":
                    $state.go('setting');
                    break;
                case "accountSafe":
                    $state.go('accountSafe');
                    break;
                case "bankCardList":
                    $state.go('bankCardList');
                    break;
            }
        };
        $scope.obj = {};
        switch (temporarySvc.get('p1').pwdStatus) {
            case "noTradPwd":
                $scope.obj = {
                    step: 0,
                    tittle: "设置交易密码",
                    pwdStatus: "noTradPwd"
                };
                break;
            case "hasTradPwd":
                $scope.obj = {
                    step: 1,
                    tittle: "验证原交易密码"
                };
                break;
            case "delBankCard":
                $scope.obj = {
                    step: 3,
                    tittle: "解绑银行卡"
                };
                break;
            case "verifyCard":
                $scope.obj = {
                    step: 2,
                    tittle: "验卡"
                };
                break;
        }

        $scope.nextStep = function (checkOldPayPwd) {
            $scope.obj = {
                step: 2,
                tittle: "设置新交易密码"
            };
        };
        $scope.thirdStep = function () {
            var setSucPopup = popupSvc.alert({
                title: "修改成功",
                buttons: []
            });
            $timeout(function () {
                setSucPopup.close();
                $state.go('setting');
            }, 500);
        };
        var encryptedInputValue = "";

        //默认参数,一个页面模版,相同变量,这里先定义.
        var public = {
            title: "设置交易密码",
            buttonText: "下一步",
            kid: "box" + new Date().getTime(),
            nextStep: function () {
            },
            tip: false,
            errorText: "",
            showForgetBtn: false
        };

        function step0() {
            //设置交易密码
            mineSvc.setTradePwd({
                new_pwd: encryptedInputValue.encryptedInputValue,
                keyboard_type: "C",
                client_random: encryptedInputValue.encryptedClientRandom,
                server_random: keyboardSvc.getServerRandom()
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    var setSucPopup = popupSvc.alert({
                        title: "设置交易密码成功",
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        setSucPopup.close();
                        $scope.goback();
                    }, 500);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        }

        function step1() {
            //验证交易密码
            mineSvc.checkTradePwd({
                pwd_type: "T",
                new_pwd: encryptedInputValue.encryptedInputValue,
                keyboard_type: "D",
                client_random: encryptedInputValue.encryptedClientRandom,
                server_random: keyboardSvc.getServerRandom()
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    keyboardSvc.clear(public.kid);
                    $scope.obj = {
                        step: 2,
                        tittle: "设置新交易密码"
                    };
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        }

        function step2() {
            //修改交易密码
            mineSvc.changeTradePwd({
                new_pwd: encryptedInputValue.encryptedInputValue,
                keyboard_type: "C",
                client_random: encryptedInputValue.encryptedClientRandom,
                server_random: keyboardSvc.getServerRandom()
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    var setSucPopup = popupSvc.alert({
                        title: "修改交易密码成功",
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        setSucPopup.close();
                        $scope.goback();
                    }, 500);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        }

        function step3() {
            //解绑银行卡
            mineSvc.checkTradePwd({
                pwd_type: "T",
                new_pwd: encryptedInputValue.encryptedInputValue,
                keyboard_type: "C",
                client_random: encryptedInputValue.encryptedClientRandom,
                server_random: keyboardSvc.getServerRandom()
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    keyboardSvc.clear(public.kid);

                    $state.go('unBindCard')

                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        }

        $scope.nextStep = public.nextStep = function () {
            encryptedInputValue = keyboardSvc.getEncrypt(public.kid)
            if (encryptedInputValue.errorCode == CFCA_OK) {
                if ($scope.obj.step == 0) {
                    step0();
                } else if ($scope.obj.step == 1) {
                    step1();
                } else if ($scope.obj.step == 2) {
                    step2();
                } else if ($scope.obj.step == 3) {
                    step3();
                }
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码";
            }
        };


        // 配置键盘
        $scope.config = {
            doneCallback: function () {
                encryptedInputValue = keyboardSvc.getEncrypt(public.kid);
                console.info("加密输入数据:", encryptedInputValue);
                public.nextStep();
            },
            validateCallback: function () {
                $rootScope.tip = false;
                $scope.errorText = ""
            },
            serverRandomPromise: appInitSvc.synServerRandom()
        };

        $scope.public = public;
    });
