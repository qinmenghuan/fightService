/**
 * Created by mazh on 16/9/27.
 */
starter.controller("setLoginPwdCtrl",
    function ($scope,
              $rootScope,
              $state,
              CONSTANT,
              encryptSvc,
              accountSvc,
              mineSvc,
              $timeout,
              util,
              popupSvc,
              $stateParams,
              busCenterSvc,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.title = "身份验证";
        $scope.obj = {
            step: 1
        };
        $scope.loginPwdModel = {};
        $scope.idCardModel = {};
        $scope.newLoginPwdModel = {};
        // 是否显示身份证号
        $scope.showPwd = false;
        $scope.changeShowPwd = function () {
            $scope.showPwd = !$scope.showPwd;
            console.log($scope.showPwd);
        };
        $scope.params = $stateParams.params || {};
        console.log($stateParams)
        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = true;
        //设置验证码是否获取状态
        $scope.ifCode = false;
        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function (mobile) {
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(mobile, true);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //若从设置页面跳转至该页面则判断该手机号是为当前账号(写在这是因为失去焦点事件点击按钮不会触发)
            encryptSvc.then(function (encrypt) {
                if ($scope.params.lastUrl == 'login') {
                    accountSvc.getCode({mobile: mobile, busi_type: '006'}).then(function (data) {
                        console.log(data);
                        if (data.ret_code == "0000") {
                            $scope.loginPwdModel.code_id = data.code_id;
                            $scope.loginPwdModel.response_date = data.response_date;
                            $scope.phoneInvalid = false;
                            $scope.ifCode = true;
                            //获取当前时间毫秒数
                            var startTime = new Date().getTime();
                            //获取结束时间毫秒数
                            var endTime = startTime + 60 * 1000;
                            $scope.countDown = util.countDown({timer: endTime});
                            $scope.countDown.run(function (s) {
                                $scope.codeText = s + "s后重新获取";
                            }, codeReset);
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                } else {
                    if (mobile != encrypt.aesLocalTemp(CONSTANT.USER_INFO).query("mobile")) {
                        showErrorInfo("该手机号不是当前账号！")
                    }
                    accountSvc.getCode({mobile: mobile, busi_type: '006'}).then(function (data) {
                        console.log(data);
                        if (data.ret_code == "0000") {
                            $scope.loginPwdModel.code_id = data.code_id;
                            $scope.loginPwdModel.response_date = data.response_date;
                            $scope.phoneInvalid = false;
                            $scope.ifCode = true;
                            //获取当前时间毫秒数
                            var startTime = new Date().getTime();
                            //获取结束时间毫秒数
                            var endTime = startTime + 60 * 1000;
                            $scope.countDown = util.countDown({timer: endTime});
                            $scope.countDown.run(function (s) {
                                $scope.codeText = s + "s后重新获取";
                            }, codeReset);
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                }
            });
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = true;
        }

        //第一步提交手机号和验证码
        $scope.submitFirst = function (loginPwdForm, loginPwdModel) {
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(loginPwdModel.mobile, true);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //验证验证码是否合规
            var checkCode = toolSvc.checkSmsCode(loginPwdModel.code, true);
            if (checkCode) {
                showErrorInfo(checkCode);
                return;
            }
            console.log(loginPwdModel);
            busCenterSvc.oldPhone(loginPwdModel).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.loginPwdModel = angular.extend($scope.loginPwdModel, data);
                    //查询安全状态
                    mineSvc.queryAccountStatus({mobile: loginPwdModel.mobile}).then(function (data) {
                        console.log(data);
                        if (data.ret_code == "0000") {
                            if (data.acctstep_list[1].flag == "0") {
                                $scope.obj.step = 3;
                                $scope.title = "请输入新登录密码";
                            } else {
                                $scope.obj.step = 2;

                            }
                        } else {
                            showErrorInfo(data.ret_msg);

                        }
                    });
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //第二步提交身份证号
        $scope.submitSecond = function (idcardForm, idCardModel) {
            //验证身份证号是否合规
            var checkID = toolSvc.checkID(idCardModel.id_code);
            if (checkID) {
                showErrorInfo(checkID);
                return;
            }
            console.log(idCardModel);
            idCardModel = angular.extend(idCardModel, $scope.loginPwdModel);
            mineSvc.checkIdCode(idCardModel).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.obj.step = 3;
                    $scope.title = "请输入新登录密码";
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //第三步提交新登录密码
        $scope.submitThird = function (newLoginPwdForm, newLoginPwdModel) {
            console.log(newLoginPwdModel.new_pwd);
            //密码格式校验
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(newLoginPwdModel.new_pwd);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            } else {
                console.log(newLoginPwdModel);
                newLoginPwdModel.mobile = $scope.loginPwdModel.mobile;
                mineSvc.changeLoginPwd(newLoginPwdModel).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") { 
                        var setSucPopup = popupSvc.alert({
                            title: "修改成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            setSucPopup.close();
                            $rootScope.$ionicGoBack();
                            //如果从登录页进来则返回登录页
                            /*if ($stateParams.lastUrl == "login") {
                             $state.go('login');

                             } else {
                             $state.go('setting');

                             }*/

                        }, 500);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });

            }
        };
    });