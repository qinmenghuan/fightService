/**
 * Created by Z.JM on 2015/9/10.
 */
starter.factory('GestureLockService', [function () {
    return {
        getPassword: function () {
            return JSON.parse(window.localStorage.getItem('GestureLockPassword'));
        },
        setPassword: function (_password) {
            window.localStorage.setItem('GestureLockPassword', JSON.stringify(_password));
        },
        //模拟验证登录密码
        //remain_paypwd_times	剩余密码输入次数
        //pay_password_locktime	解锁时间

        'riskassess030302b': function (params, callback) {
            return {
                data: {remain_paypwd_times: 3, pay_password_locktime: "24"}
            }
        },
    };
}]);
