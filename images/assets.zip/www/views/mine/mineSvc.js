/**
 * Created by mazh on 2016/10/4.
 */
starter.factory("mineSvc",
    function (httpSvc, $http, CONSTANT, CONFIG, accountSvc) {
        return {
            //查询安全状态
            queryAccountStatus: function (params) {
                return httpSvc.post("security040101.json", params).then(function (data) {
                    return data;
                });
            },
            //设置交易密码
            setTradePwd: function (params) {
                return httpSvc.post("security040201.json", params).then(function (data) {
                    return data;
                });

            },
            //验证交易密码
            checkTradePwd: function (params) {
                return httpSvc.post("security040003.json", params).then(function (data) {
                    return data;
                });
            },
            //修改交易密码
            changeTradePwd: function (params) {
                return httpSvc.post("security040203.json", params).then(function (data) {
                    return data;
                });
            },
            //常见问题查询
            question: function (params) {
                return httpSvc.post("sys020404.json", params).then(function (data) {
                    return data;
                });
            },
            //关于我们
            aboutUs: function (params) {
                return httpSvc.post("sys020401.json", params).then(function (data) {
                    return data;
                });
            },
            //意见反馈
            feedback: function (params) {
                return httpSvc.post("feedback020201.json", params).then(function (data) {
                    return data;
                });
            },

            //查询积分
            queryIntegral: function (params) {
                return httpSvc.post("trans060601.json", params).then(function (data) {
                    return data;
                })
            },
            //查询风险等级
            queryRiskLv: function (params) {
                return httpSvc.post("security040401.json", params).then(function (data) {
                    return data;
                });
            },
            //查询风险题目
            queryRiskList: function (params) {
                return httpSvc.post("sys020407.json", params).then(function (data) {
                    return data;
                });
            },
            //退出登录
            quit: function (params) {
                return httpSvc.post("user030004.json", params).then(function (data) {
                    return data;
                })
            },
            //绑定银行卡列表查询
            queryBankCardList: function (params) {
                return httpSvc.post("bank040501.json", params).then(function (data) {
                    console.log(data);
                    return data;
                });
            },
            //绑卡
            addBankCard: function (params) {
                return httpSvc.post("bank040505.json", params).then(function (data) {
                    return data;
                });
            },
            //解绑银行卡
            removeBandBankCard: function (params) {
                return httpSvc.post("bank040503.json", params).then(function (data) {
                    return data;
                });
            },
            //验卡
            verifyCard: function (params) {
                return httpSvc.post("bank040505.json", params).then(function (data) {
                    return data;
                });
            },
            //提交风评答案
            submitRisk: function (params) {
                return httpSvc.post("security040402.json", params).then(function (data) {
                    return data;
                });
            },
            //更换手机号
            changeMobile: function (params) {
                return httpSvc.post("user030101.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //验证验证码
            checkCode: function (params) {
                return httpSvc.post("security040001.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //验证身份证号
            checkIdCode: function (params) {
                return httpSvc.post("security040002.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //修改登录密码

            changeLoginPwd: function (params) {
                return httpSvc.post("security040202.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //查询卡bin
            queryBin: function (params) {
                return httpSvc.post("bank040506.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //查询银行卡列表
            queryBankList: function (params) {
                return httpSvc.post("bank040501.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //验证银行卡信息(本地)
            checkCard: function (params) {
                return httpSvc.post("bank040504.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //验证银行卡信息（三方）
            checkCard2: function (params) {
                return httpSvc.post("bank040509.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //实名认证
            realAu: function (params) {
                return httpSvc.post("security040102.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //查询我的数据
            queryMine: function (params) {
                return httpSvc.post("prod050402.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //预约风评查询
            orderSearch: function (params) {
                return httpSvc.post("security040403.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //预约风评
            order: function (params) {
                return httpSvc.post("security040404.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //取消预约风评
            cancelOrder: function (params) {
                return httpSvc.post("security040405.json", params).then(function (data) {
                        return data;
                    }
                )
            },
            //验证是否已实名
            isRealName: function (params) {
                return httpSvc.post("user030001.json", params).then(function (data) {
                    return data;
                });
            },
            //获取服务器随机数
            getRandom: function (params) {
                return httpSvc.post("pub010401.json", params).then(function (data) {
                    return data;
                });
            },
            //获取公钥
            getDiyKey: function (params) {
                return httpSvc.post("pub010402.json", params).then(function (data) {
                    return data;
                });
            }
        }
    });