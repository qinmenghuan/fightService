/**
 * Created by mazh on 16/9/18.
 */
starter.controller("fixedAssetsOutCtrl",
    function ($rootScope, $scope, $state, assetsSvc, temporarySvc, $q, $filter, keyboardSvc, popupSvc, mineSvc, investSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p3'); //来自 fixedAssetsDetail
        // {store_date, prod_code, prod_name, term_no, acct_no, card_no, collect_amt}
        console.log(params);

        var swiperPromise, kid, action, encryptedInputValue, SWIPER;
        $scope.showRateBox = false;
        $scope.txtBtnState = false;
        $scope.conf = {
            bankcard_id:params.bankcard_id,
            out_amt: '',
            card_no: params.card_no,
            prod_code: params.prod_code,
            fix_draw_type: params.fix_draw_type,// 支取方式 0-不允许 1-部分提取 2-全部提取
            collect_amt: params.collect_amt,//待收本金
            min_hold_amt: params.min_hold_amt,//最低持有金额
            max_out_amt: params.collect_amt - params.min_hold_amt,//最多可支取金额
            card_level: '',//卡级别
            day: $filter("diffDate")(params.now_date, params.store_date),   //已存天数
            rateMoney: '',
            rateBank: ''
        };
        console.log($scope.conf);
        $scope.conf.max_day = params.inc_due - $scope.conf.day; //剩余天数

        //获取卡级别  删除card_no ,添加bankcard_id
        // assetsSvc.getBandCardDetails({card_no: $scope.conf.card_no,bankcard_id:$scope.conf.bankcard_id
        assetsSvc.getBandCardDetails({bankcard_id:$scope.conf.bankcard_id
        }).then(function (data) {
            console.log(data);
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            } else {
                $scope.conf.card_level = data.card_level;
                //如果支取方式为全部支取。直接获取利率
                if ($scope.conf.fix_draw_type == "2") {
                    $scope.conf.out_amt = $scope.conf.collect_amt;
                    getRate();
                    return;
                }
            }
        });
        //获取试算利率
        var getRate = function () {
            //请求
            var data1 = {
                prod_code: $scope.conf.prod_code,
                znck_trlday: $scope.conf.day + '',
                znck_trlamt: $scope.conf.out_amt,
                znck_cstlvl: $scope.conf.card_level
            };
            var data2 = {
                prod_code: $scope.conf.prod_code,
                znck_trlday: params.inc_due + '',
                //znck_trlamt:params.collect_amt,
                znck_trlamt: $scope.conf.out_amt,
                znck_cstlvl: $scope.conf.card_level
            };
            //试算当前支取，可获收益
            investSvc.timeDepositCounter(data1).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.conf.rateMoney = data.trl_intamt;
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
            //试算到期支取，可获收益
            investSvc.timeDepositCounter(data2).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.conf.rateMoneyEnd = data.trl_intamt;
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        }

        //编辑金额过程中，不显示利率区域
        $scope.hideRate = function () {
            $scope.showRateBox = false;
        };
        //试算--接口暂无，需要发送金额，获取当前收益及到期收益。
        $scope.showRate = function () {
            console.log($scope.conf.out_amt);
            console.log($scope.conf.max_out_amt);
            if (!Number($scope.conf.out_amt)) {
                showErrorInfo("请输入大于0的金额");
                return;
            }
            if (Number($scope.conf.out_amt) > Number($scope.conf.max_out_amt)) {
                showErrorInfo("取出金额不可高于可支取金额" + $scope.conf.max_out_amt + "元");
                return;
            }
            getRate($scope.conf.out_amt);
            $scope.showRateBox = true;
        };

        $scope.goNext = function () {
            assetsSvc.fixedAssetsOut({
                bankcard_id:params.bankcard_id,
                prod_code: params.prod_code,
                card_no: params.card_no,
                acct_no: params.acct_no,
                term_no: params.term_no,
                out_amt: $scope.conf.out_amt
            }).then(function (data) {
                if (data && data.ret_code == '0000') {
                    console.log(data);
                    temporarySvc.set("p4", {
                        out_amt: $scope.conf.out_amt,
                        rate_amt: $scope.conf.rateMoney,
                        now_date: data.now_date
                    });
                    $state.go('outSuc');
                } else {
                    showErrorInfo(data.ret_msg);
                }
            })
            /*action = popupSvc.action({
             templateUrl: "public/tpl/keyboardTpl.html",
             scope: $scope
             });
             action.deferred.promise.then(function () {
             swiperPromise = keyboardSvc.showKeyboardModal({
             onSlideChangeEnd: function (swiper) {
             SWIPER = swiper;
             if (SWIPER.activeIndex === 2) {
             $timeout(function () {
             keyboardSvc.hideKeyboardModal();
             }, 1000)
             }
             },
             hideModalCallback: hideModalCallback
             });
             });*/
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };
        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            swiperPromise.then(function (swiper) {
                SWIPER = swiper;
                SWIPER.slideNext();
                var data = {
                    pwd_type: "T",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom(),
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: 'C'
                };
                return mineSvc.checkTradePwd(data);
            })
                .then(function (data) {
                    if (data.ret_code == '0000') {
                        //trans060205.json
                        return assetsSvc.fixedAssetsOut({
                            prod_code: params.prod_code,
                            card_no: params.card_no,
                            acct_no: params.acct_no,
                            term_no: params.term_no,
                            out_amt: $scope.conf.out_amt
                        });
                    } else {
                        // SWIPER.slideNext();
                    }
                })
                .then(function (data) {
                    SWIPER.slideNext();
                    if (data && data.ret_code == '0000') {
                        $state.go('outSuc', {
                            data: {
                                out_amt: $scope.conf.out_amt,
                                rate_amt: ($scope.conf.rate * $scope.conf.day * $scope.conf.out_amt + '').toFixed(2),
                                now_date: data.now_date
                            }
                        });
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

    });