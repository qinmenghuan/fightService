/**
 * Created by admin on 2016/9/19.
 */
starter.controller('fixedAssetsListCtrl',
    function ($scope, $state, assetsSvc, temporarySvc, $q, $filter, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p1');    //从上个页面 revocableAssets 获取产品代码
        console.log(params);
        // { prod_code, prod_name, get_profit_total, collect_amt_total }

        $scope.conf = {
            hasData: true,
            prod_name: params.prod_name,
            get_profit_total: params.get_profit_total,
            collect_amt_total: params.collect_amt_total
        };
        $scope.items = [];

        var opts = {
            prod_code: params.prod_code,
            page: '0',
            rows: '10'
        };

        var get = function () {
            var def = $q.defer();
            opts.page = +opts.page + 1 + '';

            assetsSvc.getZNCKDepositUserList(opts).then(function (data) {
                console.log(data);
                if (data.ret_code !== '0000') {
                    $scope.conf.hasData = false;
                    showErrorInfo(data.ret_msg);
                    return;
                }
                data.list.forEach(function (list) {
                    list.date = Number(list.inc_due) - $filter("diffDate")(list.now_date, list.store_date) + '';
                });
                $scope.conf.get_profit_total = data.get_profit_total || 0;
                //$scope.conf.collect_amt_total = data.collect_amt_total || 0;
                $scope.items = $scope.items.concat(data.list);
                def.resolve(1);
            });

            return def.promise;
        };

        get();

        $scope.loadMoreData = function () {
            get().then(function () {
                console.log(1);
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        };
        $scope.queryDetails = function () {
            // 暂时不做
            /*temporarySvc.set('p2', {
             prod_code : params.prod_code,
             trans_type : ''
             });
             $state.go('fixedAssetsInfo');*/
        };
        $scope.goTrade = function (item) {
            temporarySvc.set('p2', {
                prod_code: params.prod_code,
                prod_name: params.prod_name,
                term_no: item.term_no,
                card_no: item.card_no,
                get_profit: item.get_profit,
                now_date: item.now_date,
                store_date: item.store_date,
                collect_amt: item.collect_amt,
                // acct_no: item.acct_no,
                bankcard_id: item.bankcard_id,
                inc_due: item.inc_due,
                date: item.date
            });
            $state.go('fixedAssetsDetail');
        };

    });

