/**
 * Created by admin on 2016/9/19.
 */
starter.controller('fixedAssetsDetailCtrl',
    function ($scope, $rootScope, $state, temporarySvc, assetsSvc, $filter) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p2');
        console.log(params);
        // 来自 fixedAssetsList
        // {prod_code, prod_name, term_no, card_no, acct_no, inc_due, get_profit, collect_amt, store_date, collect_amt, date}
        $scope.conf = {
            hasNetWork: false,
            get_profit: params.get_profit,
            collect_amt: params.collect_amt,
            left_draw_times: '-1',
            fix_draw_type: '',
            prod_name: params.prod_name,
            date: params.date,
            min_hold_amt: ''
        };

        assetsSvc.getZNCKDepositTakeOutList(params).then(function (data) {
            console.log(data);
            if (data.ret_code == '0000') {
                $scope.conf.hasNetWork = true;
                $scope.conf.left_draw_times = +data.left_draw_times;
                $scope.conf.min_hold_amt = data.min_hold_amt;
                $scope.conf.fix_draw_type = data.fix_draw_type;
                $scope.items = data.list;
            } else {
                showErrorInfo(data.ret_msg);
            }

        });

        $scope.takeOut = function () {
            //跳转 智能存支取
            temporarySvc.set('p3', {
                now_date: params.now_date,
                store_date: params.store_date,
                prod_code: params.prod_code,
                prod_name: params.prod_name,
                term_no: params.term_no,
                card_no: params.card_no,
                bankcard_id: params.bankcard_id,
                // acct_no: params.acct_no,
                inc_due: params.inc_due,
                collect_amt: params.collect_amt,
                min_hold_amt: $scope.conf.min_hold_amt,
                fix_draw_type: $scope.conf.fix_draw_type
            });
            $state.go('fixedAssetsOut');
        };
    });
