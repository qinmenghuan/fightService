/**
 * Created by mazh on 16/9/18.
 */
starter.controller("outSucCtrl",
    function ($scope, $state, $stateParams, $ionicHistory, temporarySvc, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //from fixedAssetsOut
        // { out_amt, rate_amt, now_date }
        console.log($stateParams);
        var params = temporarySvc.get("p4");
        $scope.conf = {
            out_amt: params.out_amt || '0',
            rate_amt: params.rate_amt || '0',
            now_date: params.now_date
        };
        $scope.$ionicGoBack = function () {
            $ionicHistory.goBack(-4);
        };
    });