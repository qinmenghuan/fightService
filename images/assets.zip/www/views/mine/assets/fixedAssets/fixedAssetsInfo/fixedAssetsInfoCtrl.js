/**
 * Created by admin on 2016/9/19.
 */
starter.controller('fixedAssetsInfoCtrl',
    function ($scope, $state, assetsSvc, temporarySvc, $q, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p2');
        console.log(params);

        params = {
            prod_code: params.prod_code,
            trans_type: ''
        };
        $scope.select = '03';
        $scope.changeType = function (flag) {
            console.log(flag);
            $scope.select = flag;
        };

    });
