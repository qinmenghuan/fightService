/**
 * Created by admin on 2016/9/19.
 */
starter.controller('checkBranchCtrl',
    function ($scope, homeSvc, $stateParams, CONFIG, $cordovaGeolocation, assetsSvc, mapSvc, $rootScope) {
        //var webSiteType = $stateParams.params;
        var webSiteType = $stateParams.params ? $stateParams.params : "201610151910597532129920";
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //获取经纬度
        $scope.myLocation = [];
        /* if(!CONFIG.DEBUG_ON_CHROME){
         $cordovaGeolocation
         .getCurrentPosition({timeout: 3000, enableHighAccuracy: true})
         .then(function (position) {
         console.log(position);
         $scope.myLocation.long = position.coords.longitude;
         $scope.myLocation.lat = position.coords.latitude;
         }, function (err) {
         });
         }*/

        $scope.onComplete = function (data) {
            $scope.myLocation = data;
            console.log($scope.myLocation);
            assetsSvc.getChangeSite({goods_id: webSiteType}).then(function (data) {
                console.log(data);
                if (data.ret_code === "0000") {
                    $scope.arrList = data.merchant_list;
                    data.merchant_list.map(function (item, index) {
                        if ($scope.myLocation) {
                            item.distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance([item.longitude, item.latitude]).toFixed(0);
                            item.distanceNum = parseInt(item.distance);
                        }
                    });
                    $scope.selectList = data.merchant_list;
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //调用mapSvc服务初始化地图
        mapSvc.init('map', $scope.onComplete);
    }
);
