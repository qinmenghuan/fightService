/**
 * Created by admin on 2016/9/19.
 */
starter.controller('exchangeRecordCtrl',
    function ($scope, $state, assetsSvc, CONFIG, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        $scope.currentPage = 1;  //当前页
        $scope.pagerows = 10;     //每页数量
        $scope.exchangeRecord = [];   //兑换记录列表
        $scope.getData = function () {
            assetsSvc.exchangeRecord({page: $scope.currentPage + "", rows: $scope.pagerows + ""}).then(function (data) {
                $scope.exchangeRecord = $scope.exchangeRecord.concat(data.integral_list);
                for (var i = 0; i < $scope.exchangeRecord.length; i++) {
                    $scope.exchangeRecord[i].src = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.exchangeRecord[i].pic_url_id;
                }
                $scope.$broadcast('scroll.infiniteScrollComplete');
            })
        };
        $scope.loadMore = function () {
            $scope.currentPage++;
            $scope.getData();
        };
        $scope.getData();
        $scope.read = function (item) {
            $state.go("checkOrder", {order_serno: item.order_serno})
        };
    }
);
