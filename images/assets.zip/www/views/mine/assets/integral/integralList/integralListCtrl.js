/**
 * Created by admin on 2016/9/19.
 */
starter.controller('integralListCtrl',
    function ($scope,
              $rootScope,
              $state,
              assetsSvc,
              $stateParams,
              encryptSvc,
              CONSTANT,
              CONFIG,
              resourceSvc,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //从缓存获取积分规则
        $scope.params = resourceSvc.getLocalObj(CONSTANT.PARAMS);
        console.log($scope.params);
        $scope.params.forEach(function (e) {
            if (e.paraid == "12002") {
                console.log(e);
                $scope.scale = parseFloat(e.paravalue);
            }
        });

        //获取传递过来的数据
        var p1 = temporarySvc.get("p1");
        $scope.conf = {};
        angular.extend($scope.conf, p1);

        //$scope.conf = {
        //    //可用积分=惠生活积分+其他积分
        //    totalIntegral: parseInt(p1.hui_jifn) + parseInt(p1.other_jifn)
        //};

        //点击列表item
        $scope.read = function (item) {
            temporarySvc.set('integralItem', item);
            $state.go("integralDetail");
        };

        $scope.currentPage = 1;  //当前页
        $scope.pagerows = 10;     //每页数量
        $scope.integral = []       //积分商品列表
        $scope.getData = function () {
            assetsSvc.integralProList({
                page: $scope.currentPage + "",
                pagerows: $scope.pagerows + ""
            }).then(function (data) {
                if (data.ret_code == "0000") {
                    $scope.integral = $scope.integral.concat(data.goodssales_list);
                    for (var i = 0; i < $scope.integral.length; i++) {
                        $scope.integral[i].src = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.integral[i].goods_cover_url;
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                } else {
                    showErrorInfo(data.ret_msg);
                }
            })
        };
        $scope.loadMore = function () {
            $scope.currentPage++;
            $scope.getData();
        };
        $scope.getData();
    }
);
