/**
 * Created by admin on 2016/9/19.
 */
starter.controller('selectAddressCtrl',
    function ($scope){

    }
);
