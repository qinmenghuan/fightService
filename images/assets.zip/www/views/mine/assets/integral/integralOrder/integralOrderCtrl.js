/**
 * Created by admin on 2016/9/19.
 */
starter.controller('integralOrderCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              assetsSvc,
              homeSvc,
              resourceSvc,
              CONSTANT,
              popupSvc,
              $timeout,
              keyboardSvc,
              mineSvc,
              mapSvc,
              pageJumpSvc,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //从缓存获取积分规则
        $scope.params = resourceSvc.getLocalObj(CONSTANT.PARAMS);
        $scope.params.forEach(function (e) {
            if (e.paraid == "12002") {
                $scope.scale = parseFloat(e.paravalue);
            }
        });
        $scope.orderInfo = temporarySvc.get('integralOrder') || {};
        //查询积分金额
        assetsSvc.queryIntegral().then(function (data) {
            if (data.ret_code == '0000') {
                $scope.total_jifen = parseFloat(data.other_jifn) + parseFloat(data.hui_jifn);
                console.log('可用积分', $scope.total_jifen);
                console.log('所需积分', $scope.orderInfo.market_price * $scope.scale * $scope.orderInfo.num);
                if ($scope.orderInfo.market_price * $scope.scale * $scope.orderInfo.num > $scope.total_jifen) {
                    $scope.ifOrder = false;
                    $scope.text = '积分余额不足';
                } else {
                    //未设置交易密码不可能有积分，故取消该判断
                    ////查询是否设置交易密码
                    //mineSvc.queryAccountStatus().then(function (data) {
                    //    console.log('@@@', data);
                    //    if (data.ret_code == "0000") {
                    //        $scope.ifTradPwd = data.acctstep_list[0].flag;
                    //        if ($scope.ifTradPwd == 1) {
                    //            $scope.ifOrder = true;
                    //            $scope.text = '立即兑换';
                    //        } else if ($scope.ifTradPwd == 0) {
                    //            $scope.ifOrder = true;
                    //            $scope.text = '安全认证';
                    //        }
                    //    } else {
                    //        showErrorInfo(data.ret_msg);
                    //    }
                    //});
                    $scope.ifOrder = true;
                    $scope.text = '立即兑换';
                }
            } else {
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.sendType = "0";
        var swiperPromise, kid, action, openDetail, openChangeCard, encryptedInputValue;
        //默认不显示 '查看更多自提网点'
        $scope.netWorkMoreThen2 = false;

        $scope.onComplete = function (data) {
            $scope.myLocation = data;
            console.log($scope.myLocation);

            $scope.arrList = $scope.orderInfo.merchant_list;
            $scope.arrList.map(function (item, index) {
                if ($scope.myLocation) {
                    item.distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance([item.longitude, item.latitude]).toFixed(0);
                    item.distanceNum = parseInt(item.distance);
                    console.log($scope.myLocation)
                }
            });

            if ($scope.arrList.length <= 2) {
                //当查询出附近网店数量小于等于二
                $scope.selectList = $scope.arrList;
            } else {
                //大于二时默认显示两个
                $scope.netWorkMoreThen2 = true;
                $scope.selectList = $scope.arrList.slice(0, 2);  //保存数组前两个
            }

            console.log('selectList', $scope.selectList);
        };
        mapSvc.init('map', $scope.onComplete);

        //点击查看更多网点
        $scope.viewMoreText = true;
        $scope.viewMoreNetWork = function () {
            if ($scope.viewMoreText) {
                $scope.viewMoreText = false;
                $scope.selectList = $scope.arrList;
            } else {
                $scope.viewMoreText = true;
                $scope.selectList = $scope.tempArr;
            }
        };

        //点击确认兑换按钮
        //$scope.sureExchange = function () {
        //    $scope.orderInfo.trans_no = $scope.orderInfo.num;
        //    $scope.orderInfo.total_integral = $scope.orderInfo.market_price * $scope.scale * $scope.orderInfo.num;
        //    $scope.orderInfo.delivery_way = '1';
        //    assetsSvc.integralExchangePro($scope.orderInfo).then(function (data) {
        //
        //    })
        //};
        $scope.sureExchange = function () {
            $scope.keyboardMsg = "兑换成功";
            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        if (swiper.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal('kid');
                            }, 1000)
                        }
                    },
                    //hideModalCallback: hideModalCallback
                });
            });
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };

        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            if (encryptedInputValue.errorCode == CFCA_OK) {
                $rootScope.tip = false;
                $scope.errorText = "";
                swiperPromise.then(function (swiper) {
                    swiper.slideNext();
                    var data = {
                        pwd_type: "T",
                        client_random: encryptedInputValue.encryptedClientRandom,
                        server_random: keyboardSvc.getServerRandom(),
                        new_pwd: encryptedInputValue.encryptedInputValue,
                        keyboard_type: 'C'
                    };


                    mineSvc.checkTradePwd(data).then(function (data) {
                        if (data.ret_code == '0000') {
                            $scope.orderInfo.trans_no = $scope.orderInfo.num.toFixed(2);
                            $scope.orderInfo.total_integral = ($scope.orderInfo.market_price * $scope.scale * $scope.orderInfo.num).toFixed(2);
                            $scope.orderInfo.delivery_way = '1';
                            assetsSvc.integralExchangePro($scope.orderInfo).then(function (data) {
                                if (data.ret_code == '0000') {
                                    console.log('asdasdasdadsad', data);
                                    swiper.slideNext();
                                    setTimeout(function () {
                                        $state.go("checkOrder", {order_serno: data.order_serno});
                                        pageJumpSvc.nextPageGoBack({
                                            nextState: "checkOrder",
                                            currentState: "integralOrder",
                                            goBack: -3
                                        })
                                    }, 1000);
                                } else {
                                    action.close();
                                    var errorPopup = popupSvc.alert({
                                        title: data.ret_msg,
                                        cssClass: "popup-container",
                                        buttons: []
                                    });
                                    $timeout(function () {
                                        errorPopup.close();
                                    }, 2000);
                                }
                            })
                        } else {
                            action.close();
                            var errorPopup = popupSvc.alert({
                                title: data.ret_msg,
                                cssClass: "popup-container",
                                buttons: []
                            });
                            $timeout(function () {
                                errorPopup.close();
                            }, 2000);
                        }
                    });

                });
            } else {
                $rootScope.tip = true;
                $scope.errorText = "请输入6位数字的密码";
            }
            // encryptedInputValue = keyboardSvc.getEncrypt(id);
            // console.info("加密输入数据:", encryptedInputValue);
        };

        function hideModalCallback() {
            keyboardSvc.clear('kid');
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

    }
);
