/**
 * Created by admin on 2016/9/19.
 */
starter.controller('checkOrderCtrl',
    function ($scope,$rootScope, $stateParams,assetsSvc,resourceSvc,CONSTANT,CONFIG,popupSvc){
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //从缓存获取积分规则
        $scope.params = resourceSvc.getLocalObj(CONSTANT.PARAMS);
        $scope.params.forEach(function (e) {
            if (e.paraid == "12002") {
                $scope.scale = parseFloat(e.paravalue);
            }
        });
        $scope.orderInfo = $stateParams.params;
        console.log($scope.orderInfo);

        console.log($stateParams.order_serno);
        //查询兑换记录详情
        assetsSvc.exchangeRecordDetail({order_serno:$stateParams.order_serno}).then(function(data){
            console.log(data);
            if(data.ret_code == '0000'){
                $scope.goods_info=data.goods_info;
                $scope.integral_list=data.integral_list[0];
                //生成二维码
                $('#qrcodeCanvas').html("");
                $("#qrcodeCanvas").qrcode({
                    render : "canvas",    //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
                    text : $scope.integral_list.redeem_code,    //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
                    width : "240",               //二维码的宽度
                    height : "240",              //二维码的高度
                    background : "#ffffff",       //二维码的后景色
                    foreground : "#000000",        //二维码的前景色
                    src: 'images/logo.png'         //二维码中间的图片
                });
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
        //点击放大二维码
        $scope.showQrcode = function () {
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
        //点击放大二维码
        //$scope.showQrcode = function () {
        //    popupSvc.alert({
        //        templateUrl: "views/home/dialog/qrcode.html",
        //        scope: $scope,
        //        cssClass: "qrcode-show",
        //        closeByDocument: true
        //    })
        //};
    }
);
