/**
 * Created by admin on 2016/9/19.
 */
starter.controller('integralDetailCtrl',
    function ($scope, $state, $stateParams, assetsSvc, resourceSvc, CONSTANT, CONFIG, temporarySvc, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //从缓存获取积分规则
        $scope.params = resourceSvc.getLocalObj(CONSTANT.PARAMS);
        $scope.params.forEach(function (e) {
            if (e.paraid == "12002") {
                $scope.scale = parseFloat(e.paravalue);
            }
        });
        var info = temporarySvc.get('integralItem') || {};
        assetsSvc.integralProDetail({goods_id: info.goods_id}).then(function (data) {
            if (data.ret_code == '0000') {
                $scope.goods = data.goods_info;
                $scope.goods.src = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + data.goods_info.goods_cover_url;
                $scope.merchant_list = data.merchant_list;
            }else {
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.item = {
            number: 1
        };

        $scope.minus = function () {
            if ($scope.item.number != 1) {
                $scope.item.number -= 1;
            }
        };
        $scope.plus = function () {
            $scope.item.number += 1;
        };
        $scope.order = function (goods, num) {
            console.log(goods);
            var params = angular.extend({num: num}, goods, {merchant_list: $scope.merchant_list});
            temporarySvc.set('integralOrder', params);
            $state.go("integralOrder");
        }
    }
);
