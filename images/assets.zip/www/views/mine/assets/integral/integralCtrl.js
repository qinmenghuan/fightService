/**
 * Created by admin on 2016/9/19.
 */
starter.controller('integralCtrl',
    function ($scope,
              $rootScope,
              $stateParams,
              resourceSvc,
              CONSTANT,
              CONFIG,
              assetsSvc,
              $state,
              temporarySvc,
              homeSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //根据来源返回不同页面（因为购买积分商品成功后一直返回到这里会死循环）
        /*$scope.integralBack=function(){
         if($stateParams.lastUrl=='home'){
         $state.go('home')
         }else{
         $state.go('assets')
         }
         };*/
        //查询系统参数，获取积分规则
        homeSvc.getParams().then(function (data) {
            if (data.ret_code === "0000") {
                resourceSvc.setLocal(CONSTANT.PARAMS, data.parameterlist);
                $scope.params = data.parameterlist;
                console.log($scope.params);
                $scope.params.forEach(function (e) {
                    if (e.paraid == "12002") {
                        console.log(e);
                        $scope.scale = parseFloat(e.paravalue);
                    }
                });
                console.log($scope.scale);
            } else {
                return showErrorInfo(data.ret_msg);
            }
        });

        //积分帮助
        $scope.goHelp = function () {
            $state.go('lifeQuestion', {type: '账号·积分问题'});

        };
        //初始化数据
        $scope.conf = {
            hui_jifn: "0",//惠生活积分
            other_jifn: "0"//其他积分
        };
        //查询积分金额
        assetsSvc.queryIntegral().then(function (data) {
            if (data.ret_code == '0000') {
                $scope.conf = data;
            } else {
                showErrorInfo(data.ret_msg);
            }
        });
        //初始化最新最热积分商品
        $scope.goodssales_list = [];
        $scope.goodstime_list = [];
        //查询积分列表
        assetsSvc.integralProList({
            page: "1",
            pagerows: "2"
        }).then(function (data) {

            if (data.ret_code == '0000') {
                console.log('@@@', data);
                $scope.goodssales_list = data.goodssales_list;
                $scope.goodstime_list = data.goodstime_list;
                for (var i = 0; i < $scope.goodssales_list.length; i++) {
                    $scope.goodssales_list[i].src = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.goodssales_list[i].goods_cover_url;
                }
                for (var i = 0; i < $scope.goodstime_list.length; i++) {
                    $scope.goodstime_list[i].src = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.goodstime_list[i].goods_cover_url;
                }
            } else {
                showErrorInfo(data.ret_msg);
            }
        });
        //去积分列表
        $scope.integralList = function () {
            if ($scope.conf) {
                temporarySvc.set('p1', {hui_jifn: $scope.conf.hui_jifn, other_jifn: $scope.conf.other_jifn})
                $state.go('integralList');
            }
        };
        //去积分详情
        $scope.read = function (item) {
            temporarySvc.set('integralItem', item);
            $state.go("integralDetail");
        };
    }
);
