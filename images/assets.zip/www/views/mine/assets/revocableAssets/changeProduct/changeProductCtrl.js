/**
 * Created by admin on 2016/9/19.
 */
starter.controller('changeProductCtrl',
    function ($scope, $state, investSvc, temporarySvc, assetsSvc, $ionicScrollDelegate, $q, keyboardSvc, popupSvc, mineSvc, $timeout, $ionicHistory, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p2');
        console.log(params);
        // product_no, product_name, card_no, acct_no, sign_orgno
        var opt = {
            page: '0',
            rows: '10'
        };
        var firstLoad = true;
        var swiperPromise, kid, swiper, action, encryptedInputValue;
        $scope.conf = {
            hasData: false,
            input: false,
            inputCheck: -1
        };
        $scope.items = [];

        $scope.check = function (index) {
            $scope.items.forEach(function (item, i) {
                item.checked = index === i ? true : false;
            });
            $scope.conf.inputCheck = index;
        };

        $scope.loadData = function () {
            get().then(function () {
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        };

        $scope.submit = function () {
            popupSvc.alert({
                title: "变更产品后，将按照新的产品的计息规则开始重新开始计息。原产品未结息收益将会转入您的活期账户中。是否确认变更？",
                cssClass: "popup-container",
                buttons: [
                    {
                        text: '<b>确定</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            queryPwd();
                        }
                    },
                    {text: '取消'}
                ]
            });
        };

        var get = function () {
            var def = $q.defer();
            opt.page = +opt.page + 1 + '';
            //prod050201.json
            investSvc.demandDepositList(opt).then(function (data) {
                if (data) {
                    $scope.conf.hasData = true;
                    $scope.items = $scope.items.concat(data.prod_list);
                    if (firstLoad) {
                        firstLoad = false;
                        $scope.items[0].checked = true;
                    }
                    def.resolve(1);
                } else {
                    $scope.conf.hasData = false;
                }
            });
            return def.promise;
        };
        var queryPwd = function () {
            $scope.keyboardMsg = "变更成功";
            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        SWIPER = swiper;
                        if (SWIPER.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal();
                            }, 1000)
                        }
                    },
                    hideModalCallback: hideModalCallback
                });
            });
        };

        $scope.hideKeyboardModal = function () {
            action.close();
        };
        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            swiperPromise.then(function (swiper) {
                SWIPER = swiper;
                SWIPER.slideNext();
                var data = {
                    pwd_type: "T",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom(),
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: 'C'
                };
                return mineSvc.checkTradePwd(data);
            }).then(function (data) {
                    if (data.ret_code == '0000') {
                        //trans060205.json
                        var item = $scope.items[$scope.conf.inputCheck];
                        return assetsSvc.changeProduct({
                            prod_code: item.product_no,
                            prod_name: item.prod_name,
                            bankcard_id: params.bankcard_id,
                            // card_no: params.card_no,
                            // acct_no: params.acct_no,
                            sign_orgno: params.sign_orgno
                            // sign_teller: '1',
                        });
                    } else {
                        showErrorInfo(data.ret_msg);
                        // swiper.slideNext();
                    }
                })
                .then(function (data) {
                    if (data && data.ret_code === '0000') {
                        SWIPER.slideNext();
                        $timeout(function () {
                            $ionicHistory.goBack(-4);
                        }, 1000);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }

        get();
    });
