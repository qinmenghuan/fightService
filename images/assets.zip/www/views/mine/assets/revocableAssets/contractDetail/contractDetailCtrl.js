/**
 * Created by admin on 2016/9/19.
 */
starter.controller('contractDetailCtrl',
    function ($scope, $state, temporarySvc, assetsSvc, $rootScope,encryptSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p1');
        console.log("船只1：",params);
        var opts = {
            page: '0'
        };

        var get = function () {
            opts.page = +opts.page + 1 + '';
            assetsSvc.getZNCKCurrentProfit(opts).then(function (data) {
                if (data.ret_code !== '0000'){
                    showErrorInfo(data.ret_msg);
                    return;
                } 
                $scope.conf.get_profit_total = data.get_profit_total;
                $scope.items = $scope.items.concat(data.list);
            });
        };

        // 配置卡信息12
       // $scope.conf.bank_name =  params.card_info.bank_name;
       //  $scope.conf.sub_branch_name=params.card_info.sub_branch_name;
       //  $scope.conf.card_no=params.card_no;

        // encryptSvc.then(function (encrypt) {
        //     console.log("界112面：",params.card_info.card_no);
        //     var gesturePwd = encrypt.aesDeLocal(params.card_info.card_no);
        //     console.log("界面：",gesturePwd);
        // });
        //跳转设置手势密码页面，设置完成后 改变isFirst属性 为false
        // var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
        // var user_id = userInfo.query("user_id");
        // //var resEnLocalTemp = resourceSvc.localTemp("gesture");
        // var gesturePwd = encrypt.aesDeObjectL(user_id + "gesturePwd");

        // 获得单个卡的详情   改成从前面传古来
        // assetsSvc.getBandCardDetails({card_no: params.card_no}).then(function (data) {
        //     $scope.conf.bank_name = data.bank_name;
        //     $scope.conf.sub_branch_name = data.sub_branch_name;
        //     $scope.conf.card_no = data.card_no;
        // });

        $scope.items = [];
        $scope.conf = {
            get_profit: params.get_profit,
            card_no: params.card_no,
            income_max: params.income_max,
            product_term: params.product_term,
            deposit_sum: params.deposit_sum,
            keep_balance: params.keep_balance,
            product_name:params.product_name,
            bank_name:params.card_info.bank_name,
            sub_branch_name:params.card_info.sub_branch_name,
        };
        $scope.goCancel = function () {
            //跳转解约
            temporarySvc.set('p2', {
                bankcard_id:params.card_info.bankcard_id,
                prod_code: params.product_no,
                prod_name: params.product_name,
                card_no: params.card_no,
                // acct_no: $scope.conf.acct_no,
                sign_date: params.sign_date,
                sign_orgno: params.sign_orgno,
                cancel_profit: params.cancel_profit,   //解约可获收益
                income_max: params.income_max,
                deposit_sum:params.deposit_sum
            });
            $state.go('revocableAssetsCancel')
        };
        $scope.goChangeProduct = function () {
            //更变成品
            temporarySvc.set('p2', {
                bankcard_id:params.card_info.bankcard_id,
                prod_code: params.product_no,
                prod_name: params.product_name,
                card_no: params.card_no,
                // acct_no: $scope.conf.acct_no,
                sign_orgno: params.sign_orgno  //签约机构代码
            });
            $state.go('changeProduct')
        };
    });

