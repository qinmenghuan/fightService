/**
 * Created by admin on 2016/9/19.
 */
starter.controller('revocableAssetsCtrl',
    function ($scope, $state, assetsSvc, $ionicScrollDelegate, $q, temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var isFirstLoadCurrentData = true,
            currentOpt = {
                page: '0'
            };
        var isFirstLoadRegularData = true,
            regularOpt = {
                page: '0',
                rows: '10'
            };
        $scope.conf = {
            tab: '1',
            hasCurrentData: true,
            hasRegularData: true
        };
        if (temporarySvc.get('p1')) {
            if (temporarySvc.get('p1').tab) {
                $scope.conf.tab = temporarySvc.get('p1').tab;
            }
        }
        console.log('TAB', $scope.conf);
        var loadCurrentList = function () {
            var def = $q.defer();
            currentOpt.page = +currentOpt.page + 1 + '';
            assetsSvc.getZNCKCurrentList(currentOpt).then(function (data) {
                console.log("后台数据：",data);
                if (data.ret_code !== '0000' || data.islastpage == '1') {
                    showErrorInfo(data.ret_msg);
                    $scope.conf.hasCurrentData = false;
                    return;
                }
                $scope.current.total_vol = data.total_vol || '0';
                $scope.currentList = $scope.currentList.concat(data.list);
                return def.resolve(1);
            });
            return def.promise;
        };
        var loadRegularList = function () {
            var def = $q.defer();
            regularOpt.page = +regularOpt.page + 1 + '';
            assetsSvc.getZNCKDepositList(regularOpt).then(function (data) {
                console.log(data);
                if (data.ret_code !== '0000' || data.islastpage == '1') {
                    showErrorInfo(data.ret_msg);
                    $scope.conf.hasRegularData = false;
                    return;
                }
                $scope.regular.get_profit_total = data.get_profit_total || '0';
                $scope.regular.collect_amt_total = data.collect_amt_total || '0';
                $scope.regularList = $scope.regularList.concat(data.list);
                return def.resolve(1);
            });
            return def.promise;
        };


        //进页面首先根据历史选择tab项发不同请求
        if ($scope.conf.tab === '1' && isFirstLoadCurrentData) {
            isFirstLoadCurrentData = false;
            loadCurrentList();
        }
        if ($scope.conf.tab === '2' && isFirstLoadRegularData) {
            isFirstLoadRegularData = false;
            loadRegularList();
        }


        //活期数据
        $scope.current = {
            total_vol: '0'
        };
        $scope.currentList = [];

        //定期数据
        $scope.regular = {
            get_profit_total: '0',
            collect_amt_total: '0',
            hasData: true
        };
        $scope.regularList = [];
        $scope.tab = function (n) {
            $scope.conf.tab = n;
            if (n === '1' && isFirstLoadCurrentData) {
                isFirstLoadCurrentData = false;
                loadCurrentList();
            }
            if (n === '2' && isFirstLoadRegularData) {
                isFirstLoadRegularData = false;
                loadRegularList();
            }
        };
        $scope.goProfitDetail = function () {
            //跳转收益明细
            $state.go('profitDetail');
        };
        $scope.goCurrentDetail = function (obj) {
            if ($scope.current.total_vol === 0) return;
            console.log("明细对象12：",obj);
            obj.tab = '1'

            temporarySvc.set('p1', obj);
            $state.go('contractDetail');
        };
        $scope.goB14 = function () {
            $state.go('demandDeposit');
        };
        $scope.goRegularDetail = function (obj) {
             temporarySvc.set('p1',{
                prod_code: obj.prod_code,
                prod_name: obj.prod_name,
                get_profit_total: obj.get_profit_total,
                collect_amt_total: obj.collect_amt_total,
                tab: '2'
            });
            $state.go('fixedAssetsList');
        };

        $scope.loaCurrentData = function () {
            loadCurrentList().then(function (data) {
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        };
        $scope.loadRegularData = function () {
            loadRegularList().then(function (data) {
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        }
    });
