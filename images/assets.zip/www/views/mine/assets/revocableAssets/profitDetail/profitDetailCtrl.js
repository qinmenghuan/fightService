/**
 * Created by admin on 2016/9/19.
 */
starter.controller('profitDetailCtrl',
    function ($scope, $state, assetsSvc, $ionicScrollDelegate, $q, $rootScope, temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var opt = {
            page: '0'
        };
        $scope.conf = {
            get_profit_total: '0',
            hasData: false
        };
        $scope.items = [];
        var get = function () {
            var def = $q.defer();
            opt.page = +opt.page + 1 + '';
            assetsSvc.getZNCKCurrentProfit(opt).then(function (data) {
                if (data.ret_code !== '0000') {
                    showErrorInfo(data.ret_msg);
                    $scope.conf.hasData = false;
                }
                if (data.ret_code === '0000') {
                    $scope.conf.hasData = true;
                    $scope.conf.get_profit_total = data.get_profit_total;
                    $scope.items = $scope.items.concat(data.list);
                    def.resolve(1);
                }
            });
            return def.promise;
        };
        $scope.loadData = function () {
            get().then(function (data) {
                console.log(1);
                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 1000);
            });
        };

        get();
    });

