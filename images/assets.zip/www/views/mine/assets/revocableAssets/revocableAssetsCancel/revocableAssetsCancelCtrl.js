/**
 * Created by admin on 2016/9/19.
 */
starter.controller('revocableAssetsCancelCtrl',
    function ($scope, $state, assetsSvc, investSvc, $ionicScrollDelegate, $q, temporarySvc, keyboardSvc, popupSvc, mineSvc, $timeout, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p2') || {};
        // {prod_code, prod_name, card_no, acct_no, sign_date, sign_orgno, income_max }
        console.log("详细参数23：", params);

        var date = new Time();
        var swiperPromise, kid, action, encryptedInputValue, SWIPER;
        $scope.conf = angular.extend({}, params);
        $scope.conf.day = diff(date, params.sign_date);

        // 计算总天数
        //sign_date
        //var myDate=new Date();
        //console.log(myDate);

        //var days= parseInt(myDate.toLocaleDateString()) - parseInt(params.sign_date);
        // 调用试算
        var data = {
            prod_code: params.prod_code,
            znck_trlday: ($scope.conf.day - 1).toString(),
            znck_trlamt: params.deposit_sum,
            znck_cstlvl: "1"                        // 给个默认值
        };
        console.log(data);
        investSvc.demandCounter(data).then(function (data) {
            console.log("试算的结果：", data);
            if (data.ret_code == "0000") {
                // 利率
                $scope.expc_pftrate = data.expc_pftrate || 0;
                //$scope.config.rateMoney = data.trl_intamt;
                //$scope.config.rateBank = data.curr_intamt;
            } else {
                showErrorInfo(data.ret_msg);
            }
        });

        $scope.btn = function () {
            $scope.keyboardMsg = "解约成功";
            action = popupSvc.action({
                templateUrl: "public/tpl/keyboardTpl.html",
                scope: $scope
            });
            action.deferred.promise.then(function () {
                swiperPromise = keyboardSvc.showKeyboardModal({
                    onSlideChangeEnd: function (swiper) {
                        SWIPER = swiper;
                        if (SWIPER.activeIndex === 2) {
                            $timeout(function () {
                                keyboardSvc.hideKeyboardModal();
                                $state.go('mine');
                            }, 1000)
                        }
                    },
                    hideModalCallback: hideModalCallback
                });
            });
        };
        $scope.hideKeyboardModal = function () {
            action.close();
        };
        keyboardSvc.doneCallback = function (e, id) {
            kid = id;
            e.preventDefault();
            encryptedInputValue = keyboardSvc.getEncrypt(id);
            console.info("加密输入数据:", encryptedInputValue);
            swiperPromise.then(function (swiper) {
                SWIPER = swiper;
                SWIPER.slideNext();
                var data = {
                    pwd_type: "T",
                    client_random: encryptedInputValue.encryptedClientRandom,
                    server_random: keyboardSvc.getServerRandom(),
                    new_pwd: encryptedInputValue.encryptedInputValue,
                    keyboard_type: 'C'
                };
                mineSvc.checkTradePwd(data).then(function (data) {
                    if (data.ret_code == '0000') {
                        assetsSvc.revocableAssetsCancel({
                            bankcard_id: params.bankcard_id,
                            prod_code: params.prod_code,   //产品代码
                            prod_name: params.prod_name,   //产品名称
                            // card_no: params.card_no,       //银行卡号
                            // acct_no: params.acct_no,       //银行账号
                            cancel_orgno: params.sign_orgno,              //解约机构号
                            cancel_teller: '1'             //解约柜员
                        }).then(function (data) {
                            if (data.ret_code == "0000") {
                                SWIPER.slideNext();
                                $timeout(function () {
                                    temporarySvc.set('int', data);
                                    $state.go('cancelSuc');
                                }, 1000);
                            } else {
                                action.close();
                                var errorPopup = popupSvc.alert({
                                    title: data.ret_msg,
                                    cssClass: "popup-container",
                                    buttons: []
                                });
                                $timeout(function () {
                                    errorPopup.close();
                                }, 2000);
                            }
                        });
                    } else {
                        action.close();
                        var errorPopup = popupSvc.alert({
                            title: data.ret_msg,
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            errorPopup.close();
                        }, 2000);

                    }
                })
            })
        };

        function hideModalCallback() {
            keyboardSvc.clear(kid);
            swiperPromise.then(function (swiper) {
                $timeout(function () {
                    action.close();
                    swiper.slideTo(0, 0, false);
                }, 1000);
            })
        }


        function diff(d1, d2) {
            if (typeof d2 !== 'string') return 0;
            var t = new Date(Number(d2.substring(0, 4)), Number(d2.substring(4, 6)) - 1, Number(d2.substring(6, 8)));
            return Math.ceil((d1 - t) / 1000 / 60 / 60 / 24);
        }
    });
