/**
 * Created by admin on 2016/9/19.
 */
starter.controller('cancelSucCtrl', ["$scope", "$state", "temporarySvc", "assetsSvc", "$stateParams",
    function ($scope, $state, temporarySvc, assetsSvc, $stateParams) {
        var params = temporarySvc.get('int');
        $scope.conf = {
            int_amt: params.int_amt,
            int_arv_date: params.int_arv_date
        };
        $scope.$ionicGoBack = function () {
            $state.go('assets');
        };
    }
]);
