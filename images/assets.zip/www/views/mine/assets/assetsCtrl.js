/**
 * Created by mazh on 16/9/18.
 */
starter.controller("assetsCtrl", ['$scope', '$state', "$filter", "assetsSvc", "$rootScope",
    function ($scope, $state, $filter, assetsSvc, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.goBack = function () {
            $state.go('mine');
        };
        var swiper = null;
        // 在投总额图
        var myChart = echarts.init(document.getElementById('main')),
            //累计收益图
            myChart2 = echarts.init(document.getElementById('main2'));

        //当页面动画切换完毕时
        $scope.$on('$ionicView.enter', function () {
            // 指定图表的配置项和数据
            swiper = null;
            swiper = new Swiper('.banner', {
                observer: true,
                observeParents: true,
                pagination: '.banner-pagination',
                paginationClickable: true,
                loop: false,
                preventClicks: false,
                centeredSlides: true,   //设置活动块居中
                simulateTouch: false //默认为true，Swiper接受鼠标点击、拖动。
            });
        });

        $scope.conf = {
            profit: '0.00',  //收益
            capital: '0.00',    //本金
            voucher_sums: '0',    //兑换券
            integral_total: '0'   //积分
        };

        $scope.goSetting = function () {
            $state.go('setting');
        };

        $scope.$on("$destroy", function () {
            if (swiper && swiper.destroy) swiper.destroy();
        });

        assetsSvc.getAsset().then(function (data) {
            if (data.ret_code !== '0000') {
                showErrorInfo(data.ret_msg);
                return;
            }
            var capital = Number(data.fnc_amt_total || 0) + Number(data.zncktime_amt_total || 0) + '',
                profit = Number(data.fnc_income_total || 0) + Number(data.zncktime_income_total || 0) + Number(data.znckcurr_income_total || 0) + '';
            var myChartOpt = {
                fnc_amt_total: capital,
                data: [
                    {value: data.fnc_amt_total, name: '惠理财'},
                    {value: data.zncktime_amt_total, name: '智能存·定期'}
                ]
            };
            var myChartOpt2 = {
                fnc_income_total: profit,
                data: [
                    {value: data.fnc_income_total, name: '惠理财'},
                    {value: data.zncktime_income_total, name: '智能存·定期'},
                    {value: data.znckcurr_income_total, name: '智能存·活期'}
                ]
            };
            $scope.conf.capital = data.fnc_amt_total;  //惠理财在投总额
            $scope.conf.profit = data.fnc_income_total;    //惠理财累计收益
            $scope.conf.voucher_sums = data.voucher_sums;
            $scope.conf.integral_total = data.integral_total;


            var option = {
                    color: [
                        '#f39826', '#29ab91', '#f05a4a', '#32cd32', '#6495ed',
                        '#ff69b4', '#ba55d3', '#cd5c5c', '#ffa500', '#40e0d0',
                        '#1e90ff', '#ff6347', '#7b68ee', '#00fa9a', '#ffd700',
                        '#6b8e23', '#ff00ff', '#3cb371', '#b8860b', '#30e0e0'
                    ],
                    title: {
                        text: '在投总额',
                        subtext: $filter('currency')(myChartOpt.title),
                        x: 'center'
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: "{a} <br/>{b} : {c} ({d}%)"
                    },
                    calculable: true,
                    series: [
                        {
                            type: 'pie',
                            radius: ['30%', '60%'],
                            data: myChartOpt.data
                        }
                    ]
                },
                option2 = {
                    color: [
                        '#f39826', '#29ab91', '#f05a4a', '#32cd32', '#6495ed',
                        '#ff69b4', '#ba55d3', '#cd5c5c', '#ffa500', '#40e0d0',
                        '#1e90ff', '#ff6347', '#7b68ee', '#00fa9a', '#ffd700',
                        '#6b8e23', '#ff00ff', '#3cb371', '#b8860b', '#30e0e0'
                    ],
                    title: {
                        text: '累计收益',
                        subtext: $filter('currency')(myChartOpt2.title),
                        x: 'center'
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: "{a} <br/>{b} : {c} ({d}%)"
                    },
                    calculable: true,
                    series: [
                        {
                            type: 'pie',
                            radius: ['30%', '60%'],
                            data: myChartOpt2.data
                        }
                    ]
                };

            myChart.setOption(option);
            myChart2.setOption(option2);
        });

        //app.title = '环形图';
        //
        //option = {
        //    tooltip: {
        //        trigger: 'item',
        //        formatter: "{a} <br/>{b}: {c} ({d}%)"
        //    },
        //    legend: {
        //        orient: 'vertical',
        //        x: 'left',
        //        data:['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
        //    },
        //    series: [
        //        {
        //            name:'访问来源',
        //            type:'pie',
        //            radius: ['50%', '70%'],
        //            avoidLabelOverlap: false,
        //            label: {
        //                normal: {
        //                    show: false,
        //                    position: 'center'
        //                },
        //                emphasis: {
        //                    show: true,
        //                    textStyle: {
        //                        fontSize: '30',
        //                        fontWeight: 'bold'
        //                    }
        //                }
        //            },
        //            labelLine: {
        //                normal: {
        //                    show: false
        //                }
        //            },
        //            data:[
        //                {value:335, name:'直接访问'},
        //                {value:310, name:'邮件营销'},
        //                {value:234, name:'联盟广告'},
        //                {value:135, name:'视频广告'},
        //                {value:1548, name:'搜索引擎'}
        //            ]
        //        }
        //    ]
        //};
    }]);