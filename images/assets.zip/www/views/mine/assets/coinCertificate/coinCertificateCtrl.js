/**
 * Created by admin on 2016/9/20.
 */

starter.controller('coinCertificateCtrl',
    function ($scope, $state, homeSvc, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //默认显示可用兑换券
        $scope.coinStatus = true;
        $scope.coinText = "查看更多兑换券";
        //获取兑换券记录
        var rewardInfo = function () {
            homeSvc.voucherList({activity_type: "", activity_id: ""}).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.myRewardList = data.voucher_list;
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        rewardInfo();
        //读取兑换券
        $scope.read = function (item) {
            $state.go("coinCertificateDetail", {params: item})
        };
        //下拉刷新
        //$scope.doRefresh = function () {
        //    rewardInfo();
        //    $scope.$broadcast('scroll.refreshComplete');
        //};
        //切换显示可以兑换券和全部兑换卷
        $scope.switchCoinStatus = function () {
            rewardInfo();
            $scope.coinStatus = !$scope.coinStatus;
            if ($scope.coinStatus == true) {
                $scope.coinText = "查看更多兑换券";
            } else {
                $scope.coinText = "查看可兑换兑换券";
            }
        }
    });