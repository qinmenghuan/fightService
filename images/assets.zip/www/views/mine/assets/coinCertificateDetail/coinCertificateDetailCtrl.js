/**
 * Created by admin on 2016/9/20.
 */


starter.controller('coinCertificateDetailCtrl',
    function ($scope, $stateParams, popupSvc, $cordovaGeolocation, CONFIG, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.coin = $stateParams.params;
        console.log($scope.coin);
        //二维码小图
        $("#qrcode-small").qrcode({
            width: 80,
            height: 80,
            text: $scope.coin.voucher_no,
            render: "canvas",
            background: "#ffffff",
            foreground: "#000000",
        })
            .addClass("visible");

        //生成二维码
        $("#qrcodeCanvas").qrcode({
            render: "canvas",    //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
            text: $scope.coin.voucher_no,    //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
            width: "240",               //二维码的宽度
            height: "240",              //二维码的高度
            background: "#ffffff",       //二维码的后景色
            foreground: "#000000",        //二维码的前景色
            src: 'images/logo.png'             //二维码中间的图片
        });
        //点击放大二维码
        $scope.showQrcode = function () {
            $("#qrcode-warp").addClass("visible");
        };
        //隐藏二维码
        $scope.hiddenPop = function () {
            $("#qrcode-warp").removeClass("visible");
        };
    });