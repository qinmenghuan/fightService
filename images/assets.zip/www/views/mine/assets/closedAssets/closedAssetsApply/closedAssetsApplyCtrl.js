/**
 * Created by admin on 2016/9/19.
 */
starter.controller('closedAssetsApplyCtrl',
    function ($scope, $state, popupSvc, assetsSvc, temporarySvc, $ionicScrollDelegate, $rootScope) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p1');    //from closedAssets
        console.log(params);

        $scope.conf = angular.extend({}, params.params);
        $scope.conf.bankcard_id = params.params.bankcard_id;
        $scope.conf.prod_name = params.prod_name;
        $scope.conf.hasData = true;
        $scope.items = [];

        $scope.del = function (item, index, length) {
            console.log(item, index, length);
            //撤单记录大于一条时最后一条不能撤单，等于一条时可以撤
            if (length > 1) {
                if (index == length - 1) {
                    return false
                } else {
                    popupSvc.alert({
                        template: '您正在进行撤单操作，撤单之后你可以再次买入！',
                        buttons: [
                            {text: '取消'},
                            {
                                text: '<b>确定</b>',
                                //type: 'button-positive close-assets-popup',
                                className: 'popup-container',
                                onTap: function (e) {
                                    //trans060105.json
                                    assetsSvc.cancelOrder({
                                        bankcard_id: $scope.conf.bankcard_id,
                                        prod_code: item.prod_code,
                                        prod_name: item.prod_name,
                                        // acct_no: item.acct_no,
                                        card_no: params.params.card_no,
                                        trans_amt: item.trans_amt,
                                        trans_serno: item.trans_serno,
                                        fnc_trans_serno: item.trans_serno
                                    }).then(function (data) {
                                        console.log(data);
                                        if (data.ret_code === '0000') {
                                            $scope.items.splice(index, 1);
                                        } else {
                                            showErrorInfo(data.ret_msg);
                                        }
                                    });
                                }
                            }
                        ]
                    });
                }
            } else {
                popupSvc.alert({
                    template: '您正在进行撤单操作，撤单之后你可以再次买入！',
                    buttons: [
                        {text: '取消'},
                        {
                            text: '<b>确定</b>',
                            //type: 'button-positive close-assets-popup',
                            className: 'popup-container',
                            onTap: function (e) {
                                //trans060105.json
                                assetsSvc.cancelOrder({
                                    bankcard_id: $scope.conf.bankcard_id,
                                    prod_code: item.prod_code,
                                    prod_name: item.prod_name,
                                    // acct_no: item.acct_no,
                                    // card_no: params.params.card_no,
                                    trans_amt: item.trans_amt,
                                    trans_serno: item.trans_serno,
                                    fnc_trans_serno: item.trans_serno
                                }).then(function (data) {
                                    console.log(data);
                                    if (data.ret_code === '0000') {
                                        $scope.items.splice(index, 1);
                                    } else {
                                        showErrorInfo(data.ret_msg);
                                    }
                                });
                            }
                        }
                    ]
                });
            }
        };


        $scope.buy = function () {
            //跳转B18
            temporarySvc.set("p5", {prod_code: $scope.conf.prod_code, slideBox: '0'});
            $state.go('financeDetail');
        };

        // id
        var OrderOpt = {
            page: '0',
            rows: '10',
            prod_code: $scope.conf.prod_code,
            bankcard_id: $scope.conf.bankcard_id
        };

        $scope.loadMoreData = function () {
            OrderOpt.page = +OrderOpt.page + 1 + '';

            // trans060104.json
            assetsSvc.getLCListOrder(OrderOpt).then(function (data) {
                if (data.ret_code !== '0000' || data.list.length === 0) {
                    $scope.conf.hasData = false;
                    showErrorInfo(data.ret_msg);
                    return;
                }
                $scope.items = $scope.items.concat(data.list);

                setTimeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $ionicScrollDelegate.resize();
                }, 2000);
            });
        };

        $scope.loadMoreData();
    });

