/**
 * Created by admin on 2016/9/19.
 */
starter.controller('closedAssetsOwnCtrl',
    function ($scope, $state, $stateParams, temporarySvc, $filter, $ionicHistory, $rootScope) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p1');
        console.log(params);
        $scope.conf = angular.extend({state: params.state}, params.params);
        $scope.conf.prod_name = params.prod_name;

        if ($scope.conf.cash_date) {
            $scope.conf.cash_date0 = $filter("diffDate")($scope.conf.cash_date);
            // $scope.conf.cash_date0 = params.params.date;
        }
        if ($scope.conf.winding_date) {
            $scope.conf.winding_date0 = $filter("diffDate")($scope.conf.winding_date);
            // $scope.conf.winding_date0 = params.params.date;
        }
    })

