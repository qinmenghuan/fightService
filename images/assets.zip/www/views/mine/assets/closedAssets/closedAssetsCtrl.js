/**
 * Created by mazh on 2016/9/27.
 */
starter.controller("closedAssetsCtrl",
    function ($scope, $state, assetsSvc, $ionicScrollDelegate, temporarySvc, $rootScope) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get('p1');
        console.log('参数', params);
        //配置轮播图参数
        var swiper = new Swiper('.banner', {
            observer: true,
            observeParents: true,
            pagination: '.banner-pagination',
            paginationClickable: true,
            autoplay: false,
            loop: false,
            preventClicks: false,
            centeredSlides: true,   //设置活动块居中
            simulateTouch: false //默认为true，Swiper接受鼠标点击、拖动。
        });
        var holdListOpt = {
            page: '0',
            rows: '10'
        };
        var applyListOpt = {
            page: '0',
            rows: '10'
        };
        var overListOpt = {
            page: '0',
            rows: '10'
        };
        var date = new Time();
        var getHLCHoldData = function () {
            //持有中
            holdListOpt.page = +holdListOpt.page + 1 + '';
            assetsSvc.getHLCHoldData(holdListOpt).then(function (data) {
                if (data.ret_code != '0000') {
                    showErrorInfo(data.ret_msg);
                }
                if (data instanceof Array && data.length > 0) {
                    $scope.holdList = $scope.holdList.concat(data);
                } else {
                    $scope.conf.hasHoldList = false;
                }
            });
        };
        var getHLCApplyData = function () {
            //申请中
            applyListOpt.page = +applyListOpt.page + 1 + '';
            assetsSvc.getHLCApplyData(applyListOpt).then(function (data) {
                if (data.ret_code != '0000') {
                    showErrorInfo(data.ret_msg);
                    return false;
                }
                if (data instanceof Array && data.length > 0) {
                    $scope.applyList = $scope.applyList.concat(data);
                } else {
                    $scope.conf.hasApplyList = false;
                }
            });
        };
        var getHLCOverData = function () {
            //已结束
            overListOpt.page = +overListOpt.page + 1 + '';
            assetsSvc.getHLCOverData(overListOpt).then(function (data) {
                if (data.ret_code != '0000') {
                    showErrorInfo(data.ret_msg);
                    return false;
                }
                if (data instanceof Array && data.length > 0) {
                    $scope.overList = $scope.overList.concat(data);
                } else {
                    $scope.conf.hasOverList = false;
                }
            });
        };

        $scope.conf = {
            showStatus: false,
            tabName: 1,    //1持有中, 2申请中, 3已结束
            invest_amt: '',
            increase_incomes: '',
            total_amt: '',
            hasHoldList: true,
            hasApplyList: true,
            hasOverList: true
        };
        $scope.applyList = [];  //申请中
        $scope.holdList = [];   //持有中
        $scope.overList = [];   //已结束

        $scope.switch = function () {
            $scope.conf.showStatus = !$scope.conf.showStatus;
        };
        //返回时显示历史选择页
        if (params) {
            switch (params.state) {
                case '01':
                    $scope.conf.tabName = 1;
                    break;
                case '03':
                    $scope.conf.tabName = 2;

                    break;
                case '02':
                    $scope.conf.tabName = 3;
                    break;
            }
        }
        $scope.tabs = [
            {name: "持有中", checked: true},
            {name: "申请中", checked: false},
            {name: "已结束", checked: false}
        ];

        assetsSvc.getHLCData().then(function (data) {
            if (data.ret_code !== '0000') {
                showErrorInfo(data.ret_msg);
                return;
            }
            $scope.conf.invest_amt = data.invest_amt || 0;
            $scope.conf.increase_incomes = data.increase_incomes || 0;
            $scope.conf.total_amt = data.total_amt || 0;
        });

        $scope.loadMoreData = function () {
            var tabName = $scope.conf.tabName;
            switch (tabName) {
                case 1:
                    if ($scope.conf.hasHoldList == true) {
                        getHLCHoldData();
                    }
                    break;
                case 2:
                    if ($scope.conf.hasApplyList == true) {
                        getHLCApplyData();
                    }
                    break;
                case 3:
                    if ($scope.conf.hasOverList == true) {
                        getHLCOverData();

                    }
                    break;
            }
            setTimeout(function () {
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $ionicScrollDelegate.resize();
            }, 1000);
        };

        $scope.$on('$ionicView.enter', function () {
            // 进页面请求数据
            if (params) {
                if (params.state) {
                    if (params.state === '01') getHLCHoldData();
                    if (params.state === '02') getHLCApplyData();
                    if (params.state === '03') getHLCOverData();
                } else {
                    getHLCHoldData();
                }
            }
        });

        $scope.checkTabsItem = function (num) {
            $scope.conf.tabName = num;
            if (num === 1) getHLCHoldData();
            if (num === 2) getHLCApplyData();
            if (num === 3) getHLCOverData();
            setTimeout(function () {
                $ionicScrollDelegate.resize();
            }, 1000);
        };
        $scope.goDetail = function (name, item, state, prod_name) {
            temporarySvc.set('p1', {
                state: state,
                params: item,
                prod_name: prod_name
            });
            $state.go(name);
            /*if(str == 1 ){
             $state.go('closedAssetsOwn', {state: "01"});
             }else if(str == 2) {
             $state.go('closedAssetsApply');
             }else if(str == 3){
             $state.go('closedAssetsOwn', {state: "02"});
             }*/
        }
    });
