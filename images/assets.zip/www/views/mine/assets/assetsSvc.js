/**
 */
publicModule.factory("assetsSvc", ["httpSvc", "$q", "$filter", function (httpSvc, $q, $filter) {
    //资产 持有中, 申请中, 已结束 列表排序
    var sortList = function (lists, name) {
        var result = [],
            list = '';
        var conf = {
            prevName: '',
            get_profit_total: 0,
            collect_amt_total: 0,
            index: -1
        };
        if (lists.length === 0) return result;
        for (var i = 0, l = lists.length; i < l; i++) {
            list = lists[i];
            if (!list) break;
            method[name](result, lists, list, conf);
        }
        return result;
    };
    var method = {
        HLCHoldData: function (result, lists, list, conf) {
            var obj = {
                prod_name: list.prod_name,
                prod_code: list.prod_code,
                prod_lifecycle: list.prod_lifecycle,
                income_rate: list.income_rate,
                income_max: list.income_max,
                income: list.income,
                winding_date: list.winding_date,
                total_quota: list.total_quota,
                card_no: list.card_no,
                buy_amt: list.buy_amt,
                valid_date: list.valid_date,
                prod_days: list.prod_days
            };
            if (conf.prevName === list.prod_code) {
                result[conf.index].list.push(obj);
            } else {
                conf.index++;
                result.push({
                    prod_name: list.prod_name,
                    winding_date: list.winding_date,
                    prod_lifecycle: list.prod_lifecycle,
                    list: [obj]
                });
                conf.prevName = list.prod_code;
            }
        },
        HLCApplyData: function (result, lists, list, conf) {
            var obj = {
                prod_code: list.prod_code,
                expe_rate: list.expe_rate,
                establish_date: list.establish_date,
                prod_lifecycle: list.prod_lifecycle,
                card_no: list.card_no,
                buy_amt: list.buy_amt,
                valid_date: list.valid_date,
                prod_days: list.prod_days,
                bankcard_id: list.bankcard_id
            };
            if (conf.prevName === list.prod_code) {
                result[conf.index].list.push(obj);
            } else {
                conf.index++;
                result.push({
                    prod_name: list.prod_name,
                    establish_date: list.establish_date,
                    prod_lifecycle: list.prod_lifecycle,
                    list: [obj]
                });
                conf.prevName = list.prod_code;
            }
        },
        HLCOverData: function (result, lists, list, conf) {
            var obj = {
                card_no: list.card_no,
                buy_amt: list.buy_amt,
                react_income: list.react_income,
                cash_date: list.cash_date,
                prod_days: list.prod_days,
                prod_code: list.prod_code,
                prod_name: list.prod_name,
                income_rate: list.income_rate,
                income_max: list.income_max,
                income: list.income,
                winding_date: list.winding_date,
                valid_date: list.valid_date,
                value_date: list.value_date,
                total_quota: list.total_quota
            };
            if (conf.prevName === list.prod_code) {
                result[conf.index].list.push(obj);
            } else {
                conf.index++;
                result.push({
                    prod_name: list.prod_name,
                    winding_date: list.winding_date,
                    total_quota: list.total_quota,
                    list: [obj]
                });
                conf.prevName = list.prod_code;
            }
        },
        ZNCKDepositList: function (result, lists, list, conf) {
            var obj = {
                get_profit: list.get_profit,
                collect_amt: list.collect_amt,
                card_no: list.card_no
            };
            if (conf.prevName === list.prod_code) {
                conf.get_profit_total += +list.get_profit;   //累加
                conf.collect_amt_total += +list.collect_amt;
                result[conf.index].list.push(obj);
                result[conf.index].collect_amt_total = conf.collect_amt_total;
                result[conf.index].get_profit_total = conf.get_profit_total;
            } else {
                conf.index++;
                conf.get_profit_total = +list.get_profit;
                conf.collect_amt_total = +list.collect_amt;
                result.push({
                    collect_amt_total: conf.collect_amt_total,
                    get_profit_total: conf.get_profit_total,
                    prod_name: list.prod_name,
                    prod_code: list.prod_code,
                    list: [obj]
                });
                conf.prevName = list.prod_code;
            }
        }
    };
    return {
        getAsset: function (params) {
            //我的资产
            return httpSvc.post("asset070104.json", params).then(function (data) {
                    return data;
                }
            )
        },
        // getRate : function(params){
        //     //收益汇总查询
        //     return httpSvc.post("asset070101.json");
        // },
        // getRateDetails : function(params){
        //     //总收益明细
        //     return httpSvc.post("asset070102.json");
        // },
        // getTransRecord : function(params){
        //     //交易记录查询
        //     return httpSvc.post("asset070103.json");
        // },
        getHLCData: function (params) {
            //惠理财资产查询
            return httpSvc.post("asset070201.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getHLCHoldData: function (params) {
            //惠理财资产查询—持有中
            return httpSvc.post("asset070203.json", params).then(function (data) {
                if (data.ret_code !== '0000' || data.list.length == 0) {
                    return data;
                } else {
                    return sortList(data.list, 'HLCHoldData')
                }
            })
        },
        getHLCApplyData: function (params) {
            //惠理财资产查询—申请中
            return httpSvc.post("asset070202.json", params).then(function (data) {
                if (data.ret_code !== '0000' || data.list.length == 0) {
                    return data;
                } else {
                    return sortList(data.list, 'HLCApplyData')
                }
            });
        },
        getHLCOverData: function (params) {
            //惠理财资产查询—已结束
            return httpSvc.post("asset070204.json", params).then(function (data) {
                if (data.ret_code !== '0000' || data.list.length == 0) {
                    return data;
                } else {
                    return sortList(data.list, 'HLCOverData')
                }
            });
        },
        getLCListOrder: function (params) {
            // 申请中 购买记录
            return httpSvc.post("asset060104.json", params).then(function (data) {
                    return data;
                }
            )
        },
        cancelOrder: function (params) {
            //2.6.1.5	理财撤单
            return httpSvc.post("trans060105.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getZNCKCurrentList: function (params) {
            //智能存款活期持有列表
            return httpSvc.post("asset070301.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getZNCKCurrentProfit: function (params) {
            //智能存款活期收益明细
            return httpSvc.post("asset070302.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getZNCKDepositList: function (params) {
            //智能存款定期持有列表
            return httpSvc.post("asset070303.json", params).then(function (data) {
                if (data.ret_code !== '0000') {
                    return data;
                } else {
                    return {
                        get_profit_total: data.get_profit_total,
                        collect_amt_total: data.collect_amt_total,
                        ret_code: data.ret_code,
                        islastpage: data.islastpage,
                        list: sortList(data.list, 'ZNCKDepositList')
                    };
                }
            });
        },
        getZNCKDepositUserList: function (params) {
            //智能存款定期用户持有列表
            return httpSvc.post("asset070304.json", params).then(function (data) {
                if (data.ret_code !== '0000') return data;
                if (data.list) {
                    data.list.forEach(function (list) {
                        list.inc_due = $filter('DictionariesDay')(list.inc_due);
                    })
                    return data;
                }
            })
        },
        revocableAssetsCancel: function (params) {
            //定期解约
            return httpSvc.post("trans060202.json", params).then(function (data) {
                    return data;
                }
            )
        },
        changeProduct: function (params) {
            //智能存款活期变更
            return httpSvc.post("trans060203.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //单个银行卡详情查询
        getBandCardDetails: function (params) {
            return httpSvc.post("bank040508.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getZNCKDepositTakeOutList: function (params) {
            //智能存款定期户支取列表查询
            return httpSvc.post("asset070305.json", params).then(function (data) {
                    return data;
                }
            )
        },
        getZNCKDepositTransRecord: function (params) {
            //智能存款定期单个交易明细查询
            return httpSvc.post("asset070306.json", params).then(function (data) {
                    return data;
                }
            )
        },
        fixedAssetsOut: function (params) {
            //智能存款定期 支取
            return httpSvc.post("trans060205.json", params).then(function (data) {
                    return data;
                }
            )
        },

        getGJSList: function (params) {
            //贵金属持有列表（订单列表）
            return httpSvc.post("asset070401.json", params).then(function (data) {
                    return data;
                }
            )
        },
        queryIntegral: function (params) {
            //积分
            return httpSvc.post("trans060601.json", params).then(function (data) {
                    return data;
                }
            )
        },
        integralProList: function (params) {
            //积分产品列表
            return httpSvc.post("trans060602.json", params).then(function (data) {
                    return data;
                }
            )
        },
        integralProDetail: function (params) {
            //积分产品详情
            return httpSvc.post("trans060603.json", params).then(function (data) {
                    return data;
                }
            )
        },
        integralExchangePro: function (params) {
            //积分兑换商品
            return httpSvc.post("trans060604.json", params).then(function (data) {
                    return data;
                }
            )
        },
        exchangeRecord: function (params) {
            //兑换记录列表查询
            return httpSvc.post("trans060605.json", params).then(function (data) {
                    return data;
                }
            )
        },
        exchangeRecordDetail: function (params) {
            //兑换详情查询
            return httpSvc.post("trans060606.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //查询商品供应商列表
        getChangeSite: function (params) {
            return httpSvc.post("merchant090401.json", params).then(function (data) {
                    return data;
                }
            )
        },
        //查询用户接受到的所有产品分享
        getFinaceShare: function (params) {
            return httpSvc.post("market080112.json", params).then(function (data) {
                    return data;
                }
            )
        }
    };
}]);