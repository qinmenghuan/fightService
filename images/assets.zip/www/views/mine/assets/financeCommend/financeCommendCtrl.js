/**
 * Created by liyy on 16/10/25.
 */
starter.controller("financeCommendCtrl",
    function (CONFIG, $scope, $rootScope, $state, $filter, assetsSvc, temporarySvc, investSvc, popupSvc, $ionicSlideBoxDelegate) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.conf = {
            tab: '1'
        };
        $scope.financeList = [];
        $scope.customizedList = [];
        // 获取推荐给我的理财列表
        $scope.getFinaceList = function () {
            assetsSvc.getFinaceShare({record_type: "1"}).then(function (data) {
                if (data.ret_code == "0000") {
                    console.log(data);
                    $scope.financeList = data.recommand_list;
                    for (var i = 0; i < $scope.financeList.length; i++) {
                        $scope.financeList[i].icon_url = $scope.financeList[i].icon_addr ? CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.financeList[i].icon_addr : "images/mine/login-logo.png";
                    }
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //跳转理财产品详情页
        $scope.buyFinance = function (item) {
            switch (item.s_product_type) {
                case "1":
                    temporarySvc.set("p5", {prod_code: item.product_id, lastUrl: 0, record_id: item.record_id});
                    $state.go("financeDetail");
                    break;
                case "3":
                    temporarySvc.set("p5", {prod_code: item.product_id, lastUrl: 1, record_id: item.record_id});
                    $state.go("timeDeposit");
                    break;
                case "4":
                    temporarySvc.set("p5", {prod_code: item.product_id, lastUrl: 2, record_id: item.record_id});
                    $state.go("metalDetail");
                    break;
            }
        };
        //如果存在购买有礼活动，弹出购买有礼活动弹框，显示奖励信息
        var activityPopupGift = function () {
            $scope.share = popupSvc.alert({
                templateUrl: "views/invest/investDialog/investGift.html",
                scope: $scope,
                cssClass: "hide-btn invest-gift",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                        console.log("点击事件");
                    }
                }]
            })
        };

        //点击购买有礼的“立即购买”按钮，关闭弹框
        $scope.btnClose = function () {
            console.log("12312");
            $scope.share.close();
            $scope.goFinanceDetail();
        };

        //finance惠理财营销分三种：抢购（限时、限量），分享有礼，购买有礼
        $scope.goFinanceDetail = function () {
            var data4 = {
                prod_code: $scope.giftBaseInfo.product_id,
                slideBox: 0
            };
            temporarySvc.set("p5", data4);
            // 跳转到理财明细页面
            $state.go('financeDetail');
        };

        //点击弹框事件
        $scope.showPopup = function (act) {
            // 判断活动状态
            if (!investSvc.checkActivityStatus(act, popupSvc)) {
                return;
            }
            // 弹出活动奖励
            activityPopupGift();
            console.log("activity:", act);
            //获取营销基本活动
            $scope.giftBaseInfo = act;
            //获取营销规则
            investSvc.activityInfo({
                activity_type: act.activity_type,
                activity_id: act.activity_id
            }).then(function (data) {
                if (data.ret_code == "0000") {
                    $scope.activityDetailInfo = data.prize_rule_list;
                    for (var i = 0; i < $scope.activityDetailInfo.length; i++) {
                        $scope.activityDetailInfo[i].voucher_url = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + $scope.activityDetailInfo[i].voucher_pic_url;
                    }
                    $ionicSlideBoxDelegate.update();
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //切换tab
        $scope.changeType = function () {
            $scope.conf.tab = '1'
            $scope.getFinaceList();
        };
        $scope.changeType2 = function () {
            $scope.conf.tab = '2'
        };
        $scope.changeType();
    });
