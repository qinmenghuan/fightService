/**
 * Created by admin on 2016/9/20.
 */

starter.controller('unBindCardCtrl',
    function ($scope,
              $state,
              $stateParams,
              encryptSvc,
              CONSTANT,
              accountSvc,
              util,
              $rootScope,
              mineSvc,
              popupSvc,
              $timeout,
              resourceSvc,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.goBack=function(){
            $state.go("bankCardList");
        };

        $scope.conf={};

        //将临时服务p1的对象赋给  conf
        angular.extend($scope.conf,temporarySvc.get("p1"));

        //银行卡绑定的手机号字段名是bank_mobile
        $scope.conf.bank_mobile=$scope.conf.mobile

        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = true;
        var codeText = $scope.codeText = "获取验证码";
        //获取当前时间毫秒数
        var startTime = new Date().getTime();
        //获取结束时间毫秒数
        var endTime = startTime + 60 * 1000;
        $scope.countDown = util.countDown({timer: endTime});
        $scope.countDown.run(function (s) {
            $scope.codeText = s + "s后重新获取";
        }, codeReset);
        accountSvc.getCode({mobile: $scope.conf.bank_mobile, busi_type: '004'}).then(function (result) {
            console.log(result);
            if (result.ret_code == "0000") {
                $scope.conf.code=result.code;
                $scope.conf.code_id = result.code_id;
                $scope.conf.response_date = result.response_date;

            } else {
                showErrorInfo(result.ret_msg);
                return false;
            }

        })
        //获取验证码
        $scope.getPhoneCode = function () {
            if(! $scope.conf.bank_mobile) return false;
            $scope.phoneInvalid = true;
            //获取当前时间毫秒数
            var startTime = new Date().getTime();
            //获取结束时间毫秒数
            var endTime = startTime + 60 * 1000;
            $scope.countDown = util.countDown({timer: endTime});
            $scope.countDown.run(function (s) {
                $scope.codeText = s + "s后重新获取";
            }, codeReset);

            accountSvc.getCode({mobile: $scope.conf.bank_mobile, busi_type: '004'}).then(function (result) {
                console.log(result);
                if (result.ret_code == "0000") {
                    $scope.conf.code=result.code;
                    $scope.conf.code_id = result.code_id;
                    $scope.conf.response_date = result.response_date;

                } else {
                    showErrorInfo(result.ret_msg);
                    return false;
                }
            })
        }
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        };

        //点击确认按钮
        $scope.submit=function(){
            if(!$scope.conf.code) return false;
            console.log($scope.conf);
            mineSvc.removeBandBankCard($scope.conf).then(function(data){
                if(data.ret_code == '0000'){
                    var signedPopup = popupSvc.alert({
                        title: '解绑银行卡成功',
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        signedPopup.close();
                        $state.go('bankCardList');
                    }, 1000);

                }else{
                    showErrorInfo(data.ret_msg);
                }
            })
        }
    }
)