/**
 * Created by mazh on 16/9/18.
 */
starter.controller('bankCardListCtrl',
    function ($rootScope,
              $scope,
              $state,
              $location,
              mineSvc,
              temporarySvc,
              encryptSvc,
              CONSTANT) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.hasCard = true;

        mineSvc.queryBankCardList().then(function (data) {
            if (data) {
                if (data.ret_code == '0000') {
                    $scope.cardList = data.acct_list;
                    if ($scope.cardList.length > 0) {
                        $scope.hasCard = true;
                    } else {
                        $scope.hasCard = false;
                    }
                } else {
                    showErrorInfo(data.ret_msg);
                }
            } else {
                showErrorInfo('暂无数据');
            }

        });

        //解绑银行卡
        $scope.deleteItem = function(item){
            var tempData=item;
                tempData.pwdStatus="delBankCard";
                tempData.fromUrl="bankCardList";  //该参数表示来自哪个页面
            temporarySvc.set('p1',tempData);
            $state.go('setTradePwd');

        };


        //添加银行卡
        $scope.addBankCard=function(){
            temporarySvc.set("p1",{title:'add'});
            $state.go('addBankCard2');
        };

        //验卡
        $scope.verifyCard=function(item){
            temporarySvc.set("p1",{title:'verifyCard',cardData:item})
            $state.go('addBankCard3');
        };

        ////点击返回
        //$scope.goBack=function(){
        //    $state.go('mine');
        //}

    }
);