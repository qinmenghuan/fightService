/**
 * Created by admin on 2016/9/19.
 */

//第一步控制器
starter.controller('addBankCardCtrl',
    function ($scope,
              $state,
              encryptSvc,
              CONSTANT,
              accountSvc,
              util,
              $rootScope,
              mineSvc,
              $stateParams,
              temporarySvc,
              toolSvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //获取缓存中的用户名
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            if (userInfo) {
                $scope.conf.user_name = userInfo.query("user_name");
            }
        });
        //获取temporarySvc  里边的 title值
        var sTitle = temporarySvc.get("p1").title;
        angular.extend($scope.conf, temporarySvc.get("p1").cardData);
        console.log($scope.conf);
        if (sTitle == "add" || sTitle == "demandChooseCard") {
            $scope.conf.title = "添加银行卡";
        } else if (sTitle == "verifyCard") {
            $scope.conf.title = "验卡";
        }


        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = false;
        //设置验证码是否获取状态
        $scope.ifCode = false;
        var codeText = $scope.codeText = "获取验证码";

        //获取验证码
        $scope.getPhoneCode = function () {
            console.log($scope.conf.bank_mobile);
            if (!$scope.conf.bank_mobile) return false;
            accountSvc.getCode({mobile: $scope.conf.bank_mobile, busi_type: '002'}).then(function (result) {
                console.log(result);
                if (result.ret_code == "0000") {
                    $scope.phoneInvalid = true;
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime + 60 * 1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                    $scope.ifCode = true;

                    $scope.conf.code = result.code;
                    $scope.conf.code_id = result.code_id;
                    $scope.conf.response_date = result.response_date;

                } else {
                    showErrorInfo(result.ret_msg);
                    return false;
                }

            })

        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        }

        //判断点击返回
        $scope.goBack = function () {
            switch ($scope.conf.step) {
                case '1':
                    $state.go('bankCardList');
                    break;
                case '2':
                    if ($scope.conf.user_name) {
                        if (sTitle == "demandChooseCard") {
                            $state.go('demandChooseCard');
                        }
                        $state.go('bankCardList');
                    } else {
                        $scope.conf.step = '1';
                    }
                    break;
                case '3':
                    if (sTitle == "add" || sTitle == "demandChooseCard") {  //返回时重置倒计时
                        $scope.conf.step = '2';
                        codeReset();
                        $scope.conf.code = "";
                    } else if (sTitle == "verifyCard") {
                        $state.go('bankCardList')
                    }
                    break;
            }
        };
        //默认三个按钮不可点击
        $scope.step1Disable = true;

        $scope.$watchGroup(['conf.user_name', 'conf.id_no'], function (newVal) {
            console.log(newVal)
            if (newVal[0] && newVal[1]) {
                $scope.step1Disable = false;
            }
        });

        $scope.step1 = function () {
            //姓名认证
            var checkName = toolSvc.checkName($scope.conf.user_name);
            if (checkName) {
                showErrorInfo(checkName);
                return;
            }
            //验证身份证号是否合规
            var checkID = toolSvc.checkID($scope.conf.id_no);
            if (checkID) {
                showErrorInfo(checkID);
                return;
            }
            temporarySvc.set("p1", {title: 'add', cardData: $scope.conf});
            $state.go('addBankCard2');
        };

    }
);

//第二步控制器
starter.controller('addBankCard2Ctrl',
    function ($scope,
              $state,
              encryptSvc,
              CONSTANT,
              accountSvc,
              util,
              $rootScope,
              mineSvc,
              $stateParams,
              $ionicHistory,
              temporarySvc) {
        $scope.conf = {};

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        $scope.$ionicGoBack = function () {
            $ionicHistory.goBack(-1);
        };
        //获取缓存中的用户名
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            if (userInfo) {
                $scope.conf.user_name = userInfo.query("user_name");
            }
        });

        $scope.step2Disable = true;
        $scope.$watchGroup(['conf.user_name', 'conf.card_no'], function (newVal) {
            if (newVal[0] && newVal[1]) {
                if (newVal[1].length >= 16 && newVal[1].length <= 19) {
                    $scope.step2Disable = false;

                } else {
                    $scope.step2Disable = true;
                }
            }
        });

        //获取temporarySvc  里边的 title值
        var sTitle = temporarySvc.get("p1").title;

        $scope.conf.title = "添加银行卡";
        $scope.step2 = function () {
            if ($scope.conf.card_no) {
                //查询卡bin
                mineSvc.queryBin({card_no: $scope.conf.card_no}).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        if (sTitle == 'buy') {
                            temporarySvc.set("p1", {title: 'buy', cardData: $scope.conf});
                        } else {
                            temporarySvc.set("p1", {title: 'add', cardData: $scope.conf});
                        }
                        $state.go('addBankCard3');
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });

            }
        };

        //判断点击返回
        $scope.goBack = function () {
            switch (sTitle) {
                case 'add':
                    $state.go('bankCardList');
                    break;
                case 'demandChooseCard':
                    $state.go('demandChooseCard');
                    break;
                case 'timeChooseCard':
                    $state.go('timeChooseCard');
                    break;

            }
        }
    }
);

//第三步控制器
starter.controller('addBankCard3Ctrl',
    function ($scope,
              $state,
              encryptSvc,
              CONSTANT,
              accountSvc,
              util,
              $rootScope,
              mineSvc,
              $stateParams,
              temporarySvc) {
        $scope.conf = {};

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        //获取缓存中的用户名
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            if (userInfo) {
                $scope.conf.user_name = userInfo.query("user_name");
            }
        });

        //获取temporarySvc  里边的 title值
        var sTitle = temporarySvc.get("p1").title;
        angular.extend($scope.conf, temporarySvc.get("p1").cardData);
        if (sTitle == "verifyCard") {
            $scope.conf.title = "验卡";
            console.log($scope.conf);
        } else {
            $scope.conf.title = "添加银行卡";

        }

        $scope.step3Disable = true;
        $scope.$watchGroup(['conf.bank_mobile', 'conf.code'], function (newVal) {
            if (newVal[0] && newVal[1]) {
                $scope.step3Disable = false;
            }
        });

        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = false;

        //设置验证码是否获取状态
        $scope.ifCode = false;
        var codeText = $scope.codeText = "获取验证码";

        //获取验证码
        $scope.getPhoneCode = function () {
            console.log($scope.conf.bank_mobile);
            if (!$scope.conf.bank_mobile) return false;


            accountSvc.getCode({mobile: $scope.conf.bank_mobile, busi_type: '002'}).then(function (result) {
                console.log(result);
                if (result.ret_code == "0000") {
                    $scope.phoneInvalid = true;
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime + 60 * 1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                    $scope.ifCode = true;

                    $scope.conf.code = result.code;
                    $scope.conf.code_id = result.code_id;
                    $scope.conf.response_date = result.response_date;

                } else {
                    showErrorInfo(result.ret_msg);
                    return false;
                }

            })

        }
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        };
        $scope.step3 = function () {
            if ($scope.conf.bank_mobile && $scope.conf.code) {
                if (sTitle == "buy" || sTitle == "add" || sTitle == "demandChooseCard" || sTitle == "timeChooseCard") {
                    mineSvc.addBankCard($scope.conf).then(function (data) {
                        if (data.ret_code == '0000') {
                            if (sTitle == "buy") {
                                $state.go('buy')
                            } else {
                                $state.go('bankCardList')
                            }
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    })
                } else if (sTitle == "verifyCard") {
                    mineSvc.verifyCard($scope.conf).then(function (data) {
                        if (data.ret_code == '0000') {
                            $state.go('bankCardList')
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    })
                }

            }

        };

        //判断点击返回
        $scope.goBack = function () {
            $rootScope.$ionicGoBack();
            /*switch (sTitle) {
             case 'add' || 'demandChooseCard' || 'timeChooseCard':
             $state.go('bankCardList');
             break;
             case 'verifyCard':
             $state.go('bankCardList');
             break;

             }*/
        }
    }
)