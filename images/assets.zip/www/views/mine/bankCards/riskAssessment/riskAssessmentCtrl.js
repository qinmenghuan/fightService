/**
 * Created by mazh on 2016/4/5
 */
'use strict';
starter.controller('riskAssessmentCtrl',
    function ($scope,
              util,
              $state,
              $stateParams,
              $rootScope,
              $timeout,
              $validation,
              popupSvc,
              mineSvc,
              encryptSvc,
              CONSTANT,
              $ionicHistory,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.obj = {
            step: 1,
            risk_level: ''
        };
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            $scope.queryParams = {
                id_type: userInfo.query("id_type") || "",
                id_code: userInfo.query("id_code") || ""
            };
            //查询风险等级
            mineSvc.queryRiskLv($scope.queryParams).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        $scope.obj.risk_level = data.risk_level;
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                }
            )
        });
        //返回按钮弹窗
        $scope.ask = function () {
            if ($scope.obj.step == 1) {
                //$ionicHistory.goBack(-1);
                $rootScope.$ionicGoBack();
            } else if ($scope.obj.step == 2) {
                var askQuit = popupSvc.alert({
                    title: "本次风险评估未完成，终止后将不保存当前进度，确定终止",
                    cssClass: "popup-container",
                    buttons: [
                        {
                            text: '<b>确定</b>',
                            type: 'button-positive',
                            onTap: function (e) {
                                $scope.obj.step = 1;
                                $scope.answers = [];
                                $scope.num = 0;
                            }
                        },
                        {text: '取消'}
                    ]
                });
            }
        };


        $scope.nextStep = function () {
            $scope.obj.step = 2;
            console.log($scope.num);
            //查询风险评测题目
            mineSvc.queryRiskList($scope.queryParams).then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        $scope.obj.subjects = data.question_List;
                        if ($scope.obj.subjects) {
                            var data = $scope.obj.subjects;
                            $scope.outsideList = [];
                            for (var i in data) {
                                data[i].answer_list = toolSvc.objKeySort(data[i].answer_list);
                                var inside = [];
                                for (var key in data[i].answer_list) {
                                    var o = {};
                                    if (data[i].answer_list[key]) {
                                        o.key = key;
                                        o.value = data[i].answer_list[key];
                                        o.selected = false;
                                        inside.push(o);
                                    }
                                }
                                var questionItem = {
                                    answer_list: inside,
                                    questions_name: data[i].question_name,
                                    questions_num: data[i].question_code,

                                    //result: inside[0].key
                                };
                                $scope.outsideList.push(questionItem);
                            }
                            console.log($scope.outsideList);
                        }

                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                }
            );
        };
        $scope.thirdStep = function () {
            $scope.obj.step = 3;
        };
        $scope.answers = [];
        $scope.num = 0;
        $scope.options = {defaultSelect: false};
        $scope.selected = function (item, q) {
            console.log(item);
            if ($scope.num < $scope.outsideList.length + 1) {
                item.selected = true;
                $scope.answers[$scope.num] = item.key;
                console.log($scope.answers[$scope.num]);
                for (var i = 0; i < q.answer_list.length; i++) {
                    q.answer_list[i].selected = false;
                }
                // $scope.num++;
                if ($scope.num < 9) {
                    console.log($scope.num);
                    $scope.num++;
                }
            }

            //$timeout(function () {
            //    if ($scope.num < $scope.outsideList.length - 1) {
            //        $scope.num++;
            //    }
            //}, 300);

            console.log($scope.answers);
        };
        $scope.lastItem = function () {
            if ($scope.num > 0) {
                $scope.num--;
            }
            console.log($scope.num);
        };
        console.log($scope.num);
        $scope.submitAnswer = function () {
            console.log($scope.answers.join());
            var answerStr = [];
            for (var i = 0; i < $scope.answers.length; i++) {
                if (i < 9) {
                    answerStr[i] = (i + 1) + "," + $scope.answers[i];
                } else {
                    answerStr[i] = (i + 1) + "," + $scope.answers[i];
                }
            }
            console.log(answerStr.join(";"));
            //提交风险评测题目答案参数
            encryptSvc.then(function (encrypt) {
                var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                $scope.submitParams = {
                    id_type: userInfo.query("id_type") || "",
                    id_code: userInfo.query("id_code") || "",
                    answer_list: answerStr.join(";")
                };
                mineSvc.submitRisk($scope.submitParams).then(function (data) {
                        console.log(data);
                        if (data.ret_code == "0000") {
                            var setSucPopup = popupSvc.alert({
                                title: "提交成功",
                                cssClass: "popup-container",
                                buttons: []
                            });
                            $timeout(function () {
                                setSucPopup.close();
                                $ionicHistory.goBack(-1);
                            }, 500);

                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    }
                )
            });
        }
    });