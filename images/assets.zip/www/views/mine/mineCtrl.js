/**
 * Created by mazh on 16/9/18.
 */
starter.controller("mineCtrl",
    function ($scope,
              $rootScope,
              $state,
              mineSvc,
              encryptSvc,
              CONSTANT,
              accountSvc,
              homeSvc,
              popupSvc,
              CONFIG) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //初始化数据
        $scope.mineModel = {
            total_profit_amt: "0.00",//已获收益
            total_due_in: "0.00",//待收本金
            bankcard_sum: "0"//银行卡
        };

        encryptSvc.then(function (encrypt) {
            var head_jsessionid = encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID);
            if (!head_jsessionid || head_jsessionid == null) {
                $scope.ifShow = false;
                console.log("未登录");
            } else {
                $scope.ifShow = true;
                console.log("已登录");
                //查询我的数据
                mineSvc.queryMine().then(function (data) {
                    if (data.ret_code == "0000") {
                        angular.extend($scope.mineModel, data);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
                //查询安全状态
                mineSvc.queryAccountStatus().then(function (data) {
                    console.log(data);
                    if (data.ret_code == "0000") {
                        $scope.account_info = data.acctstep_list;
                        // 1 为系统头像  2为自选头像
                        if (data.user_info.icon_type == '1') {
                            $scope.account_info.headpic = 'images/mine/' + data.user_info.icon_addr;
                        } else if (data.user_info.icon_type == '2') {
                            $scope.account_info.headpic = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + data.user_info.icon_addr;
                        }
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            }
        });
        $scope.changeShowPwd = function () {
            $scope.showPwd = !$scope.showPwd;
            console.log($scope.showPwd);
        };
        console.log($scope.checkValid);
        //根据是否风评跳转
        $scope.goRisk = function () {
            if ($scope.account_info[1].flag == "1" && $scope.account_info[2].flag == "1") {
                $state.go('riskAssessment');
            } else if ($scope.account_info[1].flag == "0") {
                $state.go('validate', {validate: "risk1"});
            } else if ($scope.account_info[1].flag == "1" && $scope.account_info[2].flag == "0") {
                $state.go('validate', {validate: "risk2"});
            }
        };

        //点击银行卡
        $scope.bankCardList = function () {
            encryptSvc.then(function (encrypt) {
                if ($scope.account_info) {
                    //用户没有完成实名认证和设置交易密码  则显示去验证页面
                    if ($scope.account_info[1].flag == '0' || $scope.account_info[0].flag == '0') {
                        $state.go('validate', {validate: 'bank'});
                    } else {
                        $state.go('bankCardList');
                    }
                }
            });
        };
        $scope.goLogin = function () {
            $state.go('login', {params: {url: 'mine'}})
        };

        $scope.dailySignIn = function () {
            homeSvc.checkActivityStatus($state, popupSvc);
        };
    });