/**
 * Created by mazh on 16/9/18.
 */
starter.controller("realAuthenticationCtrl",
    function ($scope,
              $state,
              $rootScope,
              $stateParams,
              util,
              popupSvc,
              $timeout,
              CONSTANT,
              httpSvc,
              mineSvc,
              accountSvc,
              encryptSvc,
              temporarySvc,
              toolSvc,
              pageJumpSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            if (temporarySvc.get('realA') && temporarySvc.get('realA').title) {
                $scope.realModel = temporarySvc.get('realA');
            } else {
                $scope.realModel = {
                    title: "实名认证",
                    step: 1
                };
            }
            if ($stateParams.step == 4) {
                $scope.realModel.step = 4;
                $scope.realInfo = {
                    user_name: userInfo.query("user_name"),
                    id_code: userInfo.query("id_code")
                }
            }
            $scope.step2Disable = true;
            $scope.$watchGroup(['realModel.user_name', 'realModel.card_no'], function (newVal) {
                if (newVal[0] && newVal[1]) {
                    if (newVal[1].length >= 16 && newVal[1].length <= 19) {
                        $scope.step2Disable = false;

                    } else {
                        $scope.step2Disable = true;
                    }
                }
            });
            $scope.submitId = function () {
                console.log("submitid");
                // todo 暂时取消姓名验证 身份证验证
                // 姓名认证
                var checkName = toolSvc.checkName($scope.realModel.user_name);
                if (checkName) {
                    showErrorInfo(checkName);
                    return;
                }
                // 验证身份证号是否合规
                var checkID = toolSvc.checkID($scope.realModel.id_code);
                if (checkID) {
                    showErrorInfo(checkID);
                    return;
                }
                mineSvc.isRealName({
                    check_type: '1',
                    id_code: $scope.realModel.id_code
                }).then(function (data) {
                    if (data.ret_code == '0000') {
                        //检验的身份证号未实名
                        if (data.is_regist == '1') {
                            showErrorInfo('实名认证时一张身份证应不能绑定多个账号');
                        } else {
                            //未实名，验证通过
                            console.log($scope.realModel);
                            //$scope.realModel.step = 2;
                            temporarySvc.set('realA', $scope.realModel);
                            $state.go('realAuthenticationNext');
                        }
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });
            };
            //验卡
            $scope.submitBank = function () {
                console.log($scope.realModel);
                // $scope.realModel.id_type = "D";
                $scope.realModel.id_type = "A";
                mineSvc.checkCard2($scope.realModel).then(function (data) {
                    if (data.ret_code == '0000') {
                        temporarySvc.set('realA', $scope.realModel);
                        $state.go('realAuthenticationLast');
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                })
            };
            $scope.submitCode = function () {
                console.log($scope.realModel);
                $scope.realModel.id_type = "A";
                // $scope.realModel.id_type = "D";
                $scope.realModel.acct_no = $scope.realModel.card_no;
                //实名认证
                mineSvc.realAu($scope.realModel).then(function (data) {
                    if (data.ret_code == "0000") {
                        //更新缓存
                        var value = {};
                        value[CONSTANT.JSESSIONID_UNIT] = userInfo.query(CONSTANT.JSESSIONID_UNIT);
                        value[CONSTANT.JSESSIONID_TIME] = userInfo.query(CONSTANT.JSESSIONID_TIME);
                        angular.extend(value, data.user_info);
                        userInfo.save(value);
                        encrypt.aesDeObjectL(CONSTANT.ACCOUNT_INFO, data.acctstep_list);
                        var setSucPopup = popupSvc.alert({
                            title: "实名认证成功",
                            cssClass: "popup-container",
                            buttons: []
                        });
                        $timeout(function () {
                            setSucPopup.close();
                            pageJumpSvc.nextPageGoBack({
                                currentState: "realAuthenticationLast",
                                nextState: "accountSafe",
                                goBack: "mine"
                            });
                            $state.go('accountSafe');

                        }, 500);
                    } else {
                        showErrorInfo(data.ret_msg);
                    }
                });

            };
            // 设置获取验证码按钮默认状态
            $scope.phoneInvalid = true;
            //设置验证码是否获取状态
            $scope.ifCode = false;
            var codeText = $scope.codeText = "获取验证码";
            //获取验证码
            $scope.getCode = function (bank_mobile) {
                //判断手机号是否符合格式
                if (!/^1\d{10}$/.test(bank_mobile)) {
                    showErrorInfo(CONSTANT.PHONE_ERROR);
                    return false;
                } else {
                    //获取验证码
                    accountSvc.getCode({mobile: bank_mobile, busi_type: "002"}).then(function (data) {
                        if (data.ret_code == "0000") {
                            $scope.phoneInvalid = false;
                            $scope.ifCode = true;
                            $scope.realModel.code_id = data.code_id;
                            $scope.realModel.response_date = data.response_date;
                            //获取当前时间毫秒数
                            var startTime = new Date().getTime();
                            //获取结束时间毫秒数
                            var endTime = startTime + 60 * 1000;
                            $scope.countDown = util.countDown({timer: endTime});
                            $scope.countDown.run(function (s) {
                                $scope.codeText = s + "s后重新获取";
                            }, codeReset);
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                }
            };
            //重置验证码按钮
            function codeReset() {
                $scope.countDown.cancel();
                $scope.codeText = codeText;
                $scope.phoneInvalid = true;
            }
        });


        /**
         * 验证身份证号是否可以实名，如果已实名则不能再次实名
         * @returns {boolean}
         */
        function checkRealName() {
            var result = false;

            console.log("yyyyyyyyyyyyy", result);
        }


    });