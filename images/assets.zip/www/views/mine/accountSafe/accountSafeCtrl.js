/**
 * Created by mazh on 16/9/18.
 * 账号安全
 */
starter.controller("accountSafeCtrl",
    function ($rootScope,
              $scope,
              $state,
              $stateParams,
              encryptSvc,
              mineSvc,
              CONSTANT,
              temporarySvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        /*$scope.goMine = function () {
         if ($stateParams.params) {
         switch ($stateParams.params.url) {
         case "finance":
         $state.go('financeDetail');
         break;
         }
         } else {
         $state.go('mine');
         }
         };*/
        //清除掉实名信息
        temporarySvc.remove('realA');
        mineSvc.queryAccountStatus().then(function (data) {
            if (data) {
                if (data.ret_code == '0000') {
                    $scope.result = [];
                    for (var i = 0; i < data.acctstep_list.slice(0).length; i++) {
                        $scope.result[i] = data.acctstep_list.slice(0)[i].flag;
                    }
                    console.log($scope.result.join(""));
                    var account_safe_status = $scope.result.join("");
                    $scope.acc = {};
                    if (account_safe_status == '111') {
                        $scope.acc.total = '安全';
                        $scope.acc.total_color = true;
                    }
                    else {
                        $scope.acc.total = '危险';
                        $scope.acc.total_color = false;
                    }
                    var acc_type = account_safe_status.split('');
                    var accArray = [];
                    for (i = 0; i < acc_type.length; i++) {
                        var accItem = {};
                        accItem.type = acc_type[i];
                        if (i == 0) {
                            accItem.name = "交易密码";
                            if (acc_type[i] == 0) {
                                accItem.typeInfo = "未设置";
                            } else {
                                accItem.typeInfo = "已设置";
                            }
                        } else if (i == 1) {
                            accItem.name = "实名认证";
                            if (acc_type[i] == 0) {
                                accItem.typeInfo = "未认证";
                            } else {
                                accItem.typeInfo = "已认证";
                            }
                        } else if (i == 2) {
                            accItem.name = "风险评测";
                            if (acc_type[i] == 0) {
                                accItem.typeInfo = "未风评";
                            } else {
                                accItem.typeInfo = "已风评";
                            }
                        }
                        accArray.push(accItem);
                    }
                    $scope.accArray = accArray;
                    $scope.acc.type1 = acc_type[0];
                    $scope.acc.type2 = acc_type[1];
                    $scope.acc.type3 = acc_type[2];
                } else {
                    showErrorInfo(data.ret_msg);
                }
            } else {
                //无数据
                showErrorInfo('暂无数据');
            }
        });

        $scope.accItemClick = function ($index) {
            console.log($index);
            switch ($index) {
                case 0:
                    $scope.goSetTradePwd();
                    break;
                case 1:
                    $scope.goRealAuthentication();
                    break;
                case 2:
                    $scope.goRisk();
                    break;
            }
        };

        //去设置交易密码页
        $scope.goSetTradePwd = function () {
            if ($scope.acc.type1 == 0) {
                var tempData = {
                    fromUrl: "accountSafe",
                    pwdStatus: "noTradPwd",
                    lastUrl: "accountSafe"
                };
                temporarySvc.set('p1', tempData);
                $state.go('setTradePwd');
            }
            else {
                return false;
            }
        };
        //去实名认证页
        $scope.goRealAuthentication = function () {
            if ($scope.acc.type1 == 1 && $scope.acc.type2 == 0) {
                $state.go('realAuthentication', {step: 1});
            } else if ($scope.acc.type1 == 1 && $scope.acc.type2 == 1) {
                $state.go('realAuthentication', {step: 4});
            } else {
                return false;
            }
        };
        //去风险评测页
        $scope.goRisk = function () {
            if ($scope.acc.type3 == 1) {
                $state.go('riskAssessment');
            }
            //else if ($scope.acc.type1 == 1 && $scope.acc.type2 == 1 && $scope.acc.type3 != 1) {
            //    $state.go('validate', {validate: "risk2"});
            //}
            else if ($scope.acc.type2 == 1 && $scope.acc.type3 == 0) {
                $state.go('order');
            }

        }
    });