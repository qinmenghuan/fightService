/**
 * Created by kayak on 16/9/18.
 */
starter.controller('orderCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              $sce,
              mineSvc,
              homeSvc,
              $filter,
              encryptSvc,
              CONFIG,
              CONSTANT,
              mapSvc,
              $ionicScrollDelegate,
              $timeout) {
        $scope.mapFlag=true;//让地图延迟显示避免有些标签显示不出来
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var userinfo="",walkingFlag=false,selectSiteFlag=false,cancelFlag=false;
        encryptSvc.then(function (encrypt) {
            userinfo=encrypt.aesLocalTemp(CONSTANT.USER_INFO);
        });
        $scope.myLocation = [];//定位当前的经纬度
        $scope.nowClick=null;//点击麻点或银行列表获取到的信息
        $scope.bespeak = {siteMap:""};//输入查询网点名称
        $scope.selectList=[];//查询当前城市中的网点信息
        $scope.bespeakList={};//预约成功获取的返回值信息
 	    $scope.conf = {
            step : "1"
        };
        mineSvc.orderSearch({}).then(function(data){
            if(data.ret_code === "0000"){
                if(data.is_reserve_flag!="0"){
                    $scope.conf.step  ="3";
                    var item=data.sub_list[0];
		            $scope.nowClick = item;
                    $scope.bespeakList=item;
                    $scope.bespeakList.cust_manager_mobile=item.mobile;
                    $scope.bespeakList.remain_show=$filter("remainTime")(item.create_time);
                }
            }else {
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.onComplete = function(data){
            $scope.myLocation = data;
            if($scope.conf.step == "3"){
                var data=$scope.nowClick;
                mapSvc.infoWindow({
                    position:[parseFloat(data.lng),parseFloat(data.lat)],
                    name:data.orgname,
                    address:data.address
                });
                if(walkingFlag) {
                    $scope.walkingNavigation(data);
                    walkingFlag=false;
                }
                if(selectSiteFlag) {
                    $scope.selectSite($scope.bespeak.siteMap);
                    selectSiteFlag=false;
                }
            }
        };
        $scope.addCloudLayer = function (data,location) {
            $scope.myLocation=location||$scope.myLocation;
            var distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance(data._location).toFixed(1);
            $scope.nowClick={
                orgno:data.org_no+"",
                orgname:data._name,
                address:data._address,
                lng:data._location.lng,
                lat:data._location.lat,
                distance:distance
            };
            $scope.$apply();
        };
        //调用mapSvc服务初始化地图
        mapSvc.init('map',$scope.onComplete,$scope.addCloudLayer);


        $scope.GoBack=function(type){
            if(type==0){
                //$state.go("accountSafe");
                $rootScope.$ionicGoBack();
            }else{
                $scope.conf.step  =type;
            }
            if(type==1){
                $ionicScrollDelegate.scrollTop();
                $timeout(function(){
                    $scope.mapFlag=true;
                },300)
            }
        };
        //确认预约
        $scope.onConfirmReserve=function(item){
            if(!item) return showErrorInfo("请选择银行网点");
            $scope.conf.step  ="0";
            var params={
                user_name:userinfo.user_name || "",
                id_type: userinfo.id_type || "",
                id_code: userinfo.id_code || "",
                address:item.address,
                orgno:item.orgno,
                orgname:item.orgname,
                lng:item.lng+"",
                lat:item.lat+""
            };
            mineSvc.order(params).then(function(data){
                if(data.ret_code === "0000"){
                    if(cancelFlag){
                        $scope.cancelReserved({cust_sub_id:data.cust_sub_id});
                    }else{
                        $scope.conf.step  ="3";
                        $scope.bespeakList=data;
                        $scope.bespeakList.remain_show=$filter("remainTime")(data.trans_date);
                    }
                }else {
                    $scope.conf.step  ="1";
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //取消按钮
        $scope.onCancelReserve = function(){
            cancelFlag=true;
            $scope.conf.step = "1";
        };
        //取消预约
        $scope.cancelReserved = function(item){
            mineSvc.cancelOrder({cust_sub_id:item}).then(function (result) {
                if (result.ret_code == "0000") {
                    if(cancelFlag) {
                        cancelFlag=false;
                    }else{
                        $state.go('accountSafe');
                    }
                } else {
                    showErrorInfo(result.ret_msg);
                }
            });
        };
        //查询输入的银行名称
        $scope.selectSite = function(siteMap){
            if(!$scope.myLocation.length){
                selectSiteFlag=true;
                return;
            }
            $scope.conf.step  ="2";
            $scope.mapFlag=false;
            homeSvc.webSite({orgname:siteMap||""}).then(function(data){
                if(data.ret_code === "0000"){
                    data.coordinatelist.map(function(item){
                        item.distance = new AMap.LngLat($scope.myLocation[0], $scope.myLocation[1]).distance([parseFloat(item.lng), parseFloat(item.lat)]).toFixed(1);
                        item.distanceNum = parseFloat(item.distance);
                    });
                    $scope.selectList=data.coordinatelist;
                }else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //列表中选择
        $scope.checkSelected = function(item){
            mapSvc.infoWindow({
                position:[parseFloat(item.lng),parseFloat(item.lat)],
                name:item.orgname,
                address:item.address
            });
            $scope.nowClick = item;
            $scope.conf.step  ="1";
            $ionicScrollDelegate.scrollTop();
            $timeout(function(){
                $scope.mapFlag=true;
            },300);
        };
        //导航
        $scope.walkingNavigation = function(nowClick){
            if(!$scope.myLocation.length){
                walkingFlag=true;
                return;
            }
            walkingFlag=false;
            var tUrl = 'http://m.amap.com/navi/?start='+$scope.myLocation[0]+','+ $scope.myLocation[1]+'&dest='+nowClick.lng+','+ nowClick.lat+'&destName='+nowClick.orgname+'&naviBy=car&key=06f54a9e326e97b16a1eda53dbf58718'
            if(CONFIG.DEBUG_ON_CHROME){
                $scope.conf.step  ="4";
                $scope.tUrl = $sce.trustAsResourceUrl(tUrl);
            }else {
                var config = angular.extend(CONFIG.BROWSER_CONFIG, {title: {staticText: "导航"}});
                cordova.ThemeableBrowser.open(tUrl, '_blank', config);
            }
        };
    }
);