/**
 * 请求服务
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.factory("busCenterSvc", function ($http,httpSvc) {
    return {
        // smsCode:function(params){
        //     return httpSvc.post("pub010301.json",params).then(function(data){
        //         //if (data.ret_code != "0000") return;
        //         return data;
        //     });
        // },
        setPwd:function(params){
            return httpSvc.post("merchant090102.json",params).then(function(data){
                return data;
            });
        },
        voucherInfo:function(params){
            return httpSvc.post("market080502.json",params).then(function(data){
                return data;
            });
        },
        voucherOk:function(params){
            return httpSvc.post("trans060401.json",params).then(function(data){
                return data;
            });
        },
        billInfo:function(params){
            return httpSvc.post("merchant090201.json",params).then(function(data){
                return data;
            });
        },
        billDetailInfo:function(params){
            return httpSvc.post("merchant090202.json",params).then(function(data){
                return data;
            });
        },
        settingQit:function(params){
            return httpSvc.post("merchant090104.json",params).then(function(data){
                return data;
            });
        },
        //手机验证
        oldPhone:function(params){
            return httpSvc.post("security040001.json",params).then(function(data){
                return data;
            });
        },
        newPhone:function(params){
            return httpSvc.post("merchant090103.json",params).then(function(data){
                return data;
            });
        }
    }
});
