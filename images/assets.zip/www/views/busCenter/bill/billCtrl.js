/**
 * 对账单
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('billCtrl',
    function ($scope,
              $state,
              $rootScope,
              $timeout,
              busCenterSvc,
              resourceSvc,
              $ionicScrollDelegate,
              $filter) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var viewFlag=false,billFlag=false;
        var emp_info=resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack=function(){
            $state.go("busCenter");
        };
        $scope.billlObj=[];
        $scope.billDetailObj=[];
        $scope.loading=true;
        $scope.$on("$ionicView.afterEnter", function () {
            console.log("INFO: bill start !");
            viewFlag=true;
            if(viewFlag&&billFlag) $scope.renderFinish();
        });

        $scope.renderFinish = function () {
            var swiper=new Swiper('.ad-container', {
                    slidesPerView: 1.4,
                    initialSlide: $scope.billlObj.length-1,//默认显示最后一个下标
                    spaceBetween: 0,
                    grabCursor: true,
                    ventClicksPropagation: false,
                    preventClicks: false,
                    centeredSlides: true,   //设置活动块居中
                    observer: true,
                    observeParents: true,
                    simulateTouch: false,  //默认为true，Swiper接受鼠标点击、拖动。
                    onSlideChangeEnd: function(swiper){
                        $scope.activeIndex=swiper.activeIndex;
                        $scope.loading=true;
                        $scope.postDetail(0);
                    }
                });
            $scope.$on("$destroy", function(){
                if(swiper && swiper.destroy) swiper.destroy();
            });
        };
        $scope.changeTime = function(time){
            var year=time.substr(0,4);
            var month=parseInt(time.substr(4,2))>9?parseInt(time.substr(4,2)):parseInt(time.substr(5,1));
            var Day=[31,28,31, 30,31,30, 31,31,30, 31,30,31];
            var lastDay=Day[month-1];
            if(month==2){
                lastDay=((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0))?"29":"28";
            }
           return year+"年"+month+"月账单("+month+".1-"+month+"."+lastDay+")"
        };

        busCenterSvc.billInfo({head_esessionid:emp_info.head_esessionid}).then(function(data){
            console.log(data);
            if(data.ret_code=="0000") {
                data.bill_list.map(function(item){
                    item.monthStr=$scope.changeTime(item.month);
                });
                $scope.billlObj=data.bill_list;
                billFlag=true;
                if(viewFlag&&billFlag) $scope.renderFinish();
                $scope.postDetail(0);
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.postDetail=function(type){
            var params={};
           if(type==0){
                params={
                    head_esessionid:emp_info.head_esessionid,
                    month:$scope.billlObj.length?$scope.billlObj[$scope.activeIndex||$scope.billlObj.length-1].month:$filter("date")(new Date(),"yyyyMM")
                };
            }else{
                params={
                    head_esessionid:emp_info.head_esessionid,
                    month:$scope.billlObj.length?$scope.billlObj[$scope.activeIndex||$scope.billlObj.length-1].month:"",
                    boundary_trans_id:type==1?$scope.billDetailObj[$scope.billDetailObj.length-1].trans_id:$scope.billDetailObj[0].trans_id,
                    order_by:type==1?"asc":"desc"
                };
            }
            console.log(params);
            busCenterSvc.billDetailInfo(params).then(function(data){
                console.log(data);
                if(data.ret_code=="0000") {
                if(type==2){
                    var temp=[];
                        $scope.billDetailObj=temp.concat(data.trans_list,$scope.billDetailObj);
                    }else if(type==0){
                        $scope.billDetailObj=data.trans_list;
                        $ionicScrollDelegate.scrollTop();
                }else{
                        $scope.billDetailObj=$scope.billDetailObj.concat(data.trans_list);
                    }
                    if(data.total<20){
                        $scope.loading=false;
                    }
                }else{
                    showErrorInfo(data.ret_msg);
                }
        });
        };
        //上拉
        $scope.loadPull = function () {
            $scope.postDetail(1);
            var timer=$timeout(function () {
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }, 500);
        };
        //下拉
        $scope.backPull = function () {
            $scope.postDetail(2);
            $timeout(function () {
                $scope.$broadcast('scroll.refreshComplete');
            }, 500);
        };
});