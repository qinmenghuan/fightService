/**
 * 核对用户信息
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('checkUserCtrl',
    function ($scope,
              $stateParams,
              $rootScope,
              $state,
              $interval,
              busCenterSvc,
              accountSvc,
              resourceSvc,
              util,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info=resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack=function(){
            $state.go("goodsExchange");
        };
        $scope.checkModel={
            account:emp_info.employee_phone
        };
        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = false;

        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function (phone) {
            var params={
                mobile:phone,
                busi_type:"008"
            };
            accountSvc.getCode(params).then(function(data){
                console.log(data);
                if(data.ret_code=="0000") {
                    $scope.checkModel.code_id=data.code_id;
                    $scope.checkModel.response_date=data.response_date;
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime+60*1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.phoneInvalid = true;
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        }

        $scope.nextStep = function (checkModel) {
            //验证短信验证码是否合规
            var checkSmsCode=toolSvc.checkSmsCode(checkModel.smsCode);
            if(checkSmsCode){
                showErrorInfo(checkSmsCode);
                return;
            }

            var params={
                mobile:checkModel.account,
                code:checkModel.smsCode,
                code_id:checkModel.code_id,
                response_date:checkModel.response_date
            };
            busCenterSvc.oldPhone(params).then(function(data){
                console.log(data);
                if(data.ret_code=="0000") {
                    $state.go("productInfo",{voucher_no:$stateParams.voucher_no});
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        };
});