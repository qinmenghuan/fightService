/**
 * 修改初始密码
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('changePwdCtrl',
    function ($scope,
              $rootScope,
              $state,
              util,
              busCenterSvc,
              accountSvc,
              resourceSvc,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info = resourceSvc.getLocalObj("emp_info");
        $scope.exitApp = function () {
            ionic.Platform.exitApp();
            console.log("退出app");
        };
        $scope.setPwdModel = {};
        $scope.obj = {
            step: 2
        };
        //// 设置获取验证码按钮默认状态
        //$scope.phoneInvalid = true;
        //
        //var countDown = util.countDown({timer: 60});
        //var codeText = $scope.codeText = "获取验证码";
        ////获取验证码
        //$scope.getCode = function (phone) {
        //    //判断手机号是否符合格式
        //    if (!/^1\d{10}$/.test(phone)) {
        //        return false;
        //    } else {
        //        //判断该手机号是为当前账号(写在这是因为失去焦点事件点击按钮不会触发)
        //        if (phone == "13555555555") {
        //            $scope.phoneInvalid = false;
        //            countDown.run(function (s) {
        //                $scope.codeText = s + "s后重新获取";
        //            }, codeReset);
        //        } else {
        //            //message.show("该手机号已注册！");
        //            //alert("该手机号不是当前账号！")
        //        }
        //        var params={
        //            mobile: "13555555555",
        //            busi_type: '001'
        //        };
        //        busCenterSvc.smsCode(params).then(function(result){
        //            console.log(result);
        //            $scope.formObj=result;
        //        });
        //    }
        //}
        ////重置验证码按钮
        //function codeReset() {
        //    countDown.cancel();
        //    $scope.codeText = codeText;
        //    $scope.phoneInvalid = false;
        //}
        //
        ////第一步提交手机号和验证码
        //$scope.submitFirst = function (loginPwdForm, loginPdwModel) {
        //    console.log(loginPdwModel);
        //};
        //
        //第二步设置密码
        $scope.submitSecond = function (setPwdModel) {
            console.log(setPwdModel);
            // 判断长度
            // if(setPwdModel.password&&setPwdModel.password.length<6){
            //     showErrorInfo(checkPwd);
            //     return;
            // }
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(setPwdModel.password);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }

            var params = {
                first_login: "0",
                employee_id: emp_info.employee_id,
                head_esessionid: emp_info.head_esessionid,
                employee_acount: emp_info.employee_acount,
                employee_phone: emp_info.employee_phone,
                employee_password: CryptoJS.MD5(setPwdModel.password).toString().toUpperCase()
            };
            busCenterSvc.setPwd(params).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    accountSvc.loginBus({
                        employee_acount: emp_info.employee_acount,
                        employee_password: CryptoJS.MD5(setPwdModel.password).toString().toUpperCase()
                    }).then(function (data) {
                        console.log(data);
                        if (data.ret_code == "0000") {
                            resourceSvc.setLocal("emp_info", data.emp_info);
                            $state.go("busCenter");
                        } else {
                            showErrorInfo(data.ret_msg);
                        }
                    });
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
    });