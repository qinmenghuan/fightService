/**
 * 订单追踪
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('orderTrackCtrl', ["$scope","$rootScope","$state","$filter",
    function ($scope, $rootScope, $state, $filter) {
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //var emp_info=resourceSvc.getLocalObj("emp_info");
        var date=new Date();
        $scope.conf = {
        	startTime : $filter('date')(date.setDate(date.getDate()-6),"yyyy-MM-dd"),
        	endTime : $filter('date')(new Date(),"yyyy-MM-dd")
        };
        $scope.$ionicGoBack=function(){
            $state.go("busCenter");
        };
        $scope.changeTimeHandler = function(startTime, endTime){
        	console.log(startTime, endTime);
        	$scope.conf.startTime = startTime;
        	$scope.conf.endTime = endTime;
        	if(!startTime || !endTime) return;
        	//查询单号ajax
        };
}]);