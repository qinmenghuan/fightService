/**
 * 设置
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller("busSettingCtrl",
    function ($scope,
              $rootScope,
              $state,
              busCenterSvc,
              resourceSvc,
              popupSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info = resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack = function () {
            $state.go("busCenter");
        };

        // 商户退出
        $scope.quit = function () {
            // 提示是否退出
            popupSvc.alert({
                title: "是否确认退出登录?",
                cssClass: "popup-container",
                buttons: [
                    {
                        text: '<b>确定</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            var params = {
                                employee_id: emp_info.employee_id,
                                head_esessionid: emp_info.head_esessionid
                            };
                            busCenterSvc.settingQit(params).then(function (data) {
                                console.log(data);
                                if (data.ret_code == "0000") {
                                    resourceSvc.removeLocal('emp_info');
                                    $state.go("home");
                                    // $state.go("login", {params: {comm_out: true}});
                                } else {
                                    showErrorInfo(data.ret_msg);
                                }
                            });
                        }
                    },
                    {text: '取消'}
                ]
            });
        }
    });