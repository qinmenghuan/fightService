/**
 * 修改登录密码
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('busLoginPwdCtrl',
    function ($scope,
              $rootScope,
              $state,
              $stateParams,
              util,
              busCenterSvc,
              accountSvc,
              resourceSvc,
              popupSvc,
              $timeout,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        $scope.$ionicGoBack = function () {
            $state.go("busSetting");
        };
        var emp_info = resourceSvc.getLocalObj("emp_info");
        $scope.checkStatusModel = {
            account: emp_info.employee_phone
        };
        $scope.setPwdModel = {
            password: ""
        };
        $scope.obj = {
            step: 1
        };

        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = false;
        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function (phone) {
            var params = {
                mobile: phone,
                busi_type: "008"
            };
            accountSvc.getCode(params).then(function (data) {
                if (data.ret_code == "0000") {
                    $scope.checkStatusModel.code_id = data.code_id;
                    $scope.checkStatusModel.response_date = data.response_date;
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime + 60 * 1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.phoneInvalid = true;
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        }

        //第一步
        $scope.submitFirst = function (checkStatusModel) {
            console.log(checkStatusModel);
            //验证短信验证码是否合规
            var checkSmsCode = toolSvc.checkSmsCode(checkStatusModel.smsCode);
            if (checkSmsCode) {
                showErrorInfo(checkSmsCode);
                return;
            }
            $scope.obj.step = 2;
        };
        //第二步提交密码
        $scope.submitSecond = function (setPwdModel) {
            console.log(setPwdModel);
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(setPwdModel.password);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }
            var params = {
                first_login: "1",
                employee_id: emp_info.employee_id,
                head_esessionid: emp_info.head_esessionid,
                employee_acount: emp_info.employee_acount,
                employee_phone: emp_info.employee_phone,
                employee_password: CryptoJS.MD5(setPwdModel.password).toString().toUpperCase(),
                code: $scope.checkStatusModel.smsCode,
                code_id: $scope.checkStatusModel.code_id,
                response_date: $scope.checkStatusModel.response_date
            };
            busCenterSvc.setPwd(params).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    var setSucPopup = popupSvc.alert({
                        title: "修改密码成功",
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        setSucPopup.close();
                        $state.go("busCenter");
                    }, 1000);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
    });