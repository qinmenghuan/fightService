/**
 * 更换手机号
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('busPhoneNumCtrl',
    function ($scope,
              util,
              $state,
              $stateParams,
              $rootScope,
              $timeout,
              $validation,
              popupSvc,
              resourceSvc,
              busCenterSvc,
              accountSvc,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info = resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack = function () {
            $state.go("busSetting");
        };
        $scope.phoneModel = {};
        $scope.newPhoneModel = {};
        $scope.obj = {
            validate: 1,
            title: "身份验证"
        };
        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = false;

        var codeText = $scope.codeText = "获取验证码";
        //验证旧手机号码是否正确
        $scope.phoneBlur = function (phone) {
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(phone);
            if (checkTel) {
                showErrorInfo(checkTel);
            }
        };
        //获取验证码
        $scope.getCode = function (phone, type) {
            console.log(phone);
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(phone);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            var params = {
                mobile: phone,
                busi_type: "008"
            };
            accountSvc.getCode(params).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    if (type) {
                        $scope.phoneModel.code_id = data.code_id;
                        $scope.phoneModel.response_date = data.response_date;
                    } else {
                        $scope.newPhoneModel.code_id = data.code_id;
                        $scope.newPhoneModel.response_date = data.response_date;
                    }
                    //获取当前时间毫秒数
                    var startTime = new Date().getTime();
                    //获取结束时间毫秒数
                    var endTime = startTime + 60 * 1000;
                    $scope.countDown = util.countDown({timer: endTime});
                    $scope.phoneInvalid = true;
                    $scope.countDown.run(function (s) {
                        $scope.codeText = s + "s后重新获取";
                    }, codeReset);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = false;
        }

        $scope.nextStep = function (phoneModel) {
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(phoneModel.mobile);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //验证短信验证码是否合规
            var checkSmsCode = toolSvc.checkSmsCode(phoneModel.code);
            if (checkSmsCode) {
                showErrorInfo(checkSmsCode);
                return;
            }
            var params = {
                head_esessionid: emp_info.head_esessionid,
                mobile: phoneModel.mobile,
                code: phoneModel.code,
                code_id: phoneModel.code_id,
                response_date: phoneModel.response_date
            };
            busCenterSvc.oldPhone(params).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.obj = {
                        title: "绑定新的手机",
                        validate: 2
                    };
                    codeReset();
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        $scope.submit = function (phoneModel) {
            console.log(phoneModel);
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(phoneModel.account);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //验证短信验证码是否合规
            var checkSmsCode = toolSvc.checkSmsCode(phoneModel.code);
            if (checkSmsCode) {
                showErrorInfo(checkSmsCode);
                return;
            }
            var params = {
                head_esessionid: emp_info.head_esessionid,
                employee_id: emp_info.employee_id,
                old_employee_phone: emp_info.employee_phone,
                new_employee_phone: phoneModel.account,
                code: phoneModel.code,
                code_id: phoneModel.code_id,
                response_date: phoneModel.response_date
            };
            busCenterSvc.newPhone(params).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    emp_info.employee_phone = params.new_employee_phone;
                    resourceSvc.setLocal("emp_info", emp_info);
                    var setSucPopup = popupSvc.alert({
                        title: "绑定成功",
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        setSucPopup.close();
                        $state.go("busCenter");
                    }, 1000);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
    });
