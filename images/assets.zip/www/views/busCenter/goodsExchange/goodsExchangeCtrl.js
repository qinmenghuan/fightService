/**
 * 商品兑换
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('goodsExchangeCtrl',
    function ($scope,
              $rootScope,
              $state,
              busCenterSvc,
              resourceSvc,
              $cordovaDevice,
              toolSvc) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info = resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack = function () {
            $state.go("busCenter");
        };
        $scope.exchangeModel = {};
        $scope.scanner = function () {
            console.log("console");
            document.addEventListener("deviceready", function () {
                qRcodeScanPlugin.show_qrscan(function (result) {
                    console.log("result = " + JSON.stringify(result));
                    $scope.exchangeModel.voucher_no = result;
                    $scope.nextStep({voucher_no: result});
                }, function (err) {
                    showErrorInfo(err);
                }, {});
            });
        };
        $scope.nextStep = function (exchangeModel) {
            //验证短信验证码是否合规
            var checkPwd = toolSvc.checkVoucherNo(exchangeModel.voucher_no);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }
            var params = {
                head_esessionid: emp_info.head_esessionid,
                voucher_no: exchangeModel.voucher_no
            };
            busCenterSvc.voucherInfo(params).then(function (data) {
                if (data.ret_code == "0000") {
                    $state.go("checkUser", {voucher_no: data.voucher_no});
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        }
    });