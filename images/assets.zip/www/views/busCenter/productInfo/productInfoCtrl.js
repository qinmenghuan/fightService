/**
 * 商品兑换信息
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('productInfoCtrl',
    function ($scope,
              $rootScope,
              $stateParams,
              $state,
              resourceSvc,
              busCenterSvc,
              popupSvc,
              $timeout,
              CONFIG) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var emp_info=resourceSvc.getLocalObj("emp_info");
        $scope.$ionicGoBack=function(){
            $state.go("goodsExchange");
        };
        $scope.voucher={};
        busCenterSvc.voucherInfo({
            head_esessionid:emp_info.head_esessionid,
            voucher_no:$stateParams.voucher_no
        }).then(function(data){
            if(data.ret_code=="0000") {
                $scope.voucher=data;
                $scope.voucher.imgUrl=CONFIG.HTTP_URL+"platform/showimg.json?resource_id="+data.resource_id;
            }else{
                showErrorInfo(data.ret_msg);
            }
        });
        $scope.confirm=function(){
            var params={
                head_esessionid:emp_info.head_esessionid,
                voucher_no:$stateParams.voucher_no,
                goods_name:$scope.voucher.goods_name || $scope.voucher.voucher_name,
                goods_id:$scope.voucher.goods_id
            };
            busCenterSvc.voucherOk(params).then(function(data){
                if(data.ret_code=="0000") {
                    var setSucPopup = popupSvc.alert({
                        title: "兑换成功",
                        cssClass: "popup-container",
                        buttons: []
                    });
                    $timeout(function () {
                        setSucPopup.close();
                         $state.go("busCenter");
                    }, 1000);
                }else{
                    showErrorInfo(data.ret_msg);
                }
            });
        }
});