/**
 * 商家首页
 * author suying
 * Create by suying on 2016/9/14
 * edit by
 * update by
 */
starter.controller('busCenterCtrl',
    function ($scope,
              resourceSvc,
              CONSTANT,
              encryptSvc) {
        $scope.busObj = resourceSvc.getLocalObj("emp_info");
        encryptSvc.then(function (encrypt) {
            console.log(encrypt.aesDeLocal(CONSTANT.MAIN_KEY));
        })
    });