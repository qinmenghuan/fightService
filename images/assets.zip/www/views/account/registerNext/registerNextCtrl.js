/**
 * Created by admin on 2016/9/23.
 */
starter.controller('registerNextCtrl',
    function ($scope,
              CONSTANT,
              $rootScope,
              accountSvc,
              util,
              $state,
              encryptSvc,
              toolSvc,
              permissionSvc,
              temporarySvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };

        //初始化数据
        $scope.registerData = temporarySvc.get('p1').registerData;
        console.log($scope.registerData);
        $scope.showPwd = false;

        $scope.changeShowPwd = function () {
            $scope.showPwd = !$scope.showPwd;
            console.log($scope.showPwd);
        };


        // 设置获取验证码按钮默认状态
        $scope.phoneInvalid = true;
        var codeText = $scope.codeText = "获取验证码";
        //获取验证码
        $scope.getCode = function () {
            accountSvc.getCode(
                {
                    mobile: $scope.registerData.login_name,
                    busi_type: '001'
                })
                .then(function (result) {
                    if (result.ret_code == "0000") {
                        //获取当前时间毫秒数
                        var startTime = new Date().getTime();
                        //获取结束时间毫秒数
                        var endTime = startTime + 60 * 1000;
                        $scope.countDown = util.countDown({timer: endTime});
                        $scope.phoneInvalid = false;
                        $scope.countDown.run(function (s) {
                            $scope.codeText = s + "s后重新获取";
                        }, codeReset);
                        $scope.registerData.code_id = result.code_id;
                        $scope.registerData.response_date = result.response_date;
                    } else {
                        showErrorInfo(result.ret_msg);
                        return false;
                    }
                })
        };
        //重置验证码按钮
        function codeReset() {
            $scope.countDown.cancel();
            $scope.codeText = codeText;
            $scope.phoneInvalid = true;
        }

        //从协议进来不发验证码请求
        if (temporarySvc.get('p1').lastUrl == "registerAgreement") {
        } else {
            $scope.getCode();
        }
        //$scope.checkCode = function (registerData) {
        //    console.log(registerData.code);
        //    //验证短信验证码是否合规
        //    var checkSmsCode = toolSvc.checkSmsCode(registerData.code);
        //    if (checkSmsCode) {
        //        showErrorInfo(checkSmsCode);
        //        return;
        //    }
        //};

        //$scope.checkPassword = function (registerData) {
        //    console.log(registerData.login_pwd);
        //    //验证密码是否合规
        //    var checkPwd = toolSvc.checkPwd(registerData.login_pwd);
        //    if (checkPwd) {
        //        showErrorInfo(checkPwd);
        //    }
        //};

        $scope.finishRegister = function (registerData) {
            //验证短信验证码是否合规
            var checkSmsCode = toolSvc.checkSmsCode(registerData.code);
            if (checkSmsCode) {
                showErrorInfo(checkSmsCode);
                return;
            }
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(registerData.login_pwd);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }

            var registerParams = {
                login_name: registerData.login_name,
                code: registerData.code.toString(),
                login_pwd: registerData.login_pwd,
                code_id: registerData.code_id,
                response_date: registerData.response_date
            };
            console.log(registerParams);
            accountSvc.register(registerParams).then(function (result) {
                console.log(result);
                if (result.ret_code == "0000") {
                    if (result.regist_flag == "0") {
                        console.log('注册成功');
                        accountSvc.login({
                            login_name: registerData.login_name,
                            login_pwd: registerData.login_pwd,
                            verify: "0"
                        }).then(function (data) {
                            console.log('---登录-------' + data);
                            if (data.ret_code == "0000") {
                                $state.go('setGusturePwd', {
                                    params: {
                                        step: 3,
                                        lastUrl: 'registerNext'
                                    }
                                });
                            }
                        });


                    }

                } else {
                    showErrorInfo(result.ret_msg);
                    return false;
                }

            })
        };
        $scope.goRegisterAgr = function () {
            temporarySvc.set('p1', {registerData: $scope.registerData, lastUrl: 'registerNext'});

            $state.go("registerAgreement");
        };
    });