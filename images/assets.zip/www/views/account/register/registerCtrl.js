/**
 * Created by Administrator on 2016/9/14.
 */
starter.controller('registerCtrl',
    function ($scope,
              $rootScope,
              $state,
              CONSTANT,
              accountSvc,
              toolSvc,
              temporarySvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //初始化数据
        $scope.registerData = {
            login_name: temporarySvc.get("p1").login_name || ""
        };
        $scope.goLogin=function(){
            $state.go("login")
        };
        $scope.checkPhone = function (registerData) {
            console.log(registerData.login_name);
            //验证手机号是否合规
            var checkTel=toolSvc.checkTel(registerData.login_name);
            if(checkTel){
                showErrorInfo(checkTel);
                return;
            }
            //验证手机号是否已注册参数
            var registerParams = {
                login_name: registerData.login_name
            };
            accountSvc.isRegister(registerParams).then(function (result) {
                if (result.ret_code == "0000") {
                    if (result.is_regist == "0") {
                        temporarySvc.set('p1', {registerData: $scope.registerData});
                        $state.go('registerNext');
                    } else {
                        showErrorInfo(CONSTANT.PHONE_ALREADY)
                    }
                } else {
                    showErrorInfo(result.ret_msg);
                }
            })
        };
        // $scope.goRegisterAgr = function () {
        //     $state.go("registerAgreement", {registerData: $scope.registerData, lastUrl: 'register'})
        // };
    });
