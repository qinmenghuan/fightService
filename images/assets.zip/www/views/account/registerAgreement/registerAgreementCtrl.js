/**
 * Created by mazh on 2016/9/14.
 */
/**
 * 注册页控制器
 * @author mazh 2016年04月20日
 */
starter.controller('registerAgreementCtrl',
    function ($scope,
              $state,
              $rootScope,
              $timeout,
              $sce,
              $log,
              accountSvc,
              temporarySvc) {

        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        //获取注册信息
        $scope.registerData = temporarySvc.get('p1').registerData;
        //返回注册页
        $scope.goRegister = function () {
            temporarySvc.set('p1', {registerData: $scope.registerData, lastUrl: 'registerAgreement'});
            $state.go("registerNext");
        };
        //查询协议参数
        var agreementParams = {
            protocol_type: "0"
        };
        accountSvc.getAgr(agreementParams).then(
            function (data) {
                $log.log(data);
                if (data.ret_code == "0000") {
                    $scope.contentHtml = $sce.trustAsHtml(data.protocol_content);
                } else {
                    showErrorInfo(data.ret_msg);
                }
            }, function (err) {
                $log.log(err);
            }
        );

    });
