'use strict';
starter.controller('loginGesturePwdCtrl',
    function ($scope,
              $state,
              $stateParams,
              $gestureLock,
              $timeout,
              resourceSvc,
              GestureLockService,
              $ionicHistory,
              encryptSvc,
              CONSTANT,
              util,
              CONFIG,
              pageJumpSvc) {
        $scope.loginGesturePwd = {};
        var user_id;
        var gesturePwd;
        encryptSvc.then(function (encrypt) {
            var user_info = encrypt.aesDeObjectL(CONSTANT.USER_INFO),
                user_id = user_info.user_id;
            console.log(user_info);
            $scope.loginGesturePwd.mobile = user_info.mobile;
            $scope.loginGesturePwd.pwd = encrypt.aesDeObjectL(user_id + "gesturePwd");
            if (user_info.icon_type == '1') {
                $scope.loginGesturePwd.userPic = 'images/mine/' + user_info.icon_addr;
            } else if (user_info.icon_type == '2') {
                $scope.loginGesturePwd.userPic = CONFIG.HTTP_URL + "platform/showimg.json?resource_id=" + user_info.icon_addr;
            }
            console.log($scope.loginGesturePwd.pwd);
        });
        var isValidate = true;
        var UNLOCK_TEXT = "绘制图案解锁";
        $scope.title = UNLOCK_TEXT;

        var passwords = [2];
        var count = 1;
        if (!isValidate) {
            $scope.title = "请输入原密码";
        }
        $scope.$on('$ionicView.enter', function () {
            $scope.$broadcast('canvas.init');
        });


        var setPwdCount = 0,
            pwd1 = '';
        $scope.gesturePwd = [false, false, false, false, false, false, false, false, false];
        $scope.chooseFn = function () {
        };
        var errorCount = resourceSvc.getLocal("errorCount", 0);
        checkLock();
        $scope.touchend = function (gesture) {
            if (checkLock()) {
                //已锁定
                gesture.clear();
                return;
            }
            setPwdCount++;
            var pwd = gesture.orders.join('');
            //第一次设置密码
            if (setPwdCount === 1) {
                if (pwd.length < 4) {
                    $scope.title = "请至少选择四个圆！";
                    setPwdCount = 0;
                    $timeout(function () {
                        gesture.clear();
                    }, 500);
                    return;
                }
                if ($scope.loginGesturePwd.pwd == pwd) {
                    console.log("手势登录成功：" + pwd);
                    resourceSvc.setLocal("errorcount", errorCount = 0);
                    //手势登录
                    if ($ionicHistory.backView()) {
                        //$ionicHistory.goBack(-1);
                        $rootScope.$ionicGoBack();
                    } else {
                        $state.go("home");
                    }
                } else {
                    resourceSvc.setLocal("errorCount", ++errorCount);
                    if (errorCount < 5) {
                        $scope.title = "输入错误，您还有" + (5 - errorCount) + "次输入机会";
                    } else {
                        var unlockTime = new Date().getTime() + 5 * 60 * 1000;
                        countDown(unlockTime);
                        resourceSvc.setLocal("unlockTime", unlockTime);
                    }
                    console.log("手势登录失败：" + pwd);
                    setPwdCount = 0;
                    gesture.errorStatus();
                }
                setTimeout(function () {
                    gesture.clear();
                }, 500);
            }
        };

        /**
         * 判断是否锁定
         * @returns {boolean} 是否已锁定
         */
        function checkLock() {
            var unlock = resourceSvc.getLocal("unlockTime", null);
            if (unlock) {
                //已锁定
                if (unlock > new Date().getTime()) {
                    console.log("已锁定");
                    countDown(unlock);
                } else {
                    // 已超过解锁时间，但仍有锁定信息，要解除锁定状态，错误次数清零
                    resourceSvc.setLocal("errorCount", 0);
                    resourceSvc.removeLocal("unlockTime");
                }
                return true;
            }
            return false;
        }

        /**
         * 开始倒计时
         * @param unlockTime 解除锁定的时间（1970年的毫秒数）
         */
        function countDown(unlockTime) {
            if ($scope.countDown) {
                return;
            }
            //启动倒计时
            $scope.countDown = util.countDownTimer(new Date().getTime(), unlockTime, function (DHMS) {
                if (DHMS) {
                    $scope.title = "手势密码已锁定，" + DHMS.mStr + ":" + DHMS.sStr + "后解锁";
                    if (DHMS.mins == 0 && DHMS.seconds == 0) {
                        resourceSvc.setLocal("errorCount", 0);
                        resourceSvc.removeLocal("unlockTime");
                        $scope.title = UNLOCK_TEXT;
                    }
                }
            });
        }

        //忘记手势密码
        $scope.goSetGus = function () {
            pageJumpSvc.nextPageGoBack({
                currentState: "loginGesturePwd",
                nextState: "checkLoginPwd",
                goBack: "loginGesturePwd"
            });
            $state.go('checkLoginPwd')
        };
        //去登录页
        $scope.goLogin = function () {
            $state.go('login', {params: {url: 'loginGesturePwd'}})
        };
        //退出app
        $scope.quitApp = function () {
            ionic.Platform.exitApp();
        }
    });
