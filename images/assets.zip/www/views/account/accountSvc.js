/**
 * Created by mazh on 2016/10/4.
 */
starter.factory("accountSvc",
    function (httpSvc, $http, encryptSvc, CONSTANT, permissionSvc) {
        return {
            //验证手机号是否已注册
            isRegister: function (params) {
                return httpSvc.post("user030001.json", params).then(function (data) {
                    return data;
                });

            },

            //获取验证码
            getCode: function (params) {
                return httpSvc.post("pub010301.json", params).then(function (data) {
                    return data;
                });

            },
            //注册
            register: function (params) {
                return httpSvc.post("user030002.json", params).then(function (data) {
                    return data;
                });

            },

            //登录
            login: function (params) {
                return httpSvc.post("user030003.json", params).then(function (data) {
                    if (data.ret_code == "0000") {
                        encryptSvc.then(function (encrypt) {
                            //保存用户信息到session
                            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                            var value = {};
                            value[CONSTANT.JSESSIONID_UNIT] = data.jsessionid_unit;
                            value[CONSTANT.JSESSIONID_TIME] = new Date().getTime() + (data.jsessionid_unit * 1000);
                            angular.extend(value, data.user_info);
                            userInfo.save(value);
                            //保存帐户状态和head_jsessionid
                            encrypt.aesEnLocal(CONSTANT.HEAD_JSESSIONID, data.head_jsessionid);
                            encrypt.aesEnObjectL(CONSTANT.ACCOUNT_INFO, data.acctstep_list);
                            permissionSvc.setUserType("login");
                        });
                    }
                    console.log(data);
                    return data;
                });

            },
            //商户登录
            loginBus: function (params) {
                return httpSvc.post("merchant090101.json", params).then(function (data) {
                    return data;
                });

            },
            //注册协议
            getAgr: function (params) {
                return httpSvc.post("sys020405.json", params).then(function (data) {
                    return data;
                });

            }

        }
    });