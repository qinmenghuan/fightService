/**
 * Created by kayak on 16/9/18.
 */
starter.controller('loginCtrl',
    function ($scope,
              $rootScope,
              $state,
              pageJumpSvc,
              httpSvc,
              accountSvc,
              util,
              encryptSvc,
              resourceSvc,
              permissionSvc,
              temporarySvc,
              CONSTANT,
              $ionicHistory,
              toolSvc, $stateParams) {
        document.addEventListener("deviceready", function () {
            console.log("=====================homeAD splash 隐藏时间：" + (new Date().getTime()));
            if (navigator.splashscreen) navigator.splashscreen.hide();
        });
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
            $scope.loginModel.login_pwd = "";
        };


        //获取registrationID
        var registrationid = resourceSvc.getLocal('registrationid');

        //获取商户登录退出传参
        if ($stateParams.params && $stateParams.params.comm_out) {
            $scope.comm_out = $stateParams.params.comm_out;
        }

        //默认显示用户登录
        $scope.loginWay = false;

        if ($scope.comm_out) {
            $scope.loginWay = true;

        }

        console.log("----------111111---------------" + $scope.loginWay);
        //切换用户/商户登录
        $scope.siwtchLoginWay = function () {
            $scope.loginWay = !$scope.loginWay;
            console.log($scope.loginWay);
        };

        console.log("----------22222--------------" + $scope.loginWay);
        //初始化登录参数
        $scope.loginModel = {};
        $scope.loginGoBack = function () {
            encryptSvc.then(function (encrypt) {
                var user_Info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                user_Info.clear();
                resourceSvc.removeLocal(CONSTANT.HEAD_JSESSIONID);
                pageJumpSvc.nextPageGoBack({
                    currentState: "login",
                    nextState: "loginGesturePwd",
                    goBack: "login"
                });
                $state.go('home');
            });
        };
        $scope.showPwd = false;
        $scope.changeShowPwd = function () {
            $scope.showPwd = !$scope.showPwd;
            console.log($scope.showPwd);
        };
        //var message = $validation.message("form-phone");
        //$scope.phoneBlur = function (account) {
        //    httpSvc.post("user130102.json", {account: account}).then(function (data) {
        //        if (data.head_ret_code === CONSTANT.HEAD_RET_CODE_SUCCESS) {
        //            $scope.phoneInvalid = false;
        //            message.hide();
        //        } else {
        //            message.show(data.head_ret_msg);
        //        }
        //    })
        //};
        console.log($scope.checkValid);
        $scope.submit = function (loginrModel) {
            //验证手机号是否合规
            var checkTel = toolSvc.checkTel(loginrModel.login_name, false);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //验证密码是否合规
            var checkPwd = toolSvc.checkPwd(loginrModel.login_pwd);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }
            accountSvc.login({
                login_name: loginrModel.login_name,
                login_pwd: loginrModel.login_pwd,
                verify: "1",
                registrationid: registrationid
            }).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    console.log("登录成功");
                    if (permissionSvc.autoGoState()) {
                        //$rootScope.$ionicGoBack();
                        $state.go('mine');
                    }
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        $scope.submitbus = function (loginrModel) {
            //验证商户账户是否合规
            var checkTel = toolSvc.checkBusAccount(loginrModel.employee_acount);
            if (checkTel) {
                showErrorInfo(checkTel);
                return;
            }
            //验证商户密码是否合规
            var checkPwd = toolSvc.checkBusPwd(loginrModel.employee_password);
            if (checkPwd) {
                showErrorInfo(checkPwd);
                return;
            }
            accountSvc.loginBus({
                employee_acount: loginrModel.employee_acount,
                employee_password: CryptoJS.MD5(loginrModel.employee_password).toString().toUpperCase()
            }).then(function (data) {
                if (data.ret_code == "0000") {
                    resourceSvc.setLocal("emp_info", data.emp_info);
                    if (data.emp_info.first_login == "0") {
                        $state.go("changePwd");
                    } else {
                        $state.go("busCenter");
                    }
                } else {
                    showErrorInfo(data.ret_msg);
                }
            });
        };
        $scope.goRegister = function (loginModel) {
            pageJumpSvc.nextPageGoBack({
                currentState: "login",
                nextState: "register",
                goBack: "login"
            });
            temporarySvc.set("p1", {login_name: loginModel.login_name});
            $state.go('register')
        };
        $scope.forgetLoginPwd = function () {
            pageJumpSvc.nextPageGoBack({
                currentState: "login",
                nextState: "setLoginPwd",
                goBack: "login"
            });
            $state.go('setLoginPwd', {params: {lastUrl: 'login'}});
        }
    }
);