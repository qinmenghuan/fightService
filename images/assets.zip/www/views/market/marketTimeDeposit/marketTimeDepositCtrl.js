/**
 * Created by kayak on 16/9/19.
 */
starter.controller('marketTimeDepositCtrl',
    function ($scope,
              util,
              $state,
              investSvc,
              encryptSvc,
              CONSTANT,
              mineSvc,
              popupSvc,
              tryCounter,
              $rootScope,
              temporarySvc,
              $filter) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get("p5") || {}; //获取列表页存储的当前产品数据
        console.log(params);
        $scope.conf = {
            record_id: params.record_id ? params.record_id : "",
            prod_code: params.prod_code,
            slideBox: params.slideBox
        }
        //初始化试算各参数
        $scope.counter = {
            time: "",
            money: "",
            level: ""
        };
        $scope.config = {
            rateMoney: ''//试算收益
            , rateBank: ''//银行收益
            , CounterMoneyName: '定期智能存款收益'
            , CounterBankName: '银行定期存款收益'
        };

        function rushActivity() {
            var start_time = $filter("FormData")($scope.confInfo.start_date_time).getTime();
            var end_time = $filter("FormData")($scope.confInfo.end_date_time).getTime();
            var now_time = new Date().getTime();
            if (now_time - start_time < 0) {
                util.countDownTimer(now_time, start_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "2";
                        util.countDownTimer(start_time, end_time, function (DHMS) {
                            $scope.confInfo.time = DHMS;
                            if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                                $scope.confInfo.time_flag = "3";
                            }
                        })
                    }
                })
            } else if (now_time - end_time < 0) {
                $scope.confInfo.time_flag = "2";
                util.countDownTimer(now_time, end_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "3";
                    }
                })
            } else {
                $scope.confInfo.time_flag = "3";
            }
        }

        //初始化智能存定期产品信息
        $scope.timeDetail = {};
        //获取智能存定期产品信息
        investSvc.timeDepositDetail({prod_code: $scope.conf.prod_code}).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            $scope.timeDetail = data;
            $scope.timeDetail.record_id = $scope.conf.record_id;
            console.log($scope.timeDetail);
            //console.log($scope.timeDetail.prod_lifecycle);
            var activityInfo = $scope.timeDetail.rush_list[0];
            console.log(activityInfo);
            $scope.confInfo = {
                start_date_time: activityInfo.start_date_time || "",
                end_date_time: activityInfo.end_date_time || "",
                rush_type: activityInfo.rush_type,
                max_rush_money: activityInfo.max_rush_money || 0,
                max_rush_times: activityInfo.max_rush_times || 0,
                time_flag: "1",
                time: {
                    days: "",
                    hours: "",
                    mins: "",
                    seconds: "",
                    dif: ""
                }
            };
            rushActivity();
            //判断按钮状态
            encryptSvc.then(function (encrypt) {
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        } else {
                            $scope.buyStatus = 5; // 购买
                        }
                    })

                }
                /*else if (encrypt.aesDeObjectS(CONSTANT.ACCOUNT_INFO) == 1 && $scope.item.prod_lifecycle == 8) {
                 $scope.buyStatus = '3';  //已完结
                 } else if ($scope.item.prod_lifecycle == 5) {
                 $scope.buyStatus = '7';  //收益中
                 } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount == 0) {
                 $scope.buyStatus = '4';  //已售罄
                 } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount != 0) {
                 $scope.buyStatus = '5'; // 购买
                 }*/
            });
        });
        //未登录时，去登录  url: 'prod_detail'?什么意思
        $scope.goLogin = function () {

            $state.go('login', {params: {url: 'marketTimeDeposit'}})
        };
        //点击购买
        $scope.depositBuy = function () {
            /*var data = {
             prod_subclass: $scope.timeDetail.prod_subclass,
             prod_code: $scope.timeDetail.prod_code,
             prod_name: $scope.timeDetail.prod_name,
             crt_orgno: $scope.timeDetail.crt_orgno
             };*/
            angular.extend($scope.timeDetail, {market: true});
            console.log($scope.timeDetail);
            temporarySvc.set("p2", $scope.timeDetail);
            $state.go("timeDepositBuy");
        };
        //试算
        $scope.popTryCounter = function () {
            popupSvc.alert({
                templateUrl: "views/invest/investDialog/tryCounter.html",
                scope: $scope,
                cssClass: "hide-btn try-counter",
                buttons: [{
                    text: '&#xe620;',
                    type: 'button-default iconfont',
                    onTap: function (e) {
                    }
                }]
            });
            $scope.counter = tryCounter.init();
            getTryscope();
        };
        var getTryscope = function (params) {
            var data = angular.extend({
                prod_code: $scope.conf.prod_code,
                znck_trlday: $scope.counter.time,
                znck_trlamt: $scope.counter.money,
                znck_cstlvl: $scope.counter.level
            }, params);
            console.log(data);
            investSvc.timeDepositCounter(data).then(function (data) {
                console.log(data);
                if (data.ret_code == "0000") {
                    $scope.config.rateMoney = data.trl_intamt;
                    $scope.config.rateBank = data.curr_intamt;

                }
            })
        };
        //加载详情页，即显示默认的10万，1年，普卡的试算结果
        getTryscope({
            znck_trlday: "365",
            znck_trlamt: "100000",
            znck_cstlvl: "1"
        });
        $scope.speedyChoose = function (type, str, $index) {
            tryCounter.speedyChoose(type, str, $index, getTryscope);
        }
    }
);