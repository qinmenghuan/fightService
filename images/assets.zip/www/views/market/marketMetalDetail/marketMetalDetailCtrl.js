/**
 * Created by kayak on 16/9/19.
 */
starter.controller('marketMetalDetailCtrl',
    function ($scope,
              $state,
              $stateParams,
              investSvc,
              $rootScope,
              popupSvc,
              encryptSvc,
              CONFIG,
              CONSTANT,
              mineSvc,
              homeSvc,
              temporarySvc,
              util,
              $timeout,
              $filter) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get("p5") || {};
        console.log(params);
        $scope.conf = {
            record_id: params.record_id ? params.record_id : ""
            , prod_code: params.prod_code
            , slideBox: params.slideBox
        };
        $scope.showStatus = false;
        $scope.showInfo = function () {
            $scope.showStatus = !$scope.showStatus;
        };
        //初始化购物车数量加减,获取分享ID
        $scope.item = {
            number: 1,
            record_id: $scope.conf.record_id
        };

        //商品数量增减
        $scope.minus = function () {
            if ($scope.item.number != 0) {
                $scope.item.number -= 1;
            }
        };
        $scope.plus = function () {
            $scope.item.number += 1;
        };
        function rushActivity() {
            var start_time = $filter("FormData")($scope.confInfo.start_date_time).getTime();
            var end_time = $filter("FormData")($scope.confInfo.end_date_time).getTime();
            var now_time = new Date().getTime();
            if (now_time - start_time < 0) {
                util.countDownTimer(now_time, start_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "2";
                        util.countDownTimer(start_time, end_time, function (DHMS) {
                            $scope.confInfo.time = DHMS;
                            if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                                $scope.confInfo.time_flag = "3";
                            }
                        })
                    }
                })
            } else if (now_time - end_time < 0) {
                $scope.confInfo.time_flag = "2";
                util.countDownTimer(now_time, end_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "3";
                    }
                })
            } else {
                $scope.confInfo.time_flag = "3";
            }
        }

        var data = {
            prod_sub_id: $scope.conf.prod_code
        };
        investSvc.metalDetail(data).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            angular.extend($scope.item, data);
            $scope.item.nowPrice = $scope.item.discount_flag == '1' ? $scope.item.discount_price : $scope.item.fixed_price;
            var activityInfo = $scope.item.rush_list[0];
            console.log(activityInfo);
            $scope.confInfo = {
                start_date_time: activityInfo.start_date_time || "",
                end_date_time: activityInfo.end_date_time || "",
                rush_type: activityInfo.rush_type,
                rush_type_text: '',
                rush_type_text2: '',
                max_rush_money: activityInfo.max_rush_money || "",
                max_rush_times: activityInfo.max_rush_times || "",
                time_flag: "1",
                time: {
                    days: "",
                    hours: "",
                    mins: "",
                    seconds: "",
                    dif: ""
                }
            };
            if ($scope.confInfo.rush_type == '1') {
                $scope.confInfo.rush_type_text = '限额';
                $scope.confInfo.rush_type_text2 = '元';
            } else if ($scope.confInfo.rush_type == '2') {
                $scope.confInfo.rush_type_text = '限份';
                $scope.confInfo.rush_type_text2 = '份';
            }
            console.log($scope.confInfo.rush_type_text);
            rushActivity();
            encryptSvc.then(function (encrypt) {
                console.log(encrypt.aesDeObjectL(CONSTANT.ACCOUNT_INFO));
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        } else {
                            $scope.buyStatus = 5; // 购买
                        }
                    })

                }
            });
        });
        $scope.metalBuy = function () {
            var data = angular.extend($scope.item, {market: true});
            console.log(data);
            if ($scope.confInfo.rush_type == '1') {
                console.log(data.number * data.nowPrice);
                if (data.number * data.nowPrice > data.rush_list[0].max_rush_money) {
                    showErrorInfo('超出限购金额');
                    return false;
                }
            } else if ($scope.confInfo.rush_type == '2') {
                if (data.number > data.rush_list[0].max_rush_money) {
                    showErrorInfo('超出限购份数');
                    return false;
                }
            }
            temporarySvc.set("p2", data);
            $state.go('metalBuy')
        };
        $scope.goLogin = function () {
            $state.go('login', {params: {url: 'metal'}})
        };

    });