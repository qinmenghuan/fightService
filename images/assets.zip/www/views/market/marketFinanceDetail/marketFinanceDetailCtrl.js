/**
 * Created by kayak on 16/9/19.
 */
starter.controller('marketFinanceDetailCtrl',
    function ($scope,
              $state,
              $stateParams,
              $ionicLoading,
              $ionicPopup,
              $timeout,
              investSvc,
              homeSvc,
              popupSvc,
              CONSTANT,
              encryptSvc,
              CONFIG,
              mineSvc,
              temporarySvc,
              shareApp,
              $ionicScrollDelegate,
              $ionicSlideBoxDelegate,
              $cordovaClipboard,
              $interval,
              $rootScope,
              $q,
              $filter,
              pdfSvc,
              util) {
        //错误提示信息控制
        var showErrorInfo = function (info) {
            $rootScope.errorMsg = info;
            $rootScope.tipShow = true;
        };
        var params = temporarySvc.get("p5") || {};
        console.log(params);
        $scope.conf = {
            record_id: params.record_id ? params.record_id : "",
            prod_code: params.prod_code,
            slideBox: params.slideBox
        };
        //初始化用户信息
        var user_info = {};
        encryptSvc.then(function (encrypt) {
            user_info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
        });
        console.log(user_info);
        $scope.isPull = false;
        //上拉下拉
        console.log($scope.isPull);
        document.getElementById("content").addEventListener("touchstart", function () {
            $scope.$apply();
        });
        //上拉
        $scope.loadPull = function () {
            $timeout(function () {
                console.log($scope.isPull);
                $scope.isPull = true;
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }, 500);
        };

        //下拉返回
        $scope.backPull = function () {
            $timeout(function () {
                $scope.isPull = false;
                $scope.$broadcast('scroll.refreshComplete');
                $ionicScrollDelegate.scrollTop();
            }, 500);
        };
        console.log($scope.isPull);
        $scope.step = 0;
        //选项卡
        $scope.changeTab = function (index) {
            var a = document.getElementById('sub_header_list').getElementsByTagName('a');
            for (var i = 0; i < 4; i++) {
                a[i].className = "tab-item ";
            }
            a[index].className = "tab-item sub_button_select";
            $scope.step = index;
        };
        function rushActivity() {
            var start_time = $filter("FormData")($scope.confInfo.start_date_time).getTime();
            var end_time = $filter("FormData")($scope.confInfo.end_date_time).getTime();
            var now_time = new Date().getTime();
            if (now_time - start_time < 0) {
                util.countDownTimer(now_time, start_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "2";
                        util.countDownTimer(start_time, end_time, function (DHMS) {
                            $scope.confInfo.time = DHMS;
                            if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                                $scope.confInfo.time_flag = "3";
                            }
                        })
                    }
                })
            } else if (now_time - end_time < 0) {
                $scope.confInfo.time_flag = "2";
                util.countDownTimer(now_time, end_time, function (DHMS) {
                    $scope.confInfo.time = DHMS;
                    if (!DHMS.days && !DHMS.hours && !DHMS.mins && !DHMS.secounds && !DHMS.dif) {
                        $scope.confInfo.time_flag = "3";
                    }
                })
            } else {
                $scope.confInfo.time_flag = "3";
            }
        }

        var data = {
            prod_code: $scope.conf.prod_code
        };
        //获取惠理财详情
        investSvc.financeDetail(data).then(function (data) {
            if (data.ret_code != "0000") {
                showErrorInfo(data.ret_msg);
                return;
            }
            $scope.item = data;
            $scope.item.record_id = $scope.conf.record_id;
            var activityInfo = $scope.item.rush_list[0];
            console.log(activityInfo);
            $scope.confInfo = {
                start_date_time: activityInfo.start_date_time || "",
                end_date_time: activityInfo.end_date_time || "",
                rush_type: activityInfo.rush_type,
                max_rush_money: activityInfo.max_rush_money || 0,
                max_rush_times: activityInfo.max_rush_times || 0,
                time_flag: "1",
                time: {
                    days: "",
                    hours: "",
                    mins: "",
                    seconds: "",
                    dif: ""
                }
            };


            rushActivity();
            //angular.extend($scope.item, data);
            //$scope.item.is_buy 1为已买过，0为未买过
            console.log($scope.item);
            encryptSvc.then(function (encrypt) {
                console.log(encrypt.aesDeObjectL(CONSTANT.ACCOUNT_INFO));
                if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                    $scope.buyStatus = 1; //登录
                } else {
                    mineSvc.queryAccountStatus().then(function (data) {
                        if (encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID) && data.acctstep_list[2].flag != '1') {
                            $scope.buyStatus = 2; //安全认证
                        }
                        else if (data.acctstep_list[2].flag == '1' && $scope.item.prod_lifecycle == 8) {
                            $scope.buyStatus = '3';  //已完结
                        } else if ($scope.item.prod_lifecycle == 5 || $scope.item.prod_lifecycle == 4) {
                            $scope.buyStatus = '7';  //收益中
                        } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount == 0) {
                            $scope.buyStatus = '4';  //已售罄
                        } else if ($scope.item.prod_lifecycle == 2 && $scope.item.remain_amount != 0) {
                            $scope.buyStatus = '5'; // 购买
                        }
                    })
                }
            });

            //剩余金额进度条
            var money_width = document.getElementsByClassName('line-main')[0].offsetWidth;
            console.log(money_width);
            $scope.item.percent_money = 1 - ( $scope.item.remain / $scope.item.total_quota);
            console.log($scope.item.percent_money);
            document.getElementById('line_move').style.width = money_width * $scope.item.percent_money + 'px';
        });


        $scope.goLogin = function () {
            $state.go('login');
            //$state.go('login', {params: {url: 'marketFinance'}})
        };
        $scope.accountSafe = function () {
            $state.go('accountSafe');
            //$state.go('accountSafe', {params: {url: 'finance'}})
        };
        $scope.goBuy = function () {
            mineSvc.queryRiskLv().then(function (data) {
                if ($scope.item.risk_level > data.risk_level) {
                    $state.go("buyFailed");
                } else {
                    angular.extend($scope.item, {market: true});
                    console.log($scope.item);
                    temporarySvc.set("p2", $scope.item);
                    $state.go('buy');
                }
            })

        };

        //查看pdf文档
        var address, title;
        if (!CONFIG.DEBUG_ON_CHROME) {
            document.addEventListener("deviceready", function () {
                $scope.downPdf = function (val) {
                    if (val == 0) {
                        address = $scope.item.prod_txt_inter_path;
                        title = "购买说明";
                    } else if (val == 1) {
                        address = $scope.item.prod_txt_exp_path;
                        title = "产品说明书";
                    } else if (val == 2) {
                        address = $scope.item.prod_txt_risk_path;
                    }
                    title = "风险提示";
                    var url = CONFIG.HTTP_URL + 'platform/downloadfile?resource_id=' + address;
                    console.log(url);
                    // window.open(url, '_blank', 'location=yes');
                    // var ref = cordova.InAppBrowser.open(url, '_blank', 'location=no');
                    //$rootScope.jumpOut(url, title);
                    pdfSvc.readPDF(url, title);
                }
            }, false)
        }
    });