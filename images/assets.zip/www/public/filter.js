/**
 * 过滤器
 * Created by fusy on 2016/9/6.
 */
publicModule.filter('hidePhone', function () {
    return function (datas) {
        if (datas != null && datas.length == 11) {
            var str1 = (datas + "").substring(0, 3);
            var str2 = (datas + "").substring(9, 11);
            return str1 + '******' + str2;
        } else {
            return datas
        }
    }
})
//将20160101转变为01月01日
    .filter('timefilter1', function () {
        return function (str) {
            if (str) {
                str = String(str);
                var finalDate = str.slice(4, 6) + '月' + str.slice(6, 8) + '日';
                return finalDate;
            }
        }
    })
    //通过日期获取星期  05月04日 周一
    .filter("week", function () {
        return function (str) {
            if (str) {
                var weekArray = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
                str = String(str);
                var finalDate = str.slice(4, 6) + '月' + str.slice(6, 8) + '日';
                var week = weekArray[new Date(str.slice(0, 4), str.slice(4, 6) - 1, str.slice(6, 8)).getDay()];
                return finalDate + "   " + week;
            }
        }
    })
    //米转为千米
    .filter('fixTo', function () {
        return function (input) {
            if (input > 10000) {

                input = input / 1000;
                input = parseInt(input);
                input += 'km';
            } else {

                input = parseInt(input);
                input += 'm';
            }

            return input;

        }
    })
    //产品年化收益
    .filter('expeRateFilter', function () {
        return function (data) {
            return (data * 100).toFixed(2);
        }
    })
    //格式化金额
    .filter('moneyFilter', function () {
        return function (data) {
            if (data >= 10000) {
                return (data / 10000) + '万'
            } else {
                return data;
            }
        }
    })

    //格式化金额，不保留小数点位数
    .filter('zsmoneyFilter', function () {
        return function (data) {
            if (data >= 10000) {
                return (data / 10000) + '万'
            }
        }
    })

    //格式化金额2，保留小数点后2位
    .filter('moneyFilter2', function () {
        return function (data) {
            if (data) {
                return Number(data).toFixed(2)
            }
        }
    })
    //格式化金额2，保留小数点后2位
    .filter('moneyFilter3', function () {
        return function (data) {
            if (data >= 10000) {
                return (data / 10000).toFixed(0) + '万'
            } else {
                return data
            }
        }
    })
    //智能存款持有期限
    .filter('incDueFilter', function () {
        return function (data) {
            if (data) {
                if (data.substring(0, 1) == 'D') {
                    return data.substring(1, 2) + '天';
                } else if (data.substring(0, 1) == "M") {
                    return data.substring(1, 2) + '月';
                } else if (data.substring(0, 1) == "Y") {
                    return data.substring(1, 2) + '年';
                }
            }
        }
    })
    //智能存款支取方式
    .filter('fixDrawTypeFilter', function () {
        return function (data) {
            switch (data) {
                case '0':
                    return '不可支取';
                    break;
                case '1':
                    return '随时可取';
                    break;
                case '2':
                    return '整存整取';
                    break;
                default:
                    return false;
            }
        }
    })
    //产品单位
    .filter('normFilter', function () {
        return function (data) {
            switch (data) {
                case '0':
                    return '克';
                    break;
                case '1':
                    return '盎司';
                    break;
                case '2':
                    return '枚';
                    break;
                case '3':
                    return '套';
                default:
                    return false;
            }
        }
    })

    //贵金属价格
    .filter('metalSortFilter', function () {
        return function (data) {
            var data1;
            switch (data) {
                case 1:
                    data1 = {
                        order_type: '1',
                        order: '1'
                    };
                    return data1;
                    break;
                case 2:
                    data1 = {
                        order_type: '0',
                        order: '1'
                    };
                    return data1;
                    break;
                case 3:
                    data1 = {
                        order_type: '2',
                        order: '0'
                    };
                    return data1;
                    break;
                case 4:
                    data1 = {
                        order_type: '2',
                        order: '1'
                    };
                    return data1;
                    break;
            }

        }
    })
    //贵金属详情产品种类
    .filter('metalDetailProdTypeFilter', function () {
        return function (data) {
            switch (data) {
                case '1':
                    return '代销工艺金';
                    break;
                case '2':
                    return '代销投资金';
                    break;
                case '3':
                    return '自营工艺金';
                    break;
                case '4':
                    return '自营投资金';
                    break;
            }
        }
    })
    //银行卡尾号
    .filter('bankCardTail', function () {
        return function (data) {
            return data.substring(data.length - 4, data.length);
        }
    })

    //收益类型
    .filter('incomeFilter', function () {
        return function (data) {
            switch (data) {
                case '1':
                    return '非保本浮动收益类';
                    break;
                case '2':
                    return '保本浮动收益类';
                    break;
                case  '3':
                    return '保证收益类';
                    break;
            }
        }
    })
    //日期格式化加空格
    .filter('formatDay1', function () {
        return function (strs) {
            if (!strs)return '';
            var str;
            str = strs.substring(0, 4) + '-' + strs.substring(4, 6) + '-' + strs.substring(6, 8);
            return str;
        }
    })


    //筛选出未投资,已投资的银行卡
    .filter('bankCardFilter', function () {
        return function (data) {
            var result = {};
            console.log(data);
            angular.forEach(data, function (value, key) {
                if (value.invest_status != '2') {
                    console.log(result);
                    result[key] = value;
                }
            });
            console.log(result);
            return result;
        };

    })
    /**
     *
     *    金额转换，四舍五不入---向下取整
     *示例：{{ value | floorTenthousand }}
     */
    .filter('floorTenthousand', function () {
        return function (datas) {
            var data = datas + "";
            var re = /^[0-9]*[1-9][0-9]*$/;
            if (data < 10000) {
                // return data;
                // return Math.floor(data*100)/100;

                var f = parseFloat(data);
                if (isNaN(f)) {
                    return '0.00';
                }
                var f = Math.floor(data * 100) / 100;
                var s = f.toString();
                var rs = s.indexOf('.');
                if (rs < 0) {
                    rs = s.length;
                    s += '.';
                }
                while (s.length <= rs + 2) {
                    s += '0';
                }
                return s;
            } else {
                data = data / 10000;
                if (re.test(data)) {
                    return data + '.00万';
                } else {
                    var dataStr = data.toString();
                    return dataStr.slice(0, dataStr.indexOf(".") + 3) + '万';
                }
            }
        }
    })

    /**
     *时间格式化：时|分|秒
     */
    .filter("formatTimeItem", function () {
        return function (value) {
            var result = "";
            if (value) {
                if (value < 10) {
                    result = "0" + value;
                } else {
                    result = "" + value;
                }
            } else {
                result = "00";
            }
            return result;
        }
    });
