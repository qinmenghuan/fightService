/**
 * Created by fei on 16/9/14.
 */
publicModule.filter('prodYield', function ($sce) {
    return function (data) {
        if (!data) return;
        var strongText = data.substring(0, 1);
        var yieldText = data.substring(1, data.length);
        var htmlStr = '<span class="yield-strong">' + strongText + '</span>' + yieldText;
        return $sce.trustAsHtml(htmlStr);
    }
})
    .filter('formatDay', function () {
        return function (time) {
            var date = new Date(time);
            var mon = date.getMonth() + 1;
            var day = date.getDate();
            return date.getFullYear() + "-" + (mon < 10 ? "0" + mon : mon) + "-" + (day < 10 ? "0" + day : day);
        }
    })
    //计算两个日期之间的天数
    /*.filter("diffDate", function () {
     return function (d1, d2){
     var p1 = new Date(Number(d1.substring(0,4)), Number(d1.substring(4,6)) - 1, Number(d1.substring(6,8)))
     var p2 = new Date(Number(d2.substring(0,4)), Number(d2.substring(4,6)) - 1, Number(d2.substring(6,8)))
     return Math.ceil((p1 - p2) / 1000 / 60 / 60 / 24);
     }
     })*/
    .filter('diffDate', function () {
        return function (str, p1) {
            if (typeof str !== 'string') return str;
            var d = new Date(Number(str.substring(0, 4)), Number(str.substring(4, 6)) - 1, Number(str.substring(6, 8)));
            var currentDate = '';
            if (p1) {
                currentDate = new Date(Number(p1.substring(0, 4)), Number(p1.substring(4, 6)) - 1, Number(p1.substring(6, 8)))
            } else {
                currentDate = new Time;
            }

            return Math.ceil((d - currentDate) / 1000 / 60 / 60 / 24);
        }
    })
    //日期转换为*年*月*日
    .filter('ymdToDate', function () {
        return function (data) {
            if (data != null) {
                var _year, _month, _day, _dateString;
                _year = data.length >= 4 ? (data + '').substring(0, 4) : "2016";
                _month = data.length >= 6 ? (data + '').substring(4, 6) : "1";
                _day = data.length >= 8 ? (data + '').substring(6, 8) : "1";
                _dateString = _year + "年" + _month + "月" + _day + "日";
                data = _dateString;
                return data;
            }
        }
    })
    //20161018161108 转为2016-10-18
    .filter("formatYear", function () {
        return function (time) {
            time = time + "";
            var newDate = time.slice(0, 4) + "-" + time.slice(4, 6) + "-" + time.slice(6, 8);
            return newDate;
        }
    })
    //日期格式化20161010变为2016.10.10
    .filter('formatDay2', function () {
        return function (strs) {
            if (!strs)return false;
            var str;
            str = strs.substring(0, 4) + '.' + strs.substring(4, 6) + '.' + strs.substring(6, 8);
            return str;
        }
    })
    //20161018161108 转为2016-10-18 16：11：08
    .filter('formatDay3', function () {
        return function (strs) {
            if (!strs)return '';
            var str;
            str = strs.substring(0, 4) + '-' + strs.substring(4, 6) + '-' + strs.substring(6, 8) + '  ' + strs.substring(8, 10) + ':' + strs.substring(10, 12) + ':' + strs.substring(12, 14);
            return str;
        }
    })
    //日期格式化20161010变为2016-10-10
    .filter('formatDay4', function () {
        return function (strs) {
            if (!strs)return '';
            var str;
            str = strs.substring(0, 4) + '-' + strs.substring(4, 6) + '-' + strs.substring(6, 8);
            return str;
        }
    })
    //时间格式转化 141212 转变为14.12
    .filter('formatTime1', function () {
        return function (strs) {
            if (!strs)return '';
            var str;
            str = strs.substring(0, 2) + ':' + strs.substring(2, 4);
            return str;
        }
    })
    // 隐藏银行卡号
    .filter('hideBankcardNum', function () {
        return function (data) {
            if (!data) {
                return "";
            }
            if (data) {
                var length = (data + "").length - 4;
                var str1 = (data + "").substring(0, 4);
                var str2 = data.substring(length, (data + "").length);
                return str1 + ' **** **** ' + str2;
            }
        }
    })
    //显示银行卡后四位
    .filter('FormatToBankCardNum', function () {
        return function (data) {
            if (!data) {
                return "";
            }
            if (data) {
                var length = (data + "").length - 4;
                var str2 = data.substring(length, (data + "").length);
                return str2;
            }
        }
    })
    //隐藏手机号
    .filter('hideMobile', function () {
        return function (data) {
            if (!data) {
                return "";
            }
            var length = (data + "").length - 4;
            var str1 = (data + "").substring(0, 3);
            var str2 = data.substring(length, (data + "").length);
            return str1 + '****' + str2;
        }
    })
    //隐藏姓名
    .filter('hideName', function () {
        return function (data) {
            if (!data) {
                return "";
            }
            var length = (data + "").length - 1;
            var str = (data + "").substring(1, (data + "").length);
            return '*' + str;
        }
    })
    //安全状态
    .filter('accountStatus', function () {
        return function (data) {
            if (!data) {
                return "";
            }
            switch (data) {
                case '0':
                    return '危险';
                    break;
                case '1':
                    return '安全';
                    break;
                default:
                    return false;
            }
        }
    })
    // 只显示银行卡号后四位
    .filter('showFourNum', function () {
        return function (data) {
            if (data) {
                var lastFourNum = data.substr(-4, 4);
                return lastFourNum;
            }
        }
    })
    // 显示银行卡号后四位
    .filter('showBankcardLastFourNum', function () {
        return function (data) {
            if (data) {
                var lastFourNum = data.substr(-4, 4);
                return '****' + ' ' + '****' + ' ' + '****' + ' ' + lastFourNum;
            }
        }
    })
    .filter('fixTo', function () {
        return function (input) {
            if (!input) return "";
            if (input > 1000) {
                input = (input / 1000).toFixed(1);
                input += 'km';
            } else {
                input += 'm';
            }
            return input;
        }
    })
    .filter('hideCardNo', function () {
        return function (str) {
            if (typeof str !== 'string') return str;
            return str.substr(-4);
        };
    })
    //从数据字典获取数据并返回
    .filter('getDictName', function (resourceSvc, CONSTANT) {
        return function (value, key) {
            //console.log(key, value);
            if (!value) {
                return "";
            }
            var _text = "";

            var dictList = resourceSvc.getLocalObj(CONSTANT.DICT),
                itemList = [];
            for (var i = 0; i < dictList.length; i++) {
                if (dictList[i].dict == key) {
                    itemList.push(dictList[i])
                }
            }
            //console.log(itemList);
            itemList.forEach(function (e) {
                if (e.itemkey == value) {
                    //console.log(e);
                    _text = e.itemval;
                }
            });
            console.log(_text);
            return _text;

        }
    })
    //产品状态字典, 慧理财资产页
    .filter('prodLifecycle', function () {
        return function (num) {
            switch (num) {
                case '0' :
                    return '设计';
                case '1' :
                    return '发行前';
                case '2' :
                    return '发行';
                case '3' :
                    return '发行失败';
                case '4' :
                    return '成立';
                case '5' :
                    return '封闭';
                case '6' :
                    return '开放';
                case '7' :
                    return '清盘';
                case '8' :
                    return '终止';
                case '9' :
                    return '暂停交易';
                default :
                    return '';
            }
        }
    })
    //慧理财资产详情页
    .filter('formatSpan', ['$sce', function ($sce) {
        return function (day) {
            if (typeof day !== 'string') return day;
            while (day.length < 4) {
                day = '0' + day;
            }
            var str = day.replace(/./g, function (a) {
                return '<span>' + a + '</span>';
            });
            return $sce.trustAsHtml(str);
        }
    }])
    .filter('formatDate', function () {
        return function (str, a1, a2, a3) {
            if (typeof str !== 'string') return str;
            a1 = a1 || '';
            a2 = a2 || '';
            a3 = a3 || '';
            return str.substring(0, 4) + a1 + str.substring(4, 6) + a2 + str.substring(6, 8) + a3;
        }
    })

    //产品期限
    .filter('DictionariesDay', function () {
        return function (str) {
            //TODO 1年应该有365天或366天
            if (typeof str !== 'string') return str;
            switch (str) {
                case 'D1' :
                    return '1';
                case 'D7' :
                    return '7';
                case 'M1' :
                    return '30';
                case 'M3' :
                    return '90';
                case 'M6' :
                    return '180';
                case 'Y1' :
                    return '360';
                case 'Y2' :
                    return '720';
                case 'Y3' :
                    return '1080';
                case 'Y5' :
                    return '1800';
                default :
                    return '1';
            }
        }
    })
    .filter('formatHours', function () {
        return function (str) {
            if (typeof str !== 'string') return str;
            return str.substring(0, 2) + ':' + str.substring(2, 4);
        }
    })
    //字符串截取
    .filter('limitToFilter', function ($filter) {
        return function (str, len) {
            if (!str) return;
            if (str.length > len) {
                return $filter("limitTo")(str, len - 2) + "..";
            } else {
                return str;
            }
        }
    })
    // 手机号 显示前三位后四位
    .filter('formatPhone', function () {
        return function (data) {
            if (data) {
                var str1 = data.substr(0, 3)
                var str2 = data.substr(-4, 4);
                return str1 + '****' + str2;
            }
        }
    })
    .filter('cardLevel', function () {
        return function (n) {
            if (typeof n !== 'string') return;
            switch (n) {
                case '1':
                    return '普卡';
                case '2':
                    return '银卡';
                case '3':
                    return '金卡';
                case '4':
                    return '白金卡';
                case '5':
                    return '钻石卡';
                default :
                    return '普卡';
            }
        };
    })
    .filter("remainTime", function ($filter) {
        return function (time) {
            if (!time && time.length != 14) return;
            var endTime = $filter("FormData")(time).getTime();
            var nowTime = new Date().getTime();
            var t = (1000 * 3600 * 24 * 4 - 36000 + endTime - nowTime) / 1000;
            var remain_day = Math.floor(t / 3600 / 24);
            var remain_hour = Math.floor((t / 3600) % 24);
            var remain_mins = Math.floor((t / 60) % 60);
            if (remain_day > 3) {
                return '已过期';
            } else if (remain_day >= 1) {
                return remain_day + '天';
            } else if (remain_hour >= 1) {
                return remain_hour + '小时';
            } else if (remain_mins >= 1) {
                return remain_mins + '分钟';
            } else {
                return '已过期';
            }
        }
    })
    /*.filter("sortNum", function () {
     return function (prop) {
     return function (obj1, obj2) {
     var val1 = Number(obj1[prop]);
     var val2 = Number(obj2[prop]);
     if (val1 < val2) {
     return -1;
     } else if (val1 > val2) {
     return 1;
     } else {
     return 0;
     }
     }
     }
     })*/
    /*eg:"20161015143847"
     *转化为Sat Oct 15 2016 14:38:47 GMT+0800 (中国标准时间)
     * */
    .filter("FormData", function () {
        return function (time) {
            if (!time && time.length != 14) return;
            return new Date(Number(time.substring(0, 4)), Number(time.substring(4, 6)) - 1, Number(time.substring(6, 8)), Number(time.substring(8, 10)), Number(time.substring(10, 12)), Number(time.substring(12, 14)));
        }
    })
    /*eg:"20161015143847"
     *转化为2016年10月15日14时38分47秒
     * */
    .filter("FormTime", function () {
        return function (time) {
            if (!time && time.length != 14) return;
            return time.substring(0, 4) + '.' + time.substring(4, 6) + '.' + time.substring(6, 8) + ' ' + time.substring(8, 10) + ':' + time.substring(10, 12) + ':' + time.substring(12, 14)
        }
    })
    /**
     *兑换券状态显示
     */
    .filter('VoucherStatusText', function () {
        return function (voucher_status) {
            var result = "";
            switch (voucher_status) {
                case '0':
                    result = "未生效";
                    break;
                case '1':
                    //result = "有效";
                    break;
                case '2':
                    result = "已使用";
                    break;
                case '3':
                    result = "已过期";
                    break;
            }
            return result;
        }
    });