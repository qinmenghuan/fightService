/**
 * 程序信息服务，如 UUID、版本号、等
 * Created by fusy on 2016/9/6.
 */
publicModule.factory("appInfoSvc", function (util, $q, $http) {
    // var guid = "guid000001"//util.guid();
    var guid = util.guid();
    var adcode = "620100";
    var getCity = (function () {
        $http.get("https://restapi.amap.com/v3/ip?key=c7bc42798f9469000eaccae6e11e08f4")
            .success(function (data) {
                adcode = data.adcode;
            })
    })();
    var UUIDDeferred = $q.defer();
    return {
        init: function () {
            UUIDDeferred.resolve(guid);
            return $q.all([UUIDDeferred.promise]);
        },
        getUUID: function () {
            // alert(2);
            return UUIDDeferred.promise;
        },
        getChannelType: function () {
            //渠道码 0:互联网 1:移动-ios 2:移动android
            return $q.when("1");
        },
        getNetwork: function () {
            return $q.when("none");
        },
        getAdcode: function () {
            return adcode;
        },
        getPixels: function () { //获取手机分辨率
            var dpr = window.devicePixelRatio;
            console.log('dpr', dpr);
            return window.screen.width * dpr + "*" + window.screen.height * dpr;
        }
    }
});