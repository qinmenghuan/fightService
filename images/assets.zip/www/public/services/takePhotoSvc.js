/**
 *   拍照/从相册获取图片服务
 *
 */
publicModule.factory("takePhotoSvc",
    function($cordovaCamera,httpSvc,CONFIG,$http){
        return{
            //拍照
            takePhoto: function(){
                var options = {
                    destinationType: Camera.DestinationType.FILE_URI,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    // allowEdit: true,
                    quality: 40,
                    targetWidth: 300,
                    targetHeight: 300
                };
                return $cordovaCamera.getPicture(options).then(function(data){
                    return data;
                })
            },
            //从相册选择
            selectAlbum: function(){
                var options = {
                    destinationType: Camera.DestinationType.FILE_URI,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    // allowEdit: true,
                    quality: 40,
                    targetWidth: 300,
                    targetHeight: 300
                };
                return $cordovaCamera.getPicture(options).then(function(data){
                    return data;
                })
            },
            //修改头像
            setUserPic:function(params){
                return httpSvc.post("user030102.json",params).then(function(data){
                    return data;
                });
            },
            //上传图片
            upLoadPic: function(params){
                return httpSvc.post("base64upload.json",params).then(function(data){
                    return data;
                });
            },
            //下载图片
            downLoadPic: function(params){
                return httpSvc.post("platform/showimg.json",params).then(function(data){
                    return data;
                });
            }
        }
    });
