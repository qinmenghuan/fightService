/**
 * Created by suy on 2016/11/10.
 */
publicModule.factory('mapSvc',
    function (gpsSvc,
              $rootScope,
              $ionicLoading,
              $timeout,
              $interval,
              CONFIG,
              AmapTips,
              toolSvc) {
        //flag避免重复定位及调用函数
        var map, timer, flag = true, location = [];
        //提示断网信息
        var showError = function () {
            $ionicLoading.show({
                template: '网络连接失败，请检查网络。'
            });
            $timeout(function () {
                $ionicLoading.hide();
            }, 3000);
        };
        var infoWindow = function (Info) {
            var infoWindow = new AMap.InfoWindow({
                content: "<span class='title'>" + Info.name + "</span><hr/>" + "地址：" + Info.address + "<br />",
                size: new AMap.Size(0, 0),
                autoMove: true,
                offset: new AMap.Pixel(0, -25)
            });
            infoWindow.open(map, Info.position);
        };
        //地图初始化
        var initMap = function (mapId, onComplete, CloudLayer) {
            //动态加载地图，避免断网无法对地图进行初始化
            toolSvc.loadScript("https://webapi.amap.com/maps?v=1.3&key=06f54a9e326e97b16a1eda53dbf58718&callback=init", "AMap")
                .then(function () {
                    var option = {
                        resizeEnable: true,
                        zoom: 13
                    };
                    if (location.length) {
                        angular.extend(option, {center: new AMap.LngLat(location[0], location[1])});
                    }
                    if (AMap && AMap.Map) {
                        initMaper(mapId, option, onComplete, CloudLayer);
                    } else {
                        //网络不好时默认进行3次地图操作，超过提示断网信息
                        console.log(123123124124);
                        var index = 0;
                        timer = $interval(function () {
                            index++;
                            initMaper(mapId, option, onComplete, CloudLayer);
                            if (index == 3) {
                                showError();
                                $interval.cancel(timer);
                            }
                        }, 300);
                    }
                }, function () {
                    showError();
                });
        };
        var initMaper = function (mapId, option, onComplete, CloudLayer) {
            if (!AMap || !AMap.Map) return;
            if (timer) $interval.cancel(timer);
            map = new AMap.Map(mapId, option);//初始化地图
            createMap(onComplete);
            addCloudLayer(CloudLayer);
        };
        var createMap = function (onComplete) {
            //定位服务插件。基于HTML5的定位接口，只有支持该定位接口的浏览器才能使用该功能
            map.plugin('AMap.Geolocation', function () {
                var geolocation = new AMap.Geolocation({
                    enableHighAccuracy: true,
                    timeout: 10000,
                    buttonOffset: new AMap.Pixel(10, 20),
                    zoomToAccuray: true,
                    buttonPosition: 'RB',
                    showCircle: false
                });
                map.addControl(geolocation);
                // 当有当前位置信息时,设置缩放级别和中心点
                if (location.length) {
                    map.setZoomAndCenter(12, location);
                    onComplete(location);
                    flag = false;
                }
                geolocation.getCurrentPosition();//获取当前位置信息,定位成功时触发complete\error事件
                AMap.event.addListener(geolocation, 'complete', function (data) {
                    location = [data.position.getLng(), data.position.getLat()];
                    if (flag && location.length) {
                        map.setZoomAndCenter(12, location);
                        onComplete(location);
                        flag = true;
                    }
                });
                AMap.event.addListener(geolocation, 'error', showError);
            });
        };
        var addCloudLayer = function (callBack) {
            //加载云图层插件
            map.plugin('AMap.CloudDataLayer', function () {
                var layerOptions = {
                    query: {
                        keywords: ''
                    },
                    clickable: true
                };
                //AmapTips.tableId为高德用户自定义地图编号，配置在config.js中
                var cloudDataLayer = new AMap.CloudDataLayer(AmapTips.tableId, layerOptions); //实例化云图层类
                cloudDataLayer.setMap(map); //叠加云图层到地图
                AMap.event.addListener(cloudDataLayer, 'click', function (result) {
                    if (!location.length) return;
                    var clouddata = result.data;
                    infoWindow({
                        position: clouddata._location,
                        name: clouddata._name,
                        address: clouddata._address
                    });
                    callBack(clouddata, location);
                });
            });
        };
        return {
            init: function (mapId, onComplete, CloudLayer) {
                if (CONFIG.DEBUG_ON_CHROME) {
                    //浏览器中初始化地图
                    initMap(mapId, onComplete, CloudLayer);
                } else {
                    //app中先获取初始化地图位置信息再初始化地图
                    gpsSvc.isGps().then(function (data) {
                        location = [data.coords.longitude, data.coords.latitude];
                        initMap(mapId, onComplete, CloudLayer);
                    }, function (err) {
                        initMap(mapId, onComplete, CloudLayer);
                    });
                }
            },
            networkEvent: function (online) {
                //添加手机断网和联网监听
                document.addEventListener("offline", showError, false);
                document.addEventListener("online", online, false);
            },
            infoWindow: infoWindow
        };
    });