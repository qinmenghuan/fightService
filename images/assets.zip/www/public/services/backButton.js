/**
 * 监控安卓返回键, 解决输入法返回问题, 增加首页连按两次返回退出功能
 * 依赖插件 ionic-plugin-keyboard
 * Created by fengc on 2016/4/29.
 */

publicModule.factory("backButton", function ($ionicPlatform, $location, $ionicHistory, appInfoSvc, 
                                             $rootScope, GestureLockService, $cordovaDevice,popupSvc,
                                             mineSvc,resourceSvc,encryptSvc,CONSTANT) {
    var keyBoard = null,
        isKeyboardShow = false, //键盘弹起来了吗
        hasTips = false;        //有退出提示吗
    return {
        init: function (urls) {  //backButton.init(["/home","/circle","/cardPay","/mine"]);
            var that = this;
            document.addEventListener('deviceReady', function () {
                console.log("1112");
                if ($cordovaDevice.getPlatform() == 'IOS') return; //iOS好像不需要这个功能
                if (!(urls instanceof Array)) return;
                if (window.cordova && cordova.plugins && cordova.plugins.Keyboard) {
                    keyBoard = cordova.plugins.Keyboard;
                }
                if (!keyBoard) return;
                that.onKeyboardShow();
                that.onKeyboardHide();
                $ionicPlatform.registerBackButtonAction(function (e) {
                    console.log("返回按钮");
                    e.preventDefault();
                    // 是否键盘弹起
                    if (isKeyboardShow) {
                        keyBoard.close();
                        isKeyboardShow = false;
                    } else {
                        // 判断处于哪个页码时双击退出
                        if (urls.some(function (str) { return str === $location.url(); }))
                        {
                            // 第一次点击
                            if (!hasTips) {
                                that.onTips();
                            }// 双击退出
                            else {
                                encryptSvc.then(function (encrypt) {
                                    // 判断是否登录
                                    if (!encrypt.aesDeLocal(CONSTANT.HEAD_JSESSIONID)) {
                                        popupSvc.alert({
                                            title: "是否确认退出惠生活?",
                                            cssClass: "popup-container",
                                            buttons: [
                                                {
                                                    text: '<b>确定</b>',
                                                    type: 'button-positive',
                                                    onTap: function (e) {
                                                        ionic.Platform.exitApp();
                                                    }
                                                },
                                                {text: '取消'}
                                            ]
                                        });
                                    }
                                    // 如果已登录
                                    else {
                                        var registrationid = resourceSvc.getLocal('registrationid');
                                        console.log("第二次退出");
                                        //alert("第二次退出");
                                        //提示是否退出
                                        popupSvc.alert({
                                            title: "是否确认退出惠生活?",
                                            cssClass: "popup-container",
                                            buttons: [
                                                {
                                                    text: '<b>确定</b>',
                                                    type: 'button-positive',
                                                    onTap: function (e) {
                                                        console.log("确认退出");
                                                        mineSvc.quit({
                                                            registrationid: registrationid
                                                        }).then(function (data) {
                                                            console.log(data);
                                                            if (data.ret_code == "0000") {
                                                                encryptSvc.then(function (encrypt) {
                                                                    var user_Info = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                                                                    user_Info.clear();
                                                                    resourceSvc.clearSession();
                                                                    resourceSvc.removeLocal(CONSTANT.HEAD_JSESSIONID);
                                                                    resourceSvc.removeLocal(CONSTANT.ACCOUNT_INFO);
                                                                });
                                                                // 退出app
                                                                ionic.Platform.exitApp();
                                                            } else {
                                                                // 退出app
                                                                ionic.Platform.exitApp();
                                                                //showErrorInfo(data.ret_msg);
                                                            }
                                                        })
                                                    }
                                                },
                                                {text: '取消'}
                                            ]
                                        });
                                    }
                                });


                                //alert("第二次退出");
                                // return;
                                // backAsHome.trigger(function () {
                                //     console.log("Success");
                                // }, function () {
                                //     console.log("Error");
                                // });
                            }
                        }
                        // 普通画面退出
                        else if ($ionicHistory.backView()) {
                            var event = {
                                flag: true,
                                preventDefault: function () {
                                    event.flag = false;
                                }
                            };
                            $rootScope.$broadcast("device-on-back", event);
                            if (!event.flag) return;
                            if ($location.url() == "/setGesturePwd") {
                                GestureLockService.skipDialog();
                            } else {
                                $rootScope.$ionicGoBack();
                            }
                        }
                        else {
                            backAsHome.trigger(function () {
                                console.log("Success");
                            }, function () {
                                console.log("Error");
                            });
                        }
                    }
                    return false;
                }, 101);
            }, false);
        },
        onKeyboardShow: function () {
            window.addEventListener('native.keyboardshow', function () {
                isKeyboardShow = true;
            }, false);
        },
        onKeyboardHide: function () {
            window.addEventListener('native.keyboardhide', function () {
                setTimeout(function () {
                    isKeyboardShow = false;
                }, 100);
            }, false);
        },
        onTips: function () {
            var that = this;
            var str = '再按一次退出',
                div = '<div id="exit-tips" style="position:fixed;left:50%;bottom:10%;width:150px;height:50px;margin-left:-75px;line-height:50px;text-align:center;background-color:rgba(0,0,0,0.3);border-radius:25px;color:#fff;font-size:14px;z-index:100">' + str + '</div>';
            hasTips = true;
            document.body.insertAdjacentHTML("beforeend", div);
            setTimeout(function () {
                hasTips = false;
                that.offTips();
            }, 1500);
        },
        offTips: function () {
            var tip = document.getElementById('exit-tips');
            if (tip) {
                tip.parentNode.removeChild(tip);
            }
        }
    };
});
