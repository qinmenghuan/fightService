/**
 * Created by kayak on 2016/10/20.
 */
publicModule.factory('gpsSvc', function ($cordovaGeolocation, $q) {
    return {
        isGps: function () {
            var posOptions = {timeout: 10000, enableHighAccuracy: true};
            var defer = $q.defer();
            $cordovaGeolocation
                .getCurrentPosition(posOptions)
                .then(function (position) {
                    defer.resolve(position);
                }, function (err) {
                    defer.reject(err);
                });
            return defer.promise;
        }
    }
})

//  ctrl中调用
// gpsSvc.isGps().then(function (data) {
//     alert('gps open');
// }, function (err) {
//     alert('gps not open');
// })