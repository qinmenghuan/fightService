/**
 * 工具服务(公共方法)
 * author duying
 * create by nies in 2.29
 * edit by
 * update by
 */

publicModule.factory("toolSvc",
    function ($log, resourceSvc, $interval, $q, $http, $filter, CONSTANT) {
        /**
         * author:qiaoyongjun
         * StrNo:用户输入的身份证件号码
         *判断身份证号码格式函数
         *公民身份号码是特征组合码，
         *排列顺序从左至右依次为：六位数字地址码，八位数字出生日期码，三位数字顺序码和一位数字校验码
         *如果验证通过返回 false,否则返回具体的错误信息
         */
        function isChinaIDCard(StrNo) {
            StrNo = StrNo.toString();
            if (StrNo.length != 18) {
                return "输入的身份证号码必须为18位！";
            }
            if (!isNumber(StrNo.substr(0, 17))) {
                return "身份证号码错误,前17位不能含有英文字母！";
            }
            var resultInfo = isValidDate(StrNo.substr(6, 4), StrNo.substr(10, 2), StrNo.substr(12, 2));
            if (resultInfo) {
                return resultInfo;
            }
            var a = 0, b, c = StrNo.substr(17, 1);
            var arr = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];  //十七位数字本体码权重
            var validate = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];    //mod11,对应校验码字符值
            for (var i = 0; i < 17; i++) {
                a += parseInt(StrNo.substr(i, 1)) * arr[i];
            }
            b = a % 11;
            if (b == 2) {//最后一位为校验位
                c = c.toUpperCase(); //转为大写X
            }
            if (c != validate[b]) {
                return "身份证号码校验失败";
            }
            return false;
        }

        /**
         * 验证身份证件中的日期是否合法有效
         * @param iY
         * @param iM
         * @param iD
         * @return 错误信息或false
         */
        function isValidDate(iY, iM, iD) {
            if (iY > 2200 || iY < 1900 || !isNumber(iY)) {
                return "输入身份证号,年度" + iY + "非法！";
            }
            if (iM > 12 || iM <= 0 || !isNumber(iM)) {
                return "输入身份证号,月份" + iM + "非法！";
            }
            if (iD > 31 || iD <= 0 || !isNumber(iD)) {
                return "输入身份证号,日期" + iD + "非法！";
            }
            return false;
        }

        /**
         * 验证是否为数字
         * @param oNum
         * @return
         */
        function isNumber(oNum) {
            if (!oNum) return false;
            if (!/^\d+(\.\d+)?$/.test(oNum)) return false;
            try {
                if (parseFloat(oNum) != oNum) return false;
            } catch (ex) {
                return false;
            }
            return true;
        }

        var tools = {
            /**
             * 动态加载js资源
             * @param sScriptSrc js资源地址
             * @param scriptName js资源引入后标签name值 以区分js资源
             * @returns {Promise}
             */
            loadScript: function (sScriptSrc, scriptName) {
                var deferred = $q.defer();
                var ss = document.getElementsByName(scriptName);
                if (ss.length > 0) {
                    deferred.resolve();
                } else {
                    //gets document head element
                    var oHead = document.getElementsByTagName("head")[0];
                    if (oHead) {
                        //creates a new script tag
                        var oScript = document.createElement("script");
                        //adds src and type attribute to script tag
                        oScript.setAttribute("src", sScriptSrc);
                        oScript.setAttribute("type", "text/javascript");
                        oScript.setAttribute("name", scriptName);
                        //calling a function after the js is loaded (IE)
                        var loadFunction = function () {
                            if (this.readyState == "complete" || this.readyState == "loaded") {
                                deferred.resolve();
                            }
                        };
                        oScript.onreadystatechange = loadFunction;
                        //calling a function after the js is loaded (Firefox)
                        oScript.onload = function () {
                            deferred.resolve();
                        };
                        oScript.onerror = function () {
                            oHead.removeChild(oScript);
                            deferred.reject();
                        };
                        //append the script tag to document head element
                        oHead.appendChild(oScript);
                    }
                }
                return deferred.promise;
            },
            //获取随机uuid
            getRandomStr: function () {
                var s = [],
                    hexDigits = "0123456789abcdef";
                for (var i = 0; i < 36; i++) {
                    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
                }
                s[14] = "4";
                s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
                s[8] = s[13] = s[18] = s[23] = "";

                return s.join("");
            },
            //获取定位城市名
            getCityName: function (successCallback) {
                var myCity = new BMap.LocalCity();
                myCity.get(function (e) {
                    if (angular.isFunction(successCallback)) {
                        successCallback(e.name);
                    }
                });
            },
            //缓存城市名
            setCityName: function () {
                this.getCityName(function (name) {
                    if (resourceSvc.getLocal("CityName", null) == null || resourceSvc.getLocal("CityName") != name) {
                        resourceSvc.setLocal("CityName", name);
                    }
                })
            },
            //字符串转日期
            str2date: function (str, format) {
                var reg = new RegExp("[\u4e00-\u9fa5]|\/|-|:|\s", "g"); //汉字正则表达
                var newDate = new Time();

                if (format) {
                    return new Date(
                        str.substr(format.indexOf("yyyy"), 4) ? str.substr(format.indexOf("yyyy"), 4) : newDate.getFullYear(),
                        str.substr(format.indexOf("MM"), 2) ? str.substr(format.indexOf("MM"), 2) - 1 : newDate.getMonth(),
                        str.substr(format.indexOf("dd"), 2) ? str.substr(format.indexOf("dd"), 2) : newDate.getDate(),
                        str.substr(format.indexOf("HH"), 2) ? str.substr(format.indexOf("HH"), 2) : 0,
                        str.substr(format.indexOf("mm"), 2) ? str.substr(format.indexOf("mm"), 2) : 0,
                        str.substr(format.indexOf("ss"), 2) ? str.substr(format.indexOf("ss"), 2) : 0,
                        str.substr(format.indexOf("SSS"), 3) ? str.substr(format.indexOf("SSS"), 3) : 0
                    )
                } else {
                    str = str.replace(/[\u4e00-\u9fa5]|\/|-|:|\s/g, "");
                    return new Date(
                        str.substr(0, 4) ? str.substr(0, 4) : newDate.getFullYear(),
                        str.substr(4, 2) ? str.substr(4, 2) - 1 : newDate.getMonth(),
                        str.substr(6, 2) ? str.substr(6, 2) : newDate.getDate(),
                        str.substr(8, 2) ? str.substr(8, 2) : 0,
                        str.substr(10, 2) ? str.substr(10, 2) : 0,
                        str.substr(12, 2) ? str.substr(12, 2) : 0,
                        str.substr(16, 3) ? str.substr(16, 3) : 0
                    )
                }
            },
            //日期计算
            dateCount: function (date, num, unit) {//时间加减 nies
                if (typeof date == "string") {
                    date = this.str2date(date, "yyyyMMddHHmmss");
                }
                switch (unit) {
                    case "y":
                        date.setFullYear(date.getFullYear() + num);
                        break;
                    case "M":
                        date.setMonth(date.getMonth() + num);
                        break;
                    case "d":
                        date.setDate(date.getDate() + num);
                        break;
                    case "h":
                        date.setHours(date.getHours() + num);
                        break;
                    case "m":
                        date.setMinutes(date.getMinutes() + num);
                        break;
                    case "s":
                        date.setSeconds(date.getSeconds() + num);
                        break;
                    case "S":
                        date.setMilliseconds(date.getMilliseconds() + num);
                }
                return date;
            },
            //有效截止日期
            dateEnd: function (num) {
                var newDate = new Time();
                newDate.setDate(newDate.getDate() + num);
                newDate = $filter("date")(newDate, "yyyy-MM-dd");
                return newDate;
            },
            //左边，补0到len长度
            addZero: function (data, len) {
                if (data.length >= len) {
                    return data;
                }
                return Array(len - data.length + 1).join("0") + data;
            },
            /**
             * 银行卡格式化
             * @param card
             * @returns {*}
             */
            bankCardFormat: function (card) {
                if (angular.isNumber(card)) {
                    card = card + "";
                }
                return card.replace(/(\d{4})(?=\d)/g, "$1 ");
            },
            /**
             * 四舍五入
             * @param num 需要四舍五入的数字
             * @param precision 保留进度 默认保留2位小数
             * @returns {number}
             */
            round: function (num, precision) {
                precision = precision ? precision : 2;
                num = Math.pow(10, precision) * num;
                num = Math.round(num);
                return num / Math.pow(10, precision);
            },
            /**
             * create by fusy at 2016年3月11日
             * 把指定时间转换为 *天*小时*分钟*秒 的形式
             * @param dif 需要转换的时间毫秒数
             * @returns {{days: number, hours: number, mins: number, seconds: number, dif: date毫秒数}}
             */
            getDHMS: function (dif) {
                var d = Math.floor(dif / 3600 / 24);
                var h = Math.floor((dif / 3600) % 24);
                var m = Math.floor((dif / 60) % 60);
                var s = Math.floor(dif % 60);
                return {
                    days: d,
                    hours: h,
                    mins: m,
                    seconds: s,
                    dif: dif
                }
            },
            /**
             * * 计时器
             * @param dif 剩余时间 (s)
             * @param callback(DHMS) 倒计时回调方法 HDMS对象 查看getDHMS方法。
             */
            count: function (dif, callback) {
                callback(tools.getDHMS(dif--));
                var stop = $interval(function () {
                    if (dif <= 0) {
                        $interval.cancel(stop);
                        callback(tools.getDHMS(0));
                        return;
                    }
                    callback(tools.getDHMS(dif--));
                }, 1000);
                return {
                    cancel: function () {
                        $interval.cancel(stop);
                        callback(tools.getDHMS(0));
                    }
                };
            },
            /**
             * create by fusy at 2016年3月11日
             * use like
             * toolSvc.countDown(start, end, function(DHMS){
       *    console.log(DHMS.days,DHMS.hours, DHMS.mins, DHMS.secounds, DHMS.dif);
       * })
             *
             * @param start 倒计时开始计数时间 type： 时间字符串
             * @param end  倒计时结束计数时间 type： 时间字符串
             * @param callback 倒计时回调方法 抛出对象DHMS (see getDHMS function);
             */
            countDown: function (start, end, callback) {
                var dif = Math.floor((end - start) / 1000);
                this.count(dif, callback);
            },
            /**
             * create by fusy at 2016年3月11日
             *
             * 进度计算(float)
             * @param max type number 区间最大值
             * @param min type number 区间最小值
             * @param current type number 区间中间值
             * @returns {float} 百分值
             */
            process: function (max, min, current) {
                max = Number(max);
                min = Number(min);
                current = Number(current);
                var D_value = max - min;
                if (current > max) {
                    return 1;
                } else if (current < min) {
                    return 0;
                }
                var process = tools.round(current / D_value, 4);
                return process;
            },
            /**
             * 时间进度
             * @param sdate 开始时间
             * @param edate 结束时间
             * @param cdate 当前时间
             * @param callback 回调方法 callback(DHMS, process) --process：进度值;
             */
            dateProcess: function (sdate, edate, cdate, callback) {
                sdate = (isDate(sdate) ? sdate : tools.str2date(sdate)).getTime();
                edate = (isDate(edate) ? edate : tools.str2date(edate)).getTime();
                cdate = (isDate(cdate) ? cdate : tools.str2date(cdate)).getTime();
                var max = edate - sdate,
                    currency = edate - cdate;
                if (isFunction(callback)) {
                    tools.countDown(cdate, edate, function (DHMS) {
                        callback(DHMS, tools.process(max, 0, currency));
                        currency = currency - 1000;
                    })
                }
            },
            /**
             * create by fusy at 2016年3月11日
             * 百分比字符串转double类型
             * @param km 百分比字符串(100%);
             * @returns {double}
             */
            percentTofloat: function (km) {
                if (km.substring(km.length - 1, km.length) == "%") {
                    km = km.substring(0, km.length - 1);
                    km = km / 100;
                }
                return km;
            },
            /**
             * url处理 将=，&等符号转为编码的形式
             * 如 huacard.com?product_id=1  =>  huacard.com?product_id%3D1
             * = : %3D
             * + : %2B
             * 空格 ： %20
             * /: %2F
             * ?: %3F
             * %: %25
             * #: %23
             * &: %26
             * @constructor
             */
            handleURL: function (url) {
                return url.replace(/%/g, "%25")
                    .replace(/=/g, "%3D")
                    .replace(/&/g, "%26")
                    .replace(/\+/g, "%2B")
                    .replace(/\s/g, "%20")
                    .replace(/\//g, "%2F")
                    .replace(/#/g, "%23")
                    .replace(/\?/, "%3F");
            },
            /**
             *   处理后台从卡系统直接返回来的值
             *    00050000    --->    实际值是500.00
             */
            formateNum: function (num) {
                if (num) {
                    num = (num.replace(/\b(0+)/gi, "")) / 100;
                    return num;
                }
            },
            compareJson: function (json1, json2) {
                var result = true;
                for (var a in json1) {
                    if (json1[a] instanceof Array) {
                        for (var b in json1[a]) {
                            if (!tools.compareJson(json1[a][b], json2[a][b])) {
                                return false;
                            }
                        }
                    } else {
                        if (json1[a] != json2[a]) {
                            return false;
                        }
                    }
                }
                /*angular.forEach(json1, function (val, key) {
                 if(val instanceof Array){
                 angular.forEach(val,function (a,i) {
                 result = compareJson(a,json2[key][i]);
                 })
                 }else {
                 console.log(val,json2[key],json2[key] != val)
                 if (json2[key] != val) {
                 result = false;
                 }
                 }
                 });*/
                return true
            },
            /**
             *   处理后台返的json Object  转换成 json Array
             */
            objToArr: function (obj) {
                var arr = [];
                for (var i in obj) {
                    arr.push({
                        key: i,
                        val: obj[i]
                    })
                }
                return arr;
            },
            //使用百度网址判断Wi-Fi情况下是否有联网
            getInternet: function () {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: "https://www.baidu.com",
                    timeout: 15000
                }).success(function () {
                    console.log("net success");
                    deferred.resolve();
                }).error(function () {
                    console.log("net error");
                    deferred.reject();
                });
                return deferred.promise;
            },
            checkTel: function (data, type) {
                if (!data) {
                    return type ? CONSTANT.ACCOUNT_NULL : CONSTANT.PHONE_NULL;
                } else if (!/^1(3|4|5|7|8)\d{9}$/.test(data)) {
                    return CONSTANT.PHONE_ERROR;
                }
                return false;
            },
            checkPwd: function (data) {
                if (!data) {
                    return CONSTANT.PASSWORD_NULL;
                } else if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,24}$/.test(data)) {
                    return CONSTANT.ACCOUNT_PASSWORD_VALID_ERROR;
                }
                return false;
            },
            checkBusAccount: function (data) {
                if (!data) {
                    return CONSTANT.ACCOUNT_NULL;
                }
                return false;
            },
            checkSmsCode: function (data) {
                if (!data) {
                    return CONSTANT.CODE_NULL;
                } else if (!/^\d{6}$/.test(data)) {
                    return CONSTANT.NULL_VALID_CODE;
                }
                return false;
            },
            checkBusPwd: function (data) {
                if (!data) {
                    return CONSTANT.PASSWORD_NULL;
                }
                return false;
            },
            checkVoucherNo: function (data) {
                if (!data) {
                    return CONSTANT.VOUCHER_NO_NULL;
                }
                return false;
            },
            checkCardType: function (data) {
                if (!data) {
                    return CONSTANT.CARD_TYPE_NULL;
                }
                return false;
            },
            //姓名考虑到外国人和新疆人，只有数字不允许
            checkName: function (data) {
                if (!data) {
                    return CONSTANT.NAME_NULL;
                } else if (/^(?=.*\d.*\b)/.test(data)) {
                    return CONSTANT.NAME_UNREAL;
                }
                return false;
            },
            checkID: function (data) {
                if (!data) {
                    return CONSTANT.ID_NULL;
                }
                return isChinaIDCard(data);
            },
            checkMoneyForm: function (data) {
                if (data == 0) {
                    return CONSTANT.MONEY_ZERO;
                } else if (!data) {
                    return CONSTANT.MONEY_NULL;
                } else if (!/^([1-9][\d]{0,7}|0)(\.[\d]{1,2})?$/.test(data)) {
                    return CONSTANT.MONEY_ERROR;
                }
                return false;
            },
            /**
             * create by fusy at 2016年3月11日
             *
             * 进度计算(float)
             * @param data type string/number 输入的数据
             * @param min type number 区间最小值
             * @param ratio type number 区间倍率
             * @param max type number 区间最大值
             * @returns 错误提示信息或者false
             */
            checkMoney: function (money, min, ratio, max) {
                var result = this.checkMoneyForm(money);
                if (result) {
                    return result;
                }
                var data = parseFloat(money);
                if (min && (min > data)) {
                    return CONSTANT.MONEY_MIN + min + "元";
                } else if (max && (data > max)) {
                    return CONSTANT.MONEY_MAX + max + "元";
                } else if (ratio && ((data - min) % ratio)) {
                    return CONSTANT.MONEY_RADIO + ratio + "的倍数";
                }
                return false;
            },
            /*
             * 判断对象是否为空
             * */
            isEmptyObject: function (obj) {
                for (var key in obj) {
                    return false;
                }
                return true;
            },
            /*
             * 对象内key排序
             * */
            objKeySort: function (obj) {
                var newkey = Object.keys(obj).sort();
                //先用Object内置类的keys方法获取要排序对象的属性名，再利用Array原型上的sort方法对获取的属性名进行排序，newkey是一个数组
                var newObj = {};//创建一个新的对象，用于存放排好序的键值对
                for (var i = 0; i < newkey.length; i++) {//遍历newkey数组
                    newObj[newkey[i]] = obj[newkey[i]];//向新创建的对象中按照排好的顺序依次增加键值对
                }
                return newObj;//返回排好序的新对象
            }
        };
        return tools;
    }
);
