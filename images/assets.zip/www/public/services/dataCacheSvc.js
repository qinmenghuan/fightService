/**
 * Created by fusy on 2016/9/27.
 *
 * 这个服务功能是缓存接口数据，在没有网络或者请求超时的情况下 使用缓存数据。
 *
 * 需要在config.js配置需要缓存的交易码。
 *
 */

publicModule.provider("dataCacheSvc", function () {
    var equals = angular.equals,
        _this = this;

    this.setCacheUrlList = function (list) {
        this.cacheUrlList = list;
    };
    this.$get = ["encryptSvc", "CONFIG", "appInfoSvc", "$q",
        function (encryptSvc, CONFIG, appInfoSvc, $q) {
            var factory = {
                /**
                 * 是否缓存
                 * @param url
                 * @returns {boolean} true 缓存 false 不缓存
                 */
                is2Cache: function (url) {
                    return _this.cacheUrlList.join("").indexOf(url) != -1;
                },
                /**
                 * 过滤器。功能根据需求添加，暂时只过滤是否
                 * @param key
                 * @param defaultValue
                 * @returns {*}
                 */
                dataCacheFilter: function (url) {
                    var deferred = $q.defer();
                    if (factory.is2Cache(url)) {
                        $q.all([factory.getCacheData(url), appInfoSvc.getNetwork()]).then(function (args) {
                            var data = args[0];
                            var connection_type = args[1];

                            if (connection_type == "none") {
                                deferred.reject(data);
                            } else {
                                deferred.resolve();
                            }
                        });
                    } else {
                        deferred.resolve();
                    }
                    return deferred.promise;
                },
                /**
                 * 添加缓存数据
                 * @param url
                 * @param data 请求响应数据
                 */
                setCacheData: function (url, requestParams, data) {
                    if(!url){
                        console.error("setCacheData arguments url is null");
                        return;
                    }

                    if (factory.is2Cache(url)) {
                        console.info("缓存url：", url);
                        console.info("缓存参数：", requestParams);
                        console.info("更新缓存数据：", data);
                        data.timestamp = new Date().getTime();
                        encryptSvc.then(function (encrypt) {
                            var urlData = encrypt.aesLocalTemp(url);
                            var params = {};
                            params[factory.json2str(url, requestParams)] = data;
                            urlData.save(params);
                         })
                    }
                },
                /**
                 * 获取缓存数据
                 * @param url
                 * @param requestParams
                 * @returns {urldata}
                 */
                getCacheData: function (url, requestParams) {
                    if(!url){
                        console.error("getCacheData arguments url is null");
                        return;
                    }
                    var deferred = $q.defer();
                    if (factory.is2Cache(url)) {
                        encryptSvc.then(function (encrypt) {
                            var urlData = encrypt.aesLocalTemp(url);
                            var data = urlData.query(factory.json2str(url, requestParams));
                            console.info("缓存url：", url);
                            console.info("缓存参数：", requestParams);
                            console.info("读取缓存数据：", data);
                            deferred.resolve(data);
                        });
                    } else {
                        deferred.resolve();
                    }
                    return deferred.promise;
                },
                json2str: function (url, params) {
                    var str = "";
                    for (var key in params) {
                        str += key;
                        str += params[key];
                    }
                    return str ? str : url;
                }
            };
            return factory;
        }]
}).config(["dataCacheSvcProvider", "CONFIG", function (dataCacheSvcProvider, CONFIG) {
    dataCacheSvcProvider.setCacheUrlList(CONFIG.CACHE_URL_LIST)
}]);