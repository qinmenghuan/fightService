/**
 * Created by fusy on 2016/9/9.
 *
 * 程序初始化服务
 */
publicModule.factory("appInitSvc",
    function ($rootScope, $state, $ionicHistory, httpSvc, $q, popupSvc, CONSTANT, CONFIG, appInfoSvc, commonEvent, permissionSvc, encryptSvc, resourceSvc) {
        var intInfo = {
            synServerRandom: function () {
                var counter = 0;
                var deferred = $q.defer();

                function synServerRandom() {
                    counter++;
                    httpSvc.post("pub010401.json", {
                        "head_trans_code": "110201"
                    }).then(function (data) {
                        console.log(data);
                        if (data.head_ret_code === CONSTANT.HEAD_RET_CODE_SUCCESS) {
                            deferred.resolve(data.server_random);
                        } else {
                            if (counter < 3) {
                                synServerRandom();
                            } else {
                                deferred.reject(data.head_ret_msg);
                            }
                        }
                    }, function (error) {
                        if (counter < 3) {
                            synServerRandom();
                        } else {
                            deferred.reject(error);
                        }
                    }, function (error) {
                        if (counter < 3) {
                            synServerRandom();
                        } else {
                            deferred.reject(error);
                        }
                    });
                }

                //TODO:打开注释
                /*appInfoSvc.init().then(function() {
                 synServerRandom();
                 });*/

                //没有服务端 测试用数据 TODO：删除
                deferred.resolve("MDAwMTQ3MzY3MzY2OTI1Nw==");

                return deferred.promise.then(function (serverRandom) {
                    return serverRandom;
                }, function (error) {
                    popupSvc.loading(error || CONSTANT.SERVER_RANDOM_ERROR);
                });
            },
            permissionInit: function () {
                permissionSvc.setUserType("visitor");
                commonEvent.on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
                    //检查jsessionid是否过期
                    encryptSvc.then(function (encrypt) {
                        var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                        var today = new Date().getTime();
                        var time = userInfo.query(CONSTANT.JSESSIONID_TIME) || 0;
                        if ((time - today) <= 0) {//如果过期 设置用户为游客 清除session
                            console.log("INFO: CHECK STATE_CHANGE_START: TIMEOUT !");
                            permissionSvc.setUserType("visitor");
                            userInfo.clear();
                            resourceSvc.clearSession();
                        } else {
                            permissionSvc.setUserType("login");
                        }
                        permissionSvc.registerPageListener(event, toState, toParams, fromState, fromParams);
                    });
                });
                $rootScope.$on("ionic-go-back", function (e, backView, curView) { //当用户返回页面没有权限访问处理
                    goBackNoPermission(backView, curView.index);
                })
            },
            /**
             * 手势密码
             */
            gestureInit: function () {

                //每次打开app启动手势密码登录(开启手势密码情况下) 如果第一次启动app则跳转设置手势密码
                if (!CONFIG.DEBUG_ON_CHROME) {
                    openGesture();
                }

                //监听app后台事件
                document.addEventListener("resume", resumeEvent, false);

                // 调用手势密码 注：手势密码与用户id对应保存。只有用户登录才能唤醒手势对象。
                function openGesture() {
                    // 这里清除 手势密码页面切换的返回状态
                    //resourceSvc.sessionTemp("loginGestureGoBack").clear();
                    encryptSvc.then(function (encrypt) {
                        //跳转设置手势密码页面，设置完成后 改变isFirst属性 为false
                        var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                        var user_id = userInfo.query("user_id");
                        //var resEnLocalTemp = resourceSvc.localTemp("gesture");
                        var gesturePwd = encrypt.aesDeObjectL(user_id + "gesturePwd");
                        var today = new Date().getTime();
                        var time = userInfo.query(CONSTANT.JSESSIONID_TIME) || 0;
                        //初始手势密码对象
                        var gesture_user_id = {
                            isFirst: true,
                            isOpen: false
                        };
                        if ((time - today) > 0) { // 如果用户缓存没有过期
                            //使用缓存手势密码对象替换手势密码对象
                            angular.extend(gesture_user_id, {gesturePwd: gesturePwd});

                            if (user_id && gesture_user_id.isFirst == false && gesture_user_id.isOpen == true) {
                                //跳转手势密码登录页
                                $state.go("loginGesturePwd");
                            }

                            //如果用户是第一次使用
                            if (user_id && gesture_user_id.isFirst == true) {
                                $state.go("setGusturePwd", {step: "3"}).then(function () {
                                    var gesture = {};
                                    gesture_user_id.isFirst = false;
                                    gesture[user_id] = gesture_user_id;
                                    resEnLocalTemp.save(gesture);
                                });
                            }
                        }
                    })
                }

                // 唤醒事件
                function resumeEvent() {
                    console.log("后台唤醒");
                    // 调用相机插件 会后台 防止选择相片后 触发手势密码
                    var resume = resourceSvc.getSession("resume", "1");
                    encryptSvc.then(function (encrypt) {
                        var currentDate = new Date().getTime();
                        var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                        //判断用户是否缓存超时
                        if (userInfo.query(CONSTANT.JSESSIONID_TIME) - currentDate > 0 && resume == "1") {
                            //用户信息还没有过期 执行唤醒手势密码逻辑
                            openGesture();
                        }

                    })
                }
            }

        };
        //黑名单 当state为黑名单中的任一名称时 返回当前黑名单原色历史页面后一级
        var blackRegs = new RegExp("^(" + CONFIG.BACK_VIEW_BLACK_LIST.join("|") + ")$");

        function goBackNoPermission(backView, index) {
            if (!backView) {
                $state.go("home");
                return;
            }
            encryptSvc.then(function (encrypt) {
                var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                var today = new Date().getTime(),
                    time = userInfo.query(CONSTANT.JSESSIONID_TIME) || 0;
                var state = $state.get(backView.stateName);
                if ((time - today) <= 0 && state.permission === "Lv1" || blackRegs.test(backView.stateName)) { //如果用户未登录或者超时 并且返回页面有权限控制 * 这里添加一个黑名单判断
                    goBackNoPermission($ionicHistory.getViewById(backView.backViewId), index);
                } else {
                    $ionicHistory.goBack(backView.index - index);
                }
            });
        }

        return intInfo;
    });