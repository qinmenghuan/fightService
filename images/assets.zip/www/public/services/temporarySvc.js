/**
 * Created by Yu on 2016/9/27.000
 */
/**
 *用作中间存储器，临时存储预约办卡页面数据，以便选取卡类型之后跳转回原页面，数据不丢失。
 */
/*
 使用上个页面的数据, 页面最多不会超过4层. 就统一用p1, p2, p3当key吧, 覆盖了也没关系
 temporarySvc.set('p1', obj);
 temporarySvc.get('p1');

 temporarySvc.set('p2', obj);
 temporarySvc.get('p2');

 temporarySvc.set('p3', obj);
 temporarySvc.get('p3');
 */
publicModule.factory('temporarySvc', function () {
    var tmp = {};
    return {
        set: function (key, obj) {
            tmp[key] = obj;
        },
        get: function (key) {
            return key ? tmp[key] : '';
        },
        remove: function (key) {
            delete tmp[key];
        },
        bespeakCardInfo: {
            card_name: '',
            sub_user_name: '',
            sub_user_id_code: '',
            sub_user_phone: '',
            code: ''
        }
    };
});