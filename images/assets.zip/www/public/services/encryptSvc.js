/**
 * 通用加密/解密/签名组件
 * @author keyy
 * create nies
 * update fusy
 * @desc 先从缓存中取出相关秘钥，再对传入的参数进行加密
 *
 */
publicModule.factory('encryptSvc', [
    'CONFIG',
    'resourceSvc',
    "appInfoSvc",
    function (CONFIG, resourceSvc, appInfoSvc) {
        var iv = CryptoJS.enc.Utf8.parse('0000000000000000'), uuid;

        var encryptObj = {
            //crypto加密js库的加密方法   同步后台解密方法
            aesEncrypt: function (word, key) {
                var aeskey = CryptoJS.enc.Utf8.parse(key);
                //return CryptoJS.AES.encrypt(word, key).toString();
                var srcs = CryptoJS.enc.Utf8.parse(word);
                var encrypt = CryptoJS.AES.encrypt(srcs, aeskey, {iv: iv});
                return encrypt.ciphertext.toString().toUpperCase();
            },
            //crypto加密js库的解密方法   同步后台加密方法
            aesDecrypt: function (word, key) {
                var aeskey = CryptoJS.enc.Utf8.parse(key);
                //return CryptoJS.AES.decrypt(word, key).toString(CryptoJS.enc.Utf8);
                var encryptedHexStr = CryptoJS.enc.Hex.parse(word);
                var srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
                var decrypt = CryptoJS.AES.decrypt(srcs, aeskey, {iv: iv});
                return CryptoJS.enc.Utf8.stringify(decrypt).toString();
            },
            //crypto加密js库的签名方法
            crypto_hmacMd5: function (word, key) {
                return CryptoJS.HmacMD5(word, key).toString().toUpperCase();
            }
        };
        var encryption = {
            encryptObj: encryptObj,
            //签名方法（只签名需要签名的字段）
            hmacMd5: function (data, hashkey) {
                var _encodeArr = [];
                var _encodeStr = "";
                CONFIG.MAC_WORDS.forEach(function (value) {
                    if (data[value]) {
                        _encodeArr.push(data[value]);
                    }
                });
                // console.log("签名字段:",_encodeArr);
                if (_encodeArr.length == 0) {
                    return encryptObj.crypto_hmacMd5("", hashkey);
                } else {
                    _encodeStr = _encodeArr.join(" ").toUpperCase();
                    return encryptObj.crypto_hmacMd5(_encodeStr, hashkey);
                }
            },
            //加密方法（只加密需要加密的字段）
            encrypt: function (data, aeskey) {
                function encryptRecurrence(data, aeskey) {
                    for (var key in data) {
                        if (angular.isObject(data[key]) || angular.isArray(data[key])) {
                            encryptRecurrence(data[key], aeskey);
                        } else {
                            CONFIG.ENCODE_WORDS.forEach(function (value) {
                                if (data[key] && (value === key)) {
                                    data[key] = encryptObj.aesEncrypt(data[key], aeskey);
                                }
                            });
                        }
                    }
                    return data;
                }

                return encryptRecurrence(data, aeskey);
            },
            //解密方法（只解密需要解密的字段）
            decrypt: function (data, aeskey) {
                function decryRecurrence(data, aeskey) {
                    for (var key in data) {
                        if (angular.isObject(data[key]) || angular.isArray(data[key])) {
                            decryRecurrence(data[key], aeskey);
                        } else {
                            CONFIG.ENCODE_WORDS.forEach(function (v2) {
                                if (v2 === key) {
                                    data[key] = encryptObj.aesDecrypt(data[key], aeskey);
                                }
                            });
                        }
                    }
                    return data;
                }

                return decryRecurrence(data, aeskey);
            },
            //AES加密字符串,通过设备唯一识别码osnumber加密
            aesEnLocal: function (key, value) {
                resourceSvc.setLocal(key, CryptoJS.AES.encrypt(value, uuid).toString());
            },
            aesEnSession: function (key, value) {
                resourceSvc.setSession(key, CryptoJS.AES.encrypt(value, uuid).toString());
            },
            //AES解密字符串
            aesDeLocal: function (key) {
                if (resourceSvc.getLocal(key)) {
                    return CryptoJS.AES.decrypt(resourceSvc.getLocal(key), uuid).toString(CryptoJS.enc.Utf8);
                } else {
                    return null;
                }
            },
            aesDeSession: function (key) {
                if (resourceSvc.getSession(key)) {
                    return CryptoJS.AES.decrypt(resourceSvc.getSession(key), uuid).toString(CryptoJS.enc.Utf8);
                } else {
                    return null;
                }
            },
            //AES加密缓存对象
            aesEnObjectL: function (key, value) {
                resourceSvc.setLocal(key, CryptoJS.AES.encrypt(angular.toJson(value), uuid).toString());
            },
            aesEnObjectS: function (key, value) {
                resourceSvc.setSession(key, CryptoJS.AES.encrypt(angular.toJson(value), uuid).toString());
            },
            //AES解密缓存对象
            aesDeObjectL: function (key) {
                if (resourceSvc.getLocal(key)) {
                    return JSON.parse(CryptoJS.AES.decrypt(resourceSvc.getLocal(key), uuid).toString(CryptoJS.enc.Utf8));
                } else {
                    return null;
                }
            },
            aesDeObjectS: function (key) {
                if (resourceSvc.getSession(key)) {
                    return JSON.parse(CryptoJS.AES.decrypt(resourceSvc.getSession(key), uuid).toString(CryptoJS.enc.Utf8));
                } else {
                    return null;
                }
            },
            json2Base64: function (data) {
                return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(JSON.stringify(data))) + "";
            },
            base642Json: function (str) {
                return JSON.parse(CryptoJS.enc.Utf8.stringify(CryptoJS.enc.Base64.parse(str)));
            },
            /**
             * session
             * 加解密缓存
             * @param key 缓存key
             * @returns {{query: query, save: save, clear: clear}}
             */
            aesSessionTemp: function (key) {
                return {
                    /**
                     * 查询缓存对象值 [可查询缓存对象单个值]
                     * @param value null：查询key值 [string:查询key值某一个属性]
                     * @param defaultVal
                     * @returns {*}
                     */
                    query: function (value, defaultVal) {
                        if (value) {
                            var data = JSON.parse(encryption.aesDeSession(key) || "{}");
                            return data[value] || defaultVal;
                        }
                        return angular.copy(JSON.parse(encryption.aesDeSession(key) || "{}"));
                    },
                    /**
                     * 更新缓存对象
                     * @param params
                     */
                    save: function (params) {
                        var temp = JSON.parse(encryption.aesDeSession(key) || "{}");
                        encryption.aesEnSession(key, JSON.stringify(angular.extend(temp, params)));
                        return temp;
                    },
                    /**
                     * 清楚缓存对象
                     */
                    clear: function () {
                        resourceSvc.removeSession(key);
                    }
                }
            },
            /**
             * local
             * 同上
             * @param key
             * @returns {{query: query, save: save, clear: clear}}
             */
            aesLocalTemp: function (key) {
                return {
                    query: function (value, defaultVal) {
                        if (value) {
                            var data = JSON.parse(encryption.aesDeLocal(key) || "{}");
                            return data[value] || defaultVal;
                        }
                        return angular.copy(JSON.parse(encryption.aesDeLocal(key) || "{}"));
                    },
                    save: function (params) {
                        var temp = JSON.parse(encryption.aesDeLocal(key) || "{}");
                        encryption.aesEnLocal(key, JSON.stringify(angular.extend(temp, params)));
                        return temp;
                    },
                    clear: function (value) {
                        if (value) {
                            var data = JSON.parse(encryption.aesDeLocal(key) || "{}");
                            if (data[value]) {
                                delete data[value];
                            }
                        } else {
                            resourceSvc.removeLocal(key);
                        }
                    }
                }
            }
        };
        return appInfoSvc.getUUID().then(function (uid) {
            encryption.uuid = uuid = uid;
            return encryption;
        });
    }]);
