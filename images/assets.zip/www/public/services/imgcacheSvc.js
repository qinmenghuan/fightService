/**
 * add by fusy at 2016年3月28日
 *
 * 图片缓存
 * API: lib/imgcache/README.md
 */
publicModule.provider("imgCacheSvc", function () {

    var equals = angular.equals;

    ImgCache.$init = function () {
        ImgCache.init(function () {
            ImgCache.$deferred.resolve();
        }, function () {
            ImgCache.$deferred.reject();
        });
    };

    this.manualInit = false;

    this.setOptions = function (options) {
        angular.extend(ImgCache.options, options);
    };

    this.setOption = function (name, value) {
        ImgCache.options[name] = value;
    };

    this.$get = ["$q", "resourceSvc", function ($q, resourceSvc) {

        ImgCache.$deferred = $q.defer();
        ImgCache.$promise = ImgCache.$deferred.promise;
        ImgCache.setLocal = function (cacheId, url) {
            var localCacheUrl = resourceSvc.getLocalObj("localCacheUrl");
            localCacheUrl[cacheId] = url;
            resourceSvc.setLocal("localCacheUrl", localCacheUrl);
        };

        ImgCache.getLocal = function (cacheId) {
            var localCacheUrl = resourceSvc.getLocalObj("localCacheUrl");
            return localCacheUrl[cacheId];
        };

        ImgCache.checkUrl = function (cacheId, url) {
            if (!ImgCache.getLocal(cacheId)) {
                return true;
            }
            return equals(ImgCache.getLocal(cacheId), url);
        };

        if (!this.manualInit) {
            ImgCache.$init();
        }

        return ImgCache;
    }];

}).directive("imgCache", ["imgCacheSvc", "$compile", "$timeout", "CONFIG", function (imgCacheSvc, $compile, $timeout, CONFIG) {

    return {
        restrict: "A",
        scope: {
            icBg: "@",
            icSrc: "@",
            default: "@",
            imgLoadErr: "=",
            scopeSelf: "@"
        },
        link: function (scope, el, attrs) {
            console.log(scope.scopeSelf);
            var promise;
            var setImg = function (type, el, src) {
                imgCacheSvc.getCachedFileURL(src, function (src, dest) {
                    var img_src = dest; //.fullPath.replace("/". ImgCache.options.localCacheFolder, ImgCache.getCacheFolderURI());
                    if (type === "bg") {
                        el.css({
                            "background": "url(" + img_src + ")",
                            "background-size": "cover",
                            "background-repeat": "no-repeat",
                            "background-position": "center"
                        });
                    } else {
                        el.attr("src", img_src);
                    }
                });
            };

            var setImgBywww = function (type, el, src) {
                if (type === "bg") {
                    el.css({
                        "background": "url(" + src + ")",
                        "background-size": "cover",
                        "background-repeat": "no-repeat",
                        "background-position": "center"
                    });
                } else {
                    el.attr("src", src);
                }
            };

            var loadImg = function (type, el, src) {
                imgCacheSvc.$promise.then(function () {
                    if (src) {
                        promise = $timeout(function () {
                            if (angular.isFunction(scope.imgLoadErr)) {
                                scope.imgLoadErr(el);
                            }
                        }, CONFIG.HTTP_TIMEOUT);
                        imgCacheSvc.isCached(src, function (path, success) {
                            if (success) {
                                setImg(type, el, src);
                            } else {
                                //缓存图片
                                imgCacheSvc.cacheFile(src, function () {
                                    setImg(type, el, src);
                                }, function () {
                                    setImgBywww(type, el, src);
                                });
                            }

                        });
                    } else {
                        setImgBywww("bg", el, "img/error.jpg");
                    }
                });
            };

            el[0].onload = function () {
                // loadingHide();
                $timeout.cancel(promise);
            };
            el[0].onerror = function () {
                // failure();
                // loadingHide();
                if (angular.isFunction(scope.imgLoadErr)) {
                    scope.imgLoadErr(el);
                }
                $timeout.cancel(promise);
            };
            attrs.$observe("icSrc", function (src) {
                loadImg("src", el, src);
            });
        }
    };
}]).config(["imgCacheSvcProvider", "CONFIG", function (imgCacheSvcProvider, CONFIG) {

    // 暂时未知初始化就缓存不了图片的问题，故先注释掉，让程序正常显示
    // if (CONFIG.DEBUG_ON_DEVICE) {
    //     imgCacheSvcProvider.manualInit = true; //初始化
    // }

    imgCacheSvcProvider.setOptions({
        debug: false, //调试模式开启
        usePersistentCache: true,
        /* false = use temporary cache storage */
        localCacheFolder: CONFIG.IMG_CACHE_FOLDER /* name of the cache folder */
    });
}]);
