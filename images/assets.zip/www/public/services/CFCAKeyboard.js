/**
 *
 * 密码键盘H5版本。 版本信息：v4.1.0.3
 *
 */
(function (window, angular) {
    var extend = angular.extend,
        forEach = angular.forEach,
        isFunction = angular.isFunction;
    publicModule.provider('keyboardSvc', function () {
        var config = this.config = {
            outputType: OUTPUT_TYPE_HASH, //OUTPUT_TYPE_HASH or OUTPUT_TYPE_ORIGINAL,
            cipherType: CIPHER_TYPE_SM2, //CIPHER_TYPE_SM2 or CIPHER_TYPE_RSA,
            minLength: 6, //The input characters minimum length 6
            maxLength: 6, //The input character maximum length 8
            matchRegex: "",
            serverRandom: null,
            keyboardType: "NumberKeyboard", //NumberKeyboard or SymbolKeyboard or CompleteKeyboard
            randomNumber: true
        };
        this.setConfig = function (options) {
            extend(config, options);
        };
        this.$get = ['$timeout', '$q', '$rootScope', function ($timeout, $q, $rootScope) {
            var KBMap = {};
            var completeKeyboard = null;
            var numberKeyboard = null;
            var symbolKeyboard = null;
            //var privateMethod = {};
            var publicMethod = {
                setKBMap: function (KB, id) {
                    KBMap[id] = KB;
                },
                getKBMap: function (id) {
                    return KBMap[id];
                },
                getConfig: function () {
                    return config;
                },
                getServerRandom: function () {
                    return config.serverRandom;
                },
                setUpEvent: function (elem, eventType, handler) {
                    return (elem.attachEvent ? elem.attachEvent("on" + eventType, handler) : ((elem.addEventListener) ? elem.addEventListener(eventType, handler, false) : null));
                },
                setConfig: function (options, id) {
                    var KB = publicMethod.getKBMap(id);
                    if (CFCA_OK != KB.setServerRandom(options.serverRandom, id)) console.error("setServerRandom error");
                    if (CFCA_OK != KB.setMinLength(options.minLength, id)) console.error("setMinLength error");
                    if (CFCA_OK != KB.setMaxLength(options.maxLength, id)) console.error("setMaxLength error");
                    if (CFCA_OK != KB.setOutputType(options.outputType, id)) console.error("setOutputType error");
                    if (CFCA_OK != KB.setCipherType(options.cipherType, id)) console.error("setCipherType error");
                    if (CFCA_OK != KB.setMatchRegex(options.matchRegex, id)) console.error("setMatchRegex error");
                    KB.randomNumber(options.randomNumber);
                },
                setServerRandom: function (serverRandom) {
                    config.serverRandom = serverRandom;
                },
                getServerRandom: function () {
                    return config.serverRandom;
                },
                clear: function (id) {
                    var KB = this.getKBMap(id);
                    $rootScope.$broadcast("keyboard-clear");
                    KB.clearInputValue(id);
                },
                //获取input加密后数据
                /**
                 * 获取input加密后数据
                 * errorCode错误解释，因为没有文档，错误码解释仅供参考
                 * 0  CFCA_OK  成功
                 * 1001: CFCA_ERROR_INVALID_PARAMETER  参数错误
                 * 1002: CFCA_ERROR_INVALID_SIP_HANDLE_ID  无效的 SIP ID，表示安全输入键盘并未创建
                 * 1003: CFCA_ERROR_INPUT_LENGTH_OUT_OF_RANGE  输入数据长度不在有效范围内
                 * 1004: CFCA_ERROR_INPUT_VALUE_IS_NULL  输入数据为空
                 * 1005: CFCA_ERROR_SERVER_RANDOM_INVALID  输入服务端随机数无效
                 * 1006: CFCA_ERROR_SERVER_RANDOM_IS_NULL  服务端随机数为空
                 * 1007: CFCA_ERROR_INPUT_VALUE_NOT_MATCH_REGEX 输入数据不匹配正则表达式
                 * 1008: CFCA_ERROR_RSA_ENCRYPT_FAILED  RSA 加密失败
                 * @param id
                 * @returns {{encryptedInputValue: string, encryptedClientRandom: string, errorCode: number}}
                 */
                getEncrypt: function (id) {
                    var KB = publicMethod.getKBMap(id);
                    var encryptedInputValue = KB.getEncryptedInputValue(id);
                    var errorCode = KB.getErrorCode(id).toString(16);
                    var encrypt = {
                        encryptedInputValue: encryptedInputValue,
                        encryptedClientRandom: "",
                        errorCode: errorCode
                    };
                    if (errorCode != CFCA_OK) {
                        console.error("加密输入数据错误 0x" + errorCode);
                        return encrypt; //如果错误 一定要return；调用 KB.getEncryptedClientRandom(id) 方法会刷新错误码
                    }
                    var encryptedClientRandom = KB.getEncryptedClientRandom(id);
                    errorCode = KB.getErrorCode(id).toString(16);
                    encrypt.encryptedClientRandom = encryptedClientRandom;
                    encrypt.errorCode = errorCode;
                    if (errorCode != CFCA_OK) {
                        console.error("加密输入随机数据错误 0x" + errorCode);
                        return encrypt;
                    }
                    return encrypt;
                },
                hideKeyboardAll: function () {
                    if (completeKeyboard) completeKeyboard.hideKeyboard();
                    if (numberKeyboard) numberKeyboard.hideKeyboard();
                    if (symbolKeyboard) symbolKeyboard.hideKeyboard();
                },
                checkEqual: function (sipboxId1, sipboxId2) {
                    var KB = publicMethod.getKBMap(sipboxId1);
                    return KB.checkInputValueMatch(sipboxId1, sipboxId2);
                },
                checkRegex: function (sipboxId) {
                    var KB = publicMethod.getKBMap(sipboxId);
                    return KB.checkMatchRegex(sipboxId)
                },
                createNumberKeyboard: function () {
                    // if (numberKeyboard == null) {
                    numberKeyboard = new CFCAKeyboard("NumberKeyboard", KEYBOARD_TYPE_DIGITAL);
                    // }
                    return numberKeyboard;
                },
                createSymbolKeyboard: function () {
                    symbolKeyboard = new CFCAKeyboard("SymbolKeyboard", KEYBOARD_TYPE_SYMBOL);
                    return symbolKeyboard;
                },
                createCompleteKeyboard: function () {
                    completeKeyboard = new CFCAKeyboard("CompleteKeyboard", KEYBOARD_TYPE_COMPLETE);
                    return completeKeyboard;
                },
                onKeyDown: function (keyDownCallback) {
                    var keyEls = document.getElementsByClassName("cfca-btn");
                    var lastTouch = "";
                    forEach(keyEls, function (el) {
                        ionic.onGesture('touchend', function (e) {
                            keyDownCallback(e, el);
                        }, el);
                    })
                },
                getKeyboardModal: function () {
                    return angular.element(document.getElementById("KeyboardModal"));
                },
                getModalBg: function () {
                    return angular.element(document.getElementById("up-modal-bg"));
                },
                toggleKeyboard: function () {
                    var modal = this.getKeyboardModal();
                    var bg = this.getModalBg();
                    modal.toggleClass("up-modal-show");
                    bg.toggleClass("show");
                },
                closeKeyboard: function () {
                    var modal = this.getKeyboardModal();
                    var bg = this.getModalBg();
                    modal.removeClass("up-modal-show");
                    bg.removeClass("show");
                },
                showKeyboard: function () {
                    var modal = this.getKeyboardModal();
                    var bg = this.getModalBg();
                    modal.addClass("up-modal-show");
                    bg.addClass("show");
                },
                showKeyboardModal: function (config) {
                    //var NumberKeyboard = document.getElementById("NumberKeyboard"); //NumberKeyboard.offsetHeight
                    var kbWrap = document.getElementById("pay-pw-content"); //NumberKeyboard.offsetHeight
                    var KeyboardModalSwiper = document.getElementById("KeyboardModalSwiper"); //NumberKeyboard.offsetHeight
                    var deferred = $q.defer();
                    $timeout(function () {
                        var swiper = new Swiper('#KeyboardModalSwiper', angular.extend({
                            autoplayDisableOnInteraction: false,
                            onlyExternal: true
                        }, config));
                        swiper.updateContainerSize();
                        deferred.resolve(swiper);
                    });
                    angular.element(KeyboardModalSwiper).css("height", (43 + kbWrap.offsetHeight) + "px");
                    this.showKeyboard();
                    this.swiperDeferred = deferred.promise;
                    this.hideModalCallback = config.hideModalCallback;
                    return deferred.promise;
                },
                hideKeyboardModal: function () {
                    this.closeKeyboard();
                    if (isFunction(this.hideModalCallback)) {
                        this.hideModalCallback();
                    }
                },
                slideNext: function () {
                    var swiperDeferred = this.swiperDeferred;
                    if (swiperDeferred) {
                        swiperDeferred.then(function (swiper) {
                            swiper.slideNext();
                        })
                    }
                },
                slidePrev: function () {
                    var swiperDeferred = this.swiperDeferred;
                    if (swiperDeferred) {
                        swiperDeferred.then(function (swiper) {
                            swiper.slidePrev();
                        })
                    }
                }
            };
            (function () {
                //document 的touchstart事件。点击视图 如果点击的当前元素 不存在 noNeedHideIds 和 noNeedHideGroup list 中，则关闭键盘
                publicMethod.setUpEvent(document, "touchstart", function (e) {
                    var elem = e.srcElement || e.target;
                    var noNeedHideIds = ["CompleteKeyboard", "NumberKeyboard", "SymbolKeyboard"];
                    var noNeedHideGroup = ["keyboard"];
                    while (elem) {
                        if (noNeedHideIds.indexOf(elem.id) !== -1) {
                            return;
                        }
                        if (noNeedHideGroup.indexOf(elem.group) !== -1) {
                            return;
                        }
                        elem = elem.parentNode;
                    }
                    publicMethod.closeKeyboard();
                });
                $rootScope.$on("$stateChangeStart", function () {
                    var el = document.getElementById("NumberKeyboard");
                    if (el) {
                        angular.element(el.parentNode).remove();
                    }
                    KBMap = {};
                    completeKeyboard = null;
                    numberKeyboard = null;
                    symbolKeyboard = null;
                    publicMethod.closeKeyboard();
                });
                $rootScope.$on("$ionicView.loaded", function () {
                    if (isFunction(publicMethod.IonicViewLoadedCallback)) {
                        publicMethod.IonicViewLoadedCallback()
                    }
                });
            })();
            return publicMethod;
        }]
    })
        .controller('KeyboardModalCtrl', ['keyboardSvc', '$scope', 'appInitSvc', function (keyboardSvc, $scope, appInitSvc) {

            var kid = $scope.kid = "pay-keyboard" + new Date().getTime();

            $scope.config = {
                serverRandomPromise: appInitSvc.synServerRandom(),
                doneCallback: function (event, id) {
                    if (isFunction(keyboardSvc.doneCallback)) {
                        keyboardSvc.doneCallback(event, id);
                    }
                }
            };

            $scope.status = "success";

            $scope.$on("pay-success", function () {
                console.log("pay-success");
                $scope.status = "success";
            });
            $scope.$on("pay-error", function () {
                console.log("pay-error");
                $scope.status = "error";
            })


        }])
        .directive('keyboardInput', ['keyboardSvc', '$rootScope', '$timeout', function (keyboardSvc, $rootScope, $timeout) {
            // Runs during compile
            var KEYBOARD_TEMPLATE = '<div class="kb-wrap" id="kb-wrap">' +
                '<div class="kb-input clearfix">' +
                '<span ng-bind="pw[0]"></span>' +
                '<span ng-bind="pw[1]"></span>' +
                '<span ng-bind="pw[2]"></span>' +
                '<span ng-bind="pw[3]"></span>' +
                '<span ng-bind="pw[4]"></span>' +
                '<span ng-bind="pw[5]"></span></div>' +
                '<input type="text" readonly="true" hidden></div>';
            return {
                // name: '',
                // priority: 1,
                // terminal: true,
                scope: {
                    config: "=",
                    kId: "="
                }, //= isolate, true = child, false/undefined = no change
                // controller: function($scope, $element, $attrs, $transclude) {},
                //require: 'ngModel', // Array = multiple requires, ? = optional, ^ = check parent elements
                // restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
                template: KEYBOARD_TEMPLATE,
                // templateUrl: '',
                replace: true,
                // transclude: true,
                // compile: function(tElement, tAttrs, function transclude(function(scope, cloneLinkingFn){ return function linking(scope, elm, attrs){}})),
                compile: function (element, attributes) {
                    var options = keyboardSvc.getConfig();
                    var input = element[0].getElementsByTagName("input");
                    var _id;
                    var KB;
                    element[0].group = "keyboard";

                    function $link(scope, iEle) {
                        _id = input[0].id = scope.kId;
                        scope.pw = [];
                        var config = extend(options, scope.config || {});

                        if (attributes.keyboardType === 'NumberKeyboard') {
                            KB = keyboardSvc.createNumberKeyboard();
                        }
                        if (attributes.keyboardType === "SymbolKeyboard") {
                            KB = keyboardSvc.createSymbolKeyboard();
                        }
                        if (attributes.keyboardType === "CompleteKeyboard") {
                            KB = keyboardSvc.createCompleteKeyboard();
                        }
                        KB.clearInputValue(_id);
                        keyboardSvc.setKBMap(KB, _id);
                        KB.bindInputBox(_id);
                        config.serverRandomPromise.then(function (serverRandom) {
                            config.serverRandom = serverRandom;
                            keyboardSvc.setServerRandom(serverRandom);
                            iEle.ready(function () {
                                keyboardSvc.setConfig(config, _id);
                            });
                            iEle.bind("click", function () {
                                if (isFunction(config.onFocus)) {
                                    config.onFocus();
                                }
                                keyboardSvc.toggleKeyboard();
                            });
                        });

                        KB.setDoneCallback(doneCallback);
                        var keyInput = document.getElementById(_id);
                        keyboardSvc.onKeyDown(function (e, key) {
                            if (key.id == "NumberKeyboard___del-number") {
                                scope.pw.pop();
                                scope.$apply();
                            } else if (key.id == "NumberKeyboard___done-number") {

                            } else {
                                $timeout(function () {
                                    for (var i = scope.pw.length; i < keyInput.value.length; i++) {
                                        scope.pw.push("*");
                                    }
                                    if (keyInput.value.length === 6 && isFunction(config.validateCallback)) {
                                        config.validateCallback()
                                    }
                                    scope.$apply();
                                });
                            }

                            $timeout(function () {
                                if (isFunction(config.onKeyDown)) {
                                    config.onKeyDown(keyInput.value.length);
                                    scope.$apply();
                                }
                            });
                        });

                        scope.$on("keyboard-clear", function () {
                            scope.pw = [];
                        });

                        function doneCallback(id) {
                            var event = {
                                default: true,
                                preventDefault: function () {
                                    this.default = false;
                                }
                            };
                            if (isFunction(config.doneCallback)) {
                                config.doneCallback(event, id);
                                scope.$apply();
                            }
                            if (event.default) {
                                keyboardSvc.closeKeyboard();
                            }
                        }
                    }

                    return $link;
                }
            }
        }])
        .directive('numberKeyboard', ['keyboardSvc', function (keyboardSvc) {
            return {
                restrict: "A",
                scope: {
                    numberKeyboard: "="
                },
                link: function (scope, iEle) {
                    var KB = keyboardSvc.createNumberKeyboard();
                    var id = iEle.attr("id");
                    var options = keyboardSvc.getConfig();
                    var config = extend(options, scope.numberKeyboard || {});
                    iEle[0].group = "keyboard";
                    KB.clearInputValue(id);
                    keyboardSvc.setKBMap(KB, id);
                    KB.bindInputBox(id);
                    config.serverRandomPromise.then(function (serverRandom) {
                        config.serverRandom = serverRandom;
                        keyboardSvc.setServerRandom(serverRandom);
                        iEle.ready(function () {
                            keyboardSvc.setConfig(config, id);
                        });
                        iEle.bind("click", function () {
                            KB.randomNumber(true);
                            iEle[0].blur();
                            if (isFunction(config.onFocus)) {
                                config.onFocus();
                            }
                            keyboardSvc.toggleKeyboard();
                        });
                    });
                    KB.setDoneCallback(doneCallback);
                    keyboardSvc.onKeyDown(function () {
                        if (isFunction(config.onKeyDown)) {
                            config.onKeyDown();
                            scope.$apply();
                        }
                    });
                    function doneCallback(id) {
                        var event = {
                            default: true,
                            preventDefault: function () {
                                this.default = false;
                            }
                        };
                        if (isFunction(config.doneCallback)) {
                            config.doneCallback(event, id);
                            scope.$apply();
                        }
                        if (event.default) {
                            keyboardSvc.closeKeyboard();
                        }
                    }
                }
            };
        }]);
})(window, angular);