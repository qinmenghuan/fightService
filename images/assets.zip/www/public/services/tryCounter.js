/**
 * 试算服务
 * @author wf 2016-1-11
 * @desc
 */

publicModule.factory('tryCounter',
    function (resourceSvc,CONSTANT) {
                //配置试算参数
                var counter = {};
                var moneyfun = function (str, $index) {
                    console.log(str);
                    counter.money = str.itemkey;
                    for (var i = 0; i < counter.mSpeedy.length; i++) {
                        counter.mChecked[i] = false;
                    }
                    counter.mChecked[$index] = true;
                    console.log(counter.money);
                };
                var timefun = function (str, $index) {
                    counter.time = str.itemkey;
                    for (var i = 0; i < counter.tSpeedy.length; i++) {
                        counter.tChecked[i] = false;
                    }
                    counter.tChecked[$index] = true;
                    console.log(counter.time);
                };
                var levelfun = function (str, $index) {
                    counter.level = str.itemkey;
                    for (var i = 0; i < counter.lSpeedy.length; i++) {
                        counter.lChecked[i] = false;
                    }
                    counter.lChecked[$index] = true;
                    console.log(counter.level);
                };
        return {
            //初始化试算参数
            init:function(){
                counter = {
                    money: '',
                    mChecked: [],
                    mSpeedy: [],
                    time:'',
                    tChecked:[],
                    tSpeedy:[],
                    level:'',
                    lChecked:[],
                    lSpeedy:[]
                };
               // 从数据字典获取金额，时间及卡级别
                var dictList = resourceSvc.getLocalObj(CONSTANT.DICT);
                var compare = function (prop) {
                    return function (obj1, obj2) {
                        var val1 = Number(obj1[prop]);
                        var val2 = Number(obj2[prop]);
                        if (val1 < val2) {
                            return -1;
                        } else if (val1 > val2) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                }
               dictList.map(function (item) {
                   if (item.dict == "znck_cstlvl") {
                       item.itemKeyNum = Number(item.itemkey);
                       counter.lSpeedy.push(item);
                   }
                   if(item.dict == "znck_trlamt"){
                       item.itemKeyNum = Number(item.itemkey);
                       counter.mSpeedy.push(item);
                   }
                   if(item.dict == "znck_trlday"){
                       counter.tSpeedy.push(item);
                   }
               });
                counter.mSpeedy.sort(compare("itemkey"));
                counter.tSpeedy.sort(compare("itemkey"));
                counter.lSpeedy.sort(compare("itemkey"));
               counter.money = counter.mSpeedy[0].itemkey;
               counter.mChecked[0] = true;
               counter.time = counter.tSpeedy[0].itemkey;
               counter.tChecked[0] = true;
               counter.level = counter.lSpeedy[0].itemkey;
               counter.lChecked[0] = true;
               return counter;
           }, //切换试算参数并请求试算结果
            speedyChoose : function (type,str, $index,callback) {
                switch (type){
                    case "0":
                        moneyfun(str, $index);
                        break;
                    case "1":
                        timefun(str, $index);
                        break;
                    case "2":
                        levelfun(str, $index);
                        break;
                }
                callback();
            }
        };
    }
);


