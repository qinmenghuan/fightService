/**
 * Created by fusy on 2016/4/22.
 * 这个服务的作用 是监听 页面切换 按钮点击 发送请求动作 表单验证等事件
 */
(function (window, angular) {
    "use strict";
    var isFunction = angular.isFunction,
        eventCount = 0,
        extend = angular.extend,
        forEach = angular.forEach;
    var stateEvent = {
            stateChangeStart: {},
            stateChangeSuccess: {},
            stateNotFount:{},
            stateChangeError:{}
        },
        touchEvent = {
            touchmove: {},
            touchend: {},
            touchstart:{},
        },
        httpEvent = {};
    $commonEventProvider.$inject = ["$httpProvider"];
    function $commonEventProvider($httpProvider) {
        var stateChangeHistory = [], config = {
            stateChangeHistorySize: 10
        };

        this.setConfig = function (conf) {
            extend(config, conf);
        };

        //$httpProvider.interceptors.push("commonEventHttpInterceptor");

        $get.$inject = ["$rootScope"];
        function $get($rootScope) {
            var index = 0;
            //监听页面切换事件
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
                forEach(stateEvent.stateChangeStart, function(callback){
                    if (isFunction(callback)) {
                        callback(event, toState, toParams, fromState, fromParams);
                    }
                });
            });
            //页面切换成功
            $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
                forEach(stateEvent.stateChangeSuccess, function(callback){
                    if (isFunction(callback)) {
                        callback(event, toState, toParams, fromState, fromParams);
                    }
                });

                if (stateChangeHistory.length >= config.stateChangeHistorySize) {
                    stateChangeHistory = [];
                    index = 0;
                }
                stateChangeHistory.push({
                    id: index++,
                    event: event,
                    toState: toState,
                    toParams: toParams,
                    fromState: fromState,
                    fromParams: fromParams
                });
            });
            //找不到页面
            $rootScope.$on("$stateNotFount", function (event, toState, toParams, fromState, fromParams) {
                forEach(stateEvent.stateNotFount, function(callback){
                    if (isFunction(callback)) {
                        callback(event, toState, toParams, fromState, fromParams);
                    }
                });

            });
            //页面切换错误
            $rootScope.$on("$stateChangeError", function (event, toState, toParams, fromState, fromParams) {
                forEach(stateEvent.stateChangeError, function(callback){
                    if (isFunction(callback)) {
                        callback(event, toState, toParams, fromState, fromParams);
                    }
                });
            });
            var publicMethod = {
                makeValidEvent: [],
                makeInvalidEvent: [],
                on: function (eventName, callback) {
                    switch (eventName) {
                        case "$stateChangeStart": //切换路由事件
                            stateEvent.stateChangeStart[eventCount++] = callback;
                            break;
                        case "$stateChangeSuccess": //切换路由成功事件
                            stateEvent.stateChangeSuccess[eventCount++] = callback;
                            break;
                        case "$stateNotFount": //路由未找到事件
                            stateEvent.stateNotFount[eventCount++] = callback;
                            break;
                        case "$stateChangeError": //理由切换失败事件
                            stateEvent.stateChangeError[eventCount++] = callback;
                            break;
                        case "touchMove":
                            touchEvent.touchmove[eventCount++] = callback;
                            break;
                        case "touchEnd":
                            touchEvent.touchend[eventCount++] = callback;
                            break;
                        case "touchStart":
                            touchEvent.touchstart[eventCount++] = callback;
                            break;
                        case "request":
                            httpEvent.requestEvent = callback;
                            break;
                        case "requestError":
                            httpEvent.requestErrorEvent = callback;
                            break;
                        case "response":
                            httpEvent.responseEvent = callback;
                            break;
                        case "responseError":
                            httpEvent.responseErrorEvent = callback;
                            break;
                        case "makeValid": //表单验证通过事件
                            publicMethod.makeValidEvent.push(callback);
                            break;
                        case "makeInvalid": //表单验证未通过事件
                            publicMethod.makeInvalidEvent.push(callback);
                            break;
                        default :console.log("commonEvent ： 没有找到" + eventName + "事件");
                    }
                },
                /**
                 * 获取我路由切换成功后的历史 默认最大保存10个state
                 * @returns {Array}
                 */
                getStateHistory: function () {
                    return stateChangeHistory;
                }
            };
            return publicMethod;
        }

        this.$get = $get;
    }

    bodyDirective.$inject = ["$q"];
    function bodyDirective($q) {
        return {
            restrict: "E",
            link: function (scope, el, attr) {
                var event = "touchmove|touchend|touchstart";
                event.split("|").forEach(function (event) {
                    el.bind(event, function (e) {
                        var targ;
                        if (!e) {
                            e = window.event;
                        }
                        if (e.target) {
                            targ = e.target;
                        } else if (e.srcElement) {
                            targ = e.srcElement;
                        }
                        if (targ.nodeType == 3) { // defeat Safari bug
                            targ = targ.parentNode;
                        }
                        touchEvent[event + "Promise"] = $q.when(e, targ);
                        forEach(touchEvent[event], function(callback){
                            if (isFunction(callback)) {
                                callback(e, targ);
                            }
                        });
                    })
                });

            }
        }
    }

    commonEventHttpInterceptor.$inject = ["$q"];
    function commonEventHttpInterceptor($q) {
        return {
            "request": function (config) {
                console.log("request:",config);
                if (isFunction(httpEvent.requestEvent)) {
                    extend(config, httpEvent.requestEvent(config));
                }
                return config;
            },
            "requestError": function (rejection) {
                console.log("requestError", rejection);
                if (isFunction(httpEvent.requestErrorEvent)) {
                    extend(rejection, httpEvent.requestErrorEvent(rejection));
                }
                return $q.reject(rejection);
            },
            "response": function (response) {
                console.log("response", response);
                if (isFunction(httpEvent.responseEvent)) {
                    extend(response, httpEvent.responseEvent(response));
                }
                return response;
            },
            "responseError": function (rejection) {
                console.log("rejection", rejection);
                if (isFunction(httpEvent.responseErrorEvent)) {
                    extend(rejection, httpEvent.responseErrorEvent(rejection));
                }
                return $q.reject(rejection);
            }
        };
    }

    angular.module("commonEvent", [])
        .provider("commonEvent", $commonEventProvider)
        .directive("body", bodyDirective)
        //.service("commonEventHttpInterceptor", commonEventHttpInterceptor);
})(window, angular);
