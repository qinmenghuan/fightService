/**
 * Created by Luo Xianli on 2016/12/9.
 */
publicModule.factory('pdfSvc', function (popupSvc) {

    /**
     * android阅读pdf
     * @param url
     * @param title
     */
    function readPDFAndroid(url, title) {
        try {
            //if (url && (url.lastIndexOf('=') + 1) < url.length) {
            //} else {
            //    popupSvc.error("下载文件失败");
            //    return;
            //}
            var path = cordova.file.externalDataDirectory + new Date().getTime() + ".pdf";
            var ft = new FileTransfer();
            popupSvc.loadingShow();
            ft.download(encodeURI(url), path, function (entry) {
                popupSvc.loadingHide();
                //alert(JSON.stringify(entry));
                if (PDFPlugin && entry) {
                    //alert('获取到插件' + entry.toURL().substring(7));
                    PDFPlugin.readPDF({
                        path: entry.toURL().substring(7),
                        title: title,
                        is_vertical: true
                    }, function (success) {
                        //alert('success');
                    }, function (error) {
                        //alert("error");
                    });
                } else {
                    //alert('插件找不到');
                }
            }, function (error) {
                console.log(error);
                popupSvc.loadingHide();
            }, true);
        } catch (e) {
            console.log(e);
        }
    }

    /**
     * ios阅读pdf
     * @param url
     * @param title
     */
    function readPDFIos(url, title) {
        cordova.ThemeableBrowser.open(url, '_blank', {
            statusbar: {
                color: '#ffffff'
            },
            toolbar: {
                height: 44,
                color: '#f0f0f0'
            },
            title: {
                color: '#000',
                showPageTitle: true,
                staticText: title
            },
            backButton: {
                wwwImage: 'images/back.png',
                wwwImagePressed: 'images/back.png',
                wwwImageDensity: 2,
                align: 'left',
                event: 'backPressed'
            },
            backButtonCanClose: true
        });
    }


    return {
        /**
         * 阅读pdf文件
         * @param url
         * @param title
         */
        readPDF: function (url, title) {
            document.addEventListener('deviceready', function () {
                if (ionic.Platform.isAndroid()) {
                    readPDFAndroid(url, title);
                } else if (ionic.Platform.isIOS) {
                    readPDFIos(url, title);
                } else {
                    //其他平台
                }
            });
        }
    };
});