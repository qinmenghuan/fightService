/**
 * Created by wwk on 16/6/17.
 */
/**
 * kkDIYKeyboardService公用自制密码键盘服务服务
 * @author  2016-06-17 15:22
 * @desc 模仿cfca键盘自制前后端加密键盘服务
 *
 */
'use strict';
publicModule.factory('kkDIYKeyboardService', [function () {
    //传入公钥,服务端随机数,输入的密码
    return {
        submit: function (pubkey, server_random_base, pwd) {
            // console.log(pubkey, server_random_base, pwd);
            var base64 = new BBase64();
            var server_random = base64.decode(server_random_base);
            // console.log('解base64后的服务端随机数', server_random);

            //设置16位客户端随机数
            var data = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
            var client_random0 = "";
            for (var i = 0; i < 16; i++) { //产生16位就使i<16
                r = Math.floor(Math.random() * 10);
                client_random0 += data[r];
            }
            // console.log('客户端随机数', client_random0); //16位数字客户端随机数

            //对客户端随机数用公钥进行RSA加密
            var encrypt = new JSEncrypt();
            encrypt.setPublicKey(pubkey);
            var encrypted = encrypt.encrypt(client_random0);
            // console.log('加密客户端随机数', encrypted);

            //组合服务器随机数和客户端随机数
            // console.log(server_random + client_random0);
            var pwdkey = server_random.substring(server_random.length - 4, server_random.length) +
                client_random0.substring(client_random0.length - 4, client_random0.length);
            // console.log('组合服务器随机数和客户端随机数', pwdkey);

            var key = pwdkey;
            var iv = '';

            key = CryptoJS.enc.Utf8.parse(key);
            iv = CryptoJS.enc.Utf8.parse(iv);

            // DES 加密
            var des = CryptoJS.DES.encrypt(pwd, key, {
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });

            // 转换为字符串
            des = des.toString();
            console.log('加密密码', des);
            return [server_random_base, encrypted, des];//服务端随机数,客户端随机数,加密密码

        }
    }
}]);
