/**
 * Created by kayak on 2016/12/23.
 */
publicModule.factory('deviceSyncSvc', function (encryptSvc, homeSvc, resourceSvc, appInfoSvc, CONSTANT) {
    //设备同步接口服务
    var device = {
        uuid: 'uuidfjsldjflsdjf',
        model: "华为",
        platform: 'Android',
        version: '6.0',
        serial: '742934729374923749427349'
    };

    function deviceSync(appVersion) {
        alert();
        encryptSvc.then(function (encrypt) {
            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
            var userId = userInfo.query("user_id") || "";

            var params = {
                head_osnumber: resourceSvc.getLocal(CONSTANT.UUID),
                user_id: userId,
                model: device.model,
                mgcf: device.platform,
                app_version: appVersion,
                version: device.version,
                imei: device.serial,
                pixels: appInfoSvc.getPixels(),
                network_operator: appInfoSvc.getNetwork(),
                mobile: 123
            };
            homeSvc.synchronizeDevice(params).then(function (data) {
                console.log("设备同步接口：", data);
                //alert(data);
                if (data.head_ret_code == '0000') {
                    console.log('设备同步成功');
                }
            })
        })
    }

    return {
        //设备同步
        sync: function () {
            document.addEventListener('deviceReady', function () {
                //设备已准备就绪
                deviceSync(BuildInfo.version);
            });
        }
    }
});
