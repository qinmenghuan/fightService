/**
 * 获取session,local资源服务
 * author duying
 * create by nies in 2.29
 * edit by
 * update by
 */
publicModule.provider('resourceSvc', [
    function () {
        var resourceObj = {
            setItem: function (resource, key, value) {
                if (angular.isObject(value)) {
                    value = JSON.stringify(value);
                } else if (angular.isString(value) || angular.isNumber(value)) {
                    value = value.toString();
                }

                if (!angular.isString(key)) {
                    console.log('ERROR: the key of the resourceSvc only allow string!');
                    return false;
                }

                if (!angular.isString(value)) {
                    console.log('ERROR: the value of the resourceSvc only allow string or object!');
                    return false;
                }

                if (window[resource]) {
                    window[resource].setItem(key, value);
                }
            },
            getItem: function (resource, key, defaultValue) {
                if (!angular.isString(key)) {
                    console.log('ERROR: the key of the resourceSvc only allow string!');
                    return false;
                }

                if (window[resource]) {
                    return window[resource].getItem(key) || defaultValue || null;
                } else {
                    console.log('WARN: the platform don\'t support ' + resource + "!");
                    return defaultValue;
                }
            },
            removeItem: function (resource, key) {
                if (!angular.isString(key)) {
                    console.error('the key of the resourceSvc only allow string!');
                    return false;
                }

                if (window[resource]) {
                    window[resource].removeItem(key);
                }
            },
            clear: function (resource) {
                if (window[resource]) {
                    window[resource].clear();
                }
            }
        };

        this.setLocal = function (key, value) {
            resourceObj.setItem('localStorage', key, value);
        };
        this.getLocal = function (key, defaultValue) {
            return resourceObj.getItem('localStorage', key, defaultValue);
        };
        this.getLocalObj = function (key) {
            return JSON.parse(resourceObj.getItem('localStorage', key, "{}"));
        };
        this.removeLocal = function (key) {
            resourceObj.removeItem('localStorage', key);
        };
        this.clearLocal = function () {
            resourceObj.clear('localStorage');
        };
        this.setSession = function (key, value) {
            resourceObj.setItem('sessionStorage', key, value);
        };
        this.getSession = function (key, defaultValue) {
            return resourceObj.getItem('sessionStorage', key, defaultValue);
        };
        this.getSessionObj = function (key) {
            return JSON.parse(this.getSession(key, "{}"));
        };
        this.removeSession = function (key) {
            resourceObj.removeItem('sessionStorage', key);
        };
        this.clearSession = function () {
            resourceObj.clear('sessionStorage');
        };
        this.$get = function () {
            return this;
        };
    }]);

