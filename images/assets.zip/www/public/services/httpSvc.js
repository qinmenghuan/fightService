/**
 * 请求服务(可设置公共请求参数)
 * author duying
 * create by nies in 2.29
 * edit by fusy in 2016.9.6
 * update by
 */

publicModule.factory("httpSvc",
    function ($q,
              $http,
              $log,
              CONSTANT,
              CONFIG,
              encryptSvc,
              appInfoSvc,
              popupSvc,
              $filter,
              util,
              resourceSvc,
              $rootScope,
              permissionSvc,
              dataCacheSvc,
              $state) {
        var mainKey, workKey;
        var httpEncryptObj = {
            /**
             * 同步密钥
             */
            synKey: function () {
                var deferred = $q.defer();
                encryptSvc.then(function (encrypt) {
                    httpEncryptObj.requestMainKey(encrypt)
                        .then(function (data1) {
                            //获取工作密钥
                            console.log("=====request main key success");
                            httpEncryptObj.requestWorkKey(encrypt, data1.main, data1.re)
                                .then(function (data2) {
                                    console.log("=====request2222 work key success");
                                    deferred.resolve(data2);
                                }, function (error) {
                                    // console.log(url + "=====request2222 work key error");
                                    deferred.reject(error);
                                });
                        }, function (error) {
                            console.log(error + "=====request main key error");
                            deferred.reject(error);
                        });
                });
                return deferred.promise;
            },
            /**
             * 获取主密钥
             * 1.  移动端查看主密钥在APP本地缓存中是否存在，如果不存在的话发起请求主密钥接口(600010)，获取主密钥。
             * 2.  已存在主密钥，判断有效期。
             * 3.  对于已过期的主密钥，移动端发起请求主密钥接口。
             * 4.  服务端获取Redis缓存中的主密钥，如不存在主密钥，则返回错误码SE6001，前端重新请求主密钥接口。
             * getLocal: 从缓存获取,参数由请求时传入
             */
            requestMainKey: function (encrypt) {
                var deferred = $q.defer();
                //获取主密匙
                mainKey = encrypt.aesDeLocal(CONSTANT.MAIN_KEY);
                //缓存中没有密钥,或者不从缓存获取密钥,则从请求获取
                if (mainKey != null) {
                    deferred.resolve({main: mainKey, re: false});
                } else {
                    httpObj.getHttpPromise("POST", CONFIG.MAIN_KEY_URL, {
                        head_osnumber: encrypt.uuid,
                        expire_time: CONFIG.MAIN_TIME + "",
                        channel_id: "0"
                    })
                        .then(function (data) {//, status, headers, config
                            if (data.ret_code == '0000') {
                                //将主密匙,主密匙有效期加密存入local
                                encrypt.aesEnLocal(CONSTANT.MAIN_KEY, data.base_key);
                                //返回主密钥,主密钥重新获取时,工作密钥也重新获取
                                deferred.resolve({main: data.base_key, re: true});
                                console.log(data);
                            } else {
                                popupSvc.loading(data.ret_msg);
                                //popupSvc.loadingClose(data.ret_msg);
                                deferred.reject("ERROR: REQUEST MAINKEY NOT SUCCESS !");
                            }
                        }, function () {//data, status, headers, config
                            // console.log("ERROR: REQUEST MAINKEY ERROR !");
                            //popupSvc.loading(SYS_CONFIG.HTTP.HTTP_FAIL_MESSAGE);
                            deferred.reject("ERROR: REQUEST MAINKEY ERROR !");
                        });
                }
                return deferred.promise;
            },
            /**
             * 获取工作密钥
             * @param mainKey 主密钥
             * @param re 主密钥控制的重新获取
             * @returns {*|promise}
             */
            requestWorkKey: function (encrypt, mainKey, re) {
                var deferred = $q.defer();
                workKey = encrypt.aesDeObjectL(CONSTANT.WORK_KEY);
                console.log(workKey);
                //当工作密匙为空,或工作密匙有效期小于当前时间时,请求工作密钥
                if (workKey == null || re) {
                    httpObj.getHttpPromise("POST", CONFIG.WORK_KEY_URL, {
                        head_osnumber: encrypt.uuid,
                        expire_time: CONFIG.WORK_TIME + "",
                        channel_id: "0"
                    }).then(function (data) {//, status, headers, config
                        if (data.ret_code == "0000") {
                            //通过主密钥解密工作密钥密文
                            workKey = encrypt.decrypt(data, mainKey);
                            console.log(workKey);
                            //将解密后的工作密钥,有效期加密存入local
                            encrypt.aesEnObjectL(CONSTANT.WORK_KEY, workKey);
                            deferred.resolve(workKey);
                        } else if (data.ret_code == "SE6001") {//主密钥不存在/已过期
                            console.log("ERROR: REQUEST MAINKEY RELOAD !");
                            resourceSvc.removeLocal(CONSTANT.MAIN_KEY);
                            resourceSvc.removeLocal(CONSTANT.WORK_KEY);
                            return httpEncryptObj.synKey(false).then(function (value) {
                                deferred.resolve(value);
                            })
                        } else {
                            popupSvc.loading(data.ret_msg);
                            //popupSvc.loadingClose(data.ret_msg);
                            deferred.reject("ERROR: WORKKEY NOT SUCCESS !");
                        }
                    }, function () {//data, status, headers, config
                        // console.log("ERROR: WORKKEY ERROR !");
                        //popupSvc.loading(SYS_CONFIG.HTTP.HTTP_FAIL_MESSAGE);
                        deferred.reject("ERROR: WORKKEY ERROR !");
                    });
                } else {
                    deferred.resolve(workKey);
                }
                return deferred.promise;
            }
        };
        var httpObj = {
            /**
             * 初始化请求参数
             * @param params
             * @returns {*}
             */
            initParams: function (params) {
                var deferred = $q.defer();
                var today = new Date();
                var commonParams = {
                    head_channel_date: $filter("date")(today, "yyyyMMdd"), //渠道日期
                    head_channel_time: $filter("date")(today, "HHmmss") //渠道时间
                };
                $q.all([
                    appInfoSvc.getUUID(),
                    appInfoSvc.getChannelType(), //渠道码 0:互联网 1:移动-ios 2:移动android
                    encryptSvc
                ]).then(function (args) {
                    commonParams.head_osnumber = args[0];
                    // alert(3);
                    commonParams.head_channel_type = args[1];
                    commonParams.trans_id = args[0].substring(args[0].length - 8, args[0].length)
                        + $filter("date")(today, "yyyyMMddHHmmsss")
                        + util.random();//交易流水号
                    commonParams.head_jsessionid = args[2].aesDeLocal(CONSTANT.HEAD_JSESSIONID) || "";
                    commonParams.channel_id = "0";
                    commonParams.channel_src = CONSTANT.CHANNEL_SRC;
                    commonParams.head_area_code = appInfoSvc.getAdcode();
                    deferred.resolve(angular.extend(commonParams, params));
                }, function () {
                    deferred.reject("ERROR: 设备信息获取失败");
                });
                return deferred.promise;
            },
            /**
             * 获取请求类型
             * @param method
             * @param url
             * @param params
             * @returns {*}
             */
            getHttpPromise: function (method, url, params) {
                var deferred = $q.defer();
                var config = angular.extend({}, {
                    "method": method,
                    "url": CONFIG.HTTP_URL + url,
                    "headers": {
                        "Accept": CONFIG.HTTP_HEADERS_ACCEPT,
                        "Content-Type": CONFIG.HTTP_HEADERS_CONTENT_TYPE
                    },
                    "timeout": CONFIG.HTTP_TIMEOUT,
                    "responseType": CONFIG.HTTP_RESPONSE_TYPE
                });

                if (angular.uppercase(method) === "GET") {
                    config = angular.extend(config, {"params": params});
                } else if (angular.uppercase(method) === "POST") {
                    config = angular.extend(config, {"data": params});
                }

                params.head_trans_code = params.head_trans_code || url.match(/\d+/);

                $http(config).success(function (data) {
                    if (angular.equals(data, {})) {
                        deferred.reject(data);
                        popupSvc.loading("RET_CODE_NULL,系统错误");
                        console.log("返回对象为空，这里直接返回了错误，但是没有错误信息显示");
                    } else {
                        deferred.resolve(data);
                    }
                }).error(function (data) {
                    deferred.reject(data);
                });
                return deferred.promise;
                /*//Y Begin
                 },
                 checkJesessionId: function (url) {
                 var deferred = $q.defer();
                 encryptSvc.then(function (encrypt) {
                 var userInfo = encrypt.aesSessionTemp(CONSTANT.USER_INFO);
                 var today = new Date().getTime(),
                 unit = userInfo.query(CONSTANT.JSESSIONID_UNIT) * 1000 || 0,
                 time = userInfo.query(CONSTANT.JSESSIONID_TIME) || 0,
                 transCodeReg = new RegExp("^(" + CONFIG.DONT_NEED_CHECK_SESSION_ID.join("|") + ")$");
                 //根据登录接口返回数据得到的过期时间（time）和 当前时间（today）做对比来判断jesessionid是否过期
                 if ((time - today) <= 0 && !transCodeReg.test(url) && !encrypt.aesEnSession(CONSTANT.HEAD_JSESSIONID)) {//如果过期 设置用户为游客 清除session
                 console.error("INFO: CHECK REQUEST JESESSIONID: TIMEOUT !");
                 //var doLoginDeferred = $q.defer();
                 permissionSvc.setUserType("visitor");
                 permissionSvc.registerHttpListener("Lv1");
                 userInfo.clear();
                 resourceSvc.clearSession();
                 deferred.reject();
                 } else { //反则 过期时间重置
                 deferred.resolve();
                 var tempObject = {};
                 tempObject[CONSTANT.JSESSIONID_TIME] = today + unit - 60000;
                 userInfo.save(tempObject);
                 //Y End*/
            }
            /*//Y Begin
             });
             //deferred.resolve();
             return deferred.promise;
             }
             //Y End*/
        };
        //Y Begin
        var counter = 0;
        var errorUrl = "";
        //页面切换重置计数器
        $rootScope.$on("$stateChangeSuccess", function () {
            counter = 0;
        });
        //Y End
        var keeperKey = {
            /**
             * 同步秘钥
             */
            synKey: httpEncryptObj.synKey,

            /**
             * post请求
             * @param url
             * @param params
             * @param isShowLoading
             * @param refresh
             */
            post: function (url, params, isShowLoading, refresh) {
                var deferred = $q.defer();
                if (++counter > 3 && errorUrl == url) { //如果请求回调post请求 只能重发3次 3次失败,停止发送请求
                    popupSvc.loadingHide();
                    return deferred.promise;
                }
                isShowLoading = (typeof isShowLoading == "undefined") ? true : isShowLoading;
                dataCacheSvc.getCacheData(url, params).then(function (cacheData) {
                    if (cacheData && !refresh) {
                        var time = new Date().getTime();
                        var remain_time = (cacheData.timestamp + CONFIG.CACHE_TIME) - time;
                        if (remain_time > 0) {
                            deferred.resolve(cacheData);
                            console.info(url + "使用缓存数据 间隔时间内 更新缓存数据剩余时间：" + remain_time / 1000 + "s");
                            return;
                        }
                    }
                    $q.all([encryptSvc, httpEncryptObj.synKey()]).then(function (args) {
                        var encrypt = args[0];
                        var workKey = args[1];
                        // if (!type) {
                        //     popupSvc.loadingShow();
                        // }
                        // console.log("=====" + url + "同步密钥成功");
                        httpObj.initParams(params).then(function (data) {
                            // console.log("===== " + url + "获取设备信息成功");
                            var postParams = angular.copy(data);

                            // //对手势密码 和 登录密码做MD5加密处理后提交
                            // if (!isMD5) { //阻止重复MD5加密
                            //     if (params && params.login_passwd) {
                            //         params.login_passwd = CryptoJS.MD5(params.login_passwd).toString();
                            //     }
                            //     if (params && params.hand_passwd) {
                            //         params.hand_passwd = CryptoJS.MD5(params.hand_passwd).toString();
                            //     }
                            // }
                            //获取参数签名
                            // console.log(encrypt);
                            var mac = encrypt.hmacMd5(postParams, workKey.hmd5_key);
                            postParams.head_mac = mac;
                            //对参数加密
                            postParams = encrypt.encrypt(postParams, workKey.aes_key);
                            var NOT_SHOW_LOADING_URL = new RegExp("^(" + CONFIG.NOT_SHOW_LOADING_URL.join("|") + ")$");
                            if (!NOT_SHOW_LOADING_URL.test(url) && isShowLoading) {
                                popupSvc.loadingShow();
                            }
                            //使用公共请求参数
                            console.log('前台传输数据', postParams);
                            httpObj.getHttpPromise("POST", url, postParams)
                                .then(function (data) {//, status, headers, config
                                    console.log('后台返回数据', data);
                                    //通过aes对报文解密
                                    data = encrypt.decrypt(data, workKey.aes_key);
                                    // console.log(url," 解密请求返回后的数据", JSON.stringify(data));
                                    // console.log("=====" + url + " 解密请求返回后的数据" + data);
                                    //通过hmacMd5签名密钥获得报文签名,验证签名是否正确(对比返回的签名和自己生成的对比)
                                    var mac1 = encrypt.hmacMd5(data, workKey.hmd5_key);
                                    if (data.ret_code == "SE6001" || data.ret_code == "F993" || data.ret_code == "SE6004") {//主密钥不存在/已过期 /签名错误/解密报文失败
                                        console.log("ERROR: HTTP POST MAINKEY RELOAD !");
                                        errorUrl = url;//Y
                                        resourceSvc.removeLocal(CONSTANT.MAIN_KEY);
                                        resourceSvc.removeLocal(CONSTANT.WORK_KEY);
                                        return keeperKey.post(url, params, isShowLoading, refresh).then(function (value) {
                                            deferred.resolve(value);
                                        })
                                    }
                                    if (data.ret_code == "SE6010") {//工作密钥不存在/已过期
                                        console.log("ERROR: HTTP POST WORKKEY RELOAD !");
                                        errorUrl = url;//Y
                                        resourceSvc.removeLocal(CONSTANT.WORK_KEY);
                                        return keeperKey.post(url, params, isShowLoading, refresh).then(function (value) {
                                            deferred.resolve(value);
                                        })
                                    }
                                    if (data.ret_code == '403003' || data.ret_code == '403010') {//用户未登录
                                        console.log('ERROR: 用户未登录');
                                        encryptSvc.then(function (encrypt) {
                                            var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
                                            userInfo.clear();
                                            resourceSvc.removeLocal(CONSTANT.HEAD_JSESSIONID);
                                            resourceSvc.removeLocal(CONSTANT.ACCOUNT_INFO);
                                            permissionSvc.setUserType("visitor");
                                            permissionSvc.registerHttpListener("Lv1");
                                            $state.go('login');
                                        });

                                    }
                                    if (data.ret_code == '0000') {
                                        if (angular.equals(mac1, data.head_mac || "")) {
                                            deferred.resolve(data);
                                            popupSvc.loadingHide();
                                            dataCacheSvc.setCacheData(url, params, data);
                                        } else {
                                            console.log("ERROR: MAC ERROR !");
                                            popupSvc.loadingHide();
                                            deferred.reject();
                                        }
                                    } else {
                                        popupSvc.loadingHide();
                                        deferred.resolve(data);
                                    }
                                }, function (err) {//, status, headers, config
                                    console.log('ERROR:' + err);
                                    console.log("ERROR: HTTP POST REQUEST ERROR !");
                                    //$state.go("pub404");
                                    popupSvc.loading(CONFIG.HTTP_FAIL_MESSAGE);
                                    dataCacheSvc.getCacheData(url, params).then(function (value) {
                                        if (angular.equals(value, {}) || !value) {
                                            deferred.reject();
                                        }
                                        deferred.resolve(value);
                                    })
                                })
                                .finally(function () {
                                    //popupSvc.loadingHide();
                                    deferred.notify();
                                });
                        }, function (error) {
                            console.log(error);
                            dataCacheSvc.getCacheData(url, params).then(function (value) {
                                if (angular.equals(value, {}) || !value) {
                                    deferred.reject();
                                }
                                deferred.resolve(value);
                            });
                        });
                    }, function (error) {
                        console.log(error);
                        dataCacheSvc.getCacheData(url, params).then(function (value) {
                            if (angular.equals(value, {}) || !value) {
                                deferred.reject();
                            }
                            deferred.resolve(value);
                        })
                    });
                });
                return deferred.promise;
            }
        };
        return keeperKey;
    });
