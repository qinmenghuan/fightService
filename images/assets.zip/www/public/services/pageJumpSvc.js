/**
 * Created by fusy on 2016/9/20.
 *
 * 页面跳转 返回 服务
 *
 * 1.重写$ionicGoBack()方法
 *
 * 2.通过nextPageGoBack设置返回路径
 *
 * 初始化：pageJumpSvc.init();
 *
 * 场景1：A页面 跳转-> B页面 跳转-> C页面 点击返回按钮跳转 返回A页面
 *
 * 在B页面控制下一个页面的返回路径
 * BCtrl.js
 * pageJumpSvc.nextPageGoBack({
 *      nextState: "C", //下一个页面stateName
 *      currentState: "B", //当前页面stateName
 *      goBack: -2 //-2 or 'A' //返回路劲 可以是stateName 也 可以是一个number
 * })
 *
 */

publicModule.provider("pageJumpSvc", function () {
    var goBackBankList = this.goBackBankList = [];
    var index = 0;
    var nextPageGoBackStack = [];

    $get.$inject = ["$rootScope", "$ionicHistory", "$state", "$q"];
    function $get($rootScope, $ionicHistory, $state, $q) {
        return {
            init: function () {
                $rootScope.$ionicGoBack = jump;
                $rootScope.$on("permission-nextState", function (e, state) {
                    //点击返回 防止重复进入登录页
                    // A -> B(需要登录，用户未登录状态，进入登录页面) -> login(登录完成) -> B(点击返回按钮 返回到A)
                    nextPageGoBackStack.push({
                        nextState: state.toState.name,
                        currentState: "login",
                        goBack: -2
                    })
                })
            },
            //页面跳转。 类似于 $state.go() 区别：优先使用历史view
            go: function (stateName, stateParams) {
                var deferred = $q.defer();
                if (!angular.equals(stateParams, {})) {
                    $state.go(stateName, stateParams).then(function(){
                        deferred.resolve();
                    });
                } else {
                    var currentView = $ionicHistory.viewHistory().currentView;
                    index = currentView.index;
                    go(stateName, stateParams, currentView, deferred);
                }
                return deferred.promise;
            },
            //设置下一个页面返回路径（需要$ionicGoBack触发）
            nextPageGoBack: function (goBackObject) {
                nextPageGoBackStack.push(goBackObject);
            }
        };

        //重写$ionicGoBack
        function jump(arg) {
            var backView = $ionicHistory.backView();
            var currentView = $ionicHistory.viewHistory().currentView;
            index = currentView.index;
            var nextPageGoBack = nextPageGoBackStack[nextPageGoBackStack.length - 1];

            if (nextPageGoBack &&
                nextPageGoBack.nextState == currentView.stateName &&
                nextPageGoBack.currentState == backView.stateName) {

                if (typeof nextPageGoBack.goBack === "number") {
                    if (nextPageGoBack.goBack == -2) {
                        $ionicHistory.removeBackView();
                        $ionicHistory.goBack();
                    } else {
                        $ionicHistory.goBack(nextPageGoBack.goBack);
                    }
                } else {
                    go(nextPageGoBack.goBack, null, currentView);
                }
                nextPageGoBackStack.pop();
                return;
            }


            if (!arg && backView) {
                $rootScope.$broadcast("ionic-go-back", backView, currentView, event);
                // goBackFilter(backView);
                return;
            }

            if (!backView) {
                $state.go("home");
            }

            if (arg) {
                $ionicHistory.goBack(arg);
            }

            $ionicHistory.goBack();
        }

        //过滤掉黑名单路由
        function goBackFilter(backView) {
            if (!backView) return;
            if (goBackBankList.join("").indexOf(backView.stateName) == -1) {
                $ionicHistory.goBack(backView.index - index);
            } else {
                goBackFilter($ionicHistory.getViewById(backView.backViewId));
            }
        }

        function go(stateName, stateParams, currentView, deferred) {
            deferred = deferred ? deferred : $q.defer();
            if (!currentView) return;
            if (!currentView.backViewId) {
                $state.go(stateName, stateParams).then(function () {
                    deferred.resolve();
                }, function () {
                    deferred.reject();
                });
                return;
            }
            if (currentView.stateName != stateName) {
                go(stateName, stateParams, $ionicHistory.getViewById(currentView.backViewId), deferred);
            } else {
                $ionicHistory.goBack(currentView.index - index);
                deferred.resolve();
            }
        }
    }

    this.$get = $get;
});