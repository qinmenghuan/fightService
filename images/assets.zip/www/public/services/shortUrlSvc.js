/**
 * Created by fei on 2016/11/16.
 * 通用短链接服务
 * @desc 向新浪短链接api发请求获取对应短链接
 * longToShortUrl:转换短链接方法
 *
 * 传入需要转换的长连接URL，则可转换相应短链接
 */
publicModule.factory('shortUrlSvc', function ($http, $q, CONSTANT) {
  return {
    longToShortUrl: function (longUrl) {
        console.log(longUrl);
      var deferred = $q.defer();
      var shortUrl = CONSTANT.SHORTURL.api + "?source=" + CONSTANT.SHORTURL.appKey + "&url_long=" + encodeURIComponent(longUrl);
      //var shortUrl = CONSTANT.SHORTURL.api + "?source=" + CONSTANT.SHORTURL.appKey + "&url_long=" + longUrl;
      $http.get(shortUrl).then(function (data) {
        deferred.resolve(data);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    }
  }
});
