publicModule.factory('updateSvc', function($ionicPopup,
                                              $ionicLoading,
                                              $window,
                                              $q,
                                              $timeout,
                                              $cordovaFileTransfer,
                                              $cordovaFileOpener2,
                                              httpSvc,
                                              CONFIG,
                                              CONSTANT, popupSvc) {
    // 此处填写上线appstore的地址  
    // var IOSURL = "https://itunes.apple.com/cn/app/wang-zhe-rong-yao-wu-chu-bu/id989673964?mt=8&v0=WWW-GCCN-ITSTOP100-FREEAPPS&l=&ign-mpt=uo%3D4";
    //可以从服务端获取更新APP的路径
    var ANDROIDURL = CONFIG.HTTP_URL+"platform/downloadfile?resource_id=";

    // todo:更换蒲公英地址后，请修改这里
    // var IOSURL = "http://www.pgyer.com/eCJQ";

    // var updatePopup;
    // var errCount = 0;

    // 检测是否有强制更新
    function checkForcedUpdate(noUpdateCallback) {
        noUpdateCallback = noUpdateCallback ? noUpdateCallback : angular.noop;
        var isIos = ionic.Platform.isIOS();
        var isAndroid = ionic.Platform.isAndroid();
        var versionParams = {
            platform: isIos ? 'I' : 'A',
            version_code: "",
            version_num: ""
        };

        // 获取app的版本信息
        //chcp.getVersionInfo(function(err, data) {
        cordova.getAppVersion.getVersionNumber().then(function (version) {
            versionParams.version_code = version;
            versionParams.version_num = version;
            console.log("版本号信息：" ,versionParams);
            // versionParams.version_num = data.buildVersion;

            httpSvc.post('version020101.json', versionParams)
                .then(function(data) {
                    // console.log('更新服务返回字段AAAAAAAAAAAAAAAA', angular.toJson(data))
                    // 经测试，添加判断head_ret_code后莫名的不执行下面代码，故没采用
                    // 后台返回字段，如果有强制更新则有version_list字段
                    console.log("版本更新返回数据：",data);
                    console.log(JSON.stringify(data));
                    //if (data.head_ret_code === CONSTANT.HEAD_RET_CODE_SUCCESS) {
                    if (data.ret_code === "0000") {
                        console.log("请求成功")
                        // var versionInfo = angular.copy(data.version_list);
                        // 0为强制 1为非强制
                        // 只处理强制更新的情况，非强制 -> 热更，继续由插件自行处理
                        if (data.is_forced_update == '0') {
                            console.log("有版本更新");
                            if (isIos) {
                                iosVersionUpdate(data);
                            } else {
                                data.download_address=ANDROIDURL+data.install_pack_resource_id;
                                console.log("安卓版本更新");
                                androidVersionUpdate(data);
                                // 物理返回键回调
                                document.addEventListener("backbutton", function() {
                                    console.log("点击物理返回键，退出app")
                                    navigator.app.exitApp();
                                }, false);
                            }
                            document.addEventListener("resume", function() {
                                if (isIos) {
                                    checkForcedUpdate();
                                }
                            }, false);
                        }
                        // 非强制更新
                        else if(data.is_forced_update == '1'){
                            if (isIos) {
                                iosVersionUpdate(data);
                            } else {
                                console.log("安卓版本更新");
                                data.download_address=ANDROIDURL+data.install_pack_resource_id;
                                androidVersionUpdate(data);
                                // 物理返回键回调
                                document.addEventListener("backbutton", function() {
                                    console.log("点击物理返回键，退出app");
                                    navigator.app.exitApp();
                                }, false);
                            }
                        }
                        else {
                            noUpdateCallback()
                        }
                        // errCount = 0; //重置更新请求错误次数
                    }else if(data.ret_code === "0001"){
                        noUpdateCallback()
                    }
                    else {
                        console.log("版本服务器异常,即将退出app");
                        // 错误码不为DE0000
                        popupSvc.message('版本服务器异常,即将退出app').then(function() {
                            if (isAndroid) {
                                navigator.app.exitApp();
                            }
                        });
                    }

                }, function(err) {
                    // if(errCount++ < 3){
                    checkForcedUpdate(noUpdateCallback);
                    // }
                    // 如果请求错误关闭app
                    // console.log("版本服务器异常,即将退出app");
                    // // 错误码不为DE0000
                    // popupSvc.message('版本服务器异常,即将退出app').then(function(){
                    //     navigator.app.exitApp();
                    // });
                });
        });
    }

    // ios版本更新  强制和非强制
    function iosVersionUpdate(versionInfo) {
        var updatePopup={};
        if(versionInfo.is_forced_update==="0"){
            updatePopup = $ionicPopup.alert({
                title: '更新提示',
                cssClass: 'popup-hasheader',
                template: '新的版本需要更新，请点击确定前往下载地址。',
                okText: '确定'
            });
        }else{
            updatePopup = $ionicPopup.confirm({
                title:'更新提示',
                cssClass:'popup-hasheader',
                template:'新的版本需要更新，请点击确定前往下载地址。',
                cancelText:'下次提醒',
                okText:'马上更新'
            });
        }

        // 如果确定，则打开浏览器跳转蒲公英或appstore地址
        updatePopup.then(function(res) {
            if (res) {
                cordova.InAppBrowser.open(versionInfo.download_url, '_system', 'location=yes');
                updatePopup = null;
            }
        });
    }

    // android版本更新
    function androidVersionUpdate(versionInfo) {
        var updatePopup={};
        // 强制更新
        if(versionInfo.is_forced_update==="0"){
            updatePopup = $ionicPopup.alert({
                title: '更新提示',
                template: '检测到新版本,请点击确定进行更新',
                cssClass: 'popup-hasheader',
                okText: '确定'
            });
        }else{
            updatePopup = $ionicPopup.confirm({
                title:'更新提示',
                cssClass:'popup-hasheader',
                template:'新的版本需要更新，请点击确定前往下载地址。',
                cancelText:'下次提醒',
                okText:'马上更新'
            });
        }

        // 如果确定，则打开浏览器跳转蒲公英或appstore地址
        updatePopup.then(function(res) {
            if (res) {
                // cordova.InAppBrowser.open(versionInfo.download_address, '_system', 'location=yes');
                // var apkUrl = CONFIG.IMG_SERVER_URL + versionInfo.download_address;
               // var apkUrl="http://10.5.1.149/";
               // var apkUrl = "http://10.5.1.149:80/android-release-unsigned.apk";
                beginUpdate(versionInfo.download_address);
            }
        });
    }

    // 开始更新
    function beginUpdate(apkurl) {
        $ionicLoading.show({
            template: "已经下载：0%"
        });
        //alert(apkurl);
        window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function(fileEntry) {
            fileEntry.getDirectory("huiLife", { create: true, exclusive: false }, function(fileEntry) {
                $cordovaFileTransfer.download(apkurl, fileEntry.toInternalURL() + "huiLife.apk")
                    .then(function(entry) {

                        $ionicLoading.show({
                            template: "下载完毕，准备打开程序"
                        });

                        $timeout(function() {
                            // 打开下载下来的APP
                            console.log(entry.toInternalURL());
                            $cordovaFileOpener2.open(entry.toInternalURL(), 'application/vnd.android.package-archive')
                                .then(function(suc) {
                                    console.log("下载完成 打开app");
                                    $ionicLoading.hide();
                                    navigator.app.exitApp();
                                }, function(err) {
                                    $ionicLoading.hide();
                                    $ionicPopup.alert({
                                        title: '更新提示',
                                        template: '打开安装包失败,请在文件夹打开安装文件。点击确认退出app',
                                        cssClass: 'popup-hasheader',
                                        okText: '确定'
                                    }).then(function(){
                                        navigator.app.exitApp();
                                    });
                                });
                        }, 500)

                    }, function(err) {
                        console.log("下载失败" + JSON.stringify(err));
                        var confirmPromise = popupSvc.confirm({
                            template: "下载失败，点击确认重新下载，点击取消退出桂银直销"
                        });
                        confirmPromise.then(function (result) {
                            if (!result) {
                                beginUpdate(apkurl);
                            } else {
                                navigator.app.exitApp();
                            }
                        })
                    }, function(progressEvent) {
                        $timeout(function() {
                            var downloadProgress = (progressEvent.loaded / progressEvent.total) * 100;
                            $ionicLoading.show({
                                template: "已经下载：" + Math.floor(downloadProgress) + "%"
                            });
                        });
                    });
            }, function(err) {
                popupSvc.message('目录创建失败').then(function() {
                    navigator.app.exitApp();
                });
            });
        }, function() {
            console.log("版本服务器异常,即将退出app");
            // 错误码不为DE0000
            popupSvc.message('about to resolve this files errors' + error.code).then(function() {
                navigator.app.exitApp();
            });
        });
    }

    // function isUpdateInstall() {
    //     chcp.isUpdateAvailableForInstallation(function(error, data) {
    //         // data打印信息为chcp.json内配置信息
    //         if (error) {
    //             console.log('暂无可安装更新,检测更新并下载');
    //             // 监听更新失败,此处换为后台控制是否强更，故不需要这里
    //             // document.addEventListener('chcp_updateLoadFailed', onUpdateLoadError, false);
    //             chcp.fetchUpdate(fetchUpdateCallback);
    //             return;
    //         }
    //         // 有可用更新时
    //         chcp.installUpdate(installationCallback)
    //     });
    // }

    // 检测更新回调
    var fetchUpdateCallback = function(error, data) {
        // 更新错误（详细错误信息看error.code、error.description）
        if (error) {
            console.log('更新失败，错误代码: ' + error.code);
            console.log('错误描述: ' + error.description);
            return;
        }
        // todo:有新版本弹框,现在放到app.js检测更新
        console.log('运行此处，表示已经下载好版本了');
    }

    // 安装更新回调
    // function installationCallback(error) {
    //     if (error) {
    //         console.log('安装更新失败: ' + error.code);
    //         console.log('错误描述: ' + error.description);
    //         $ionicPopup.alert({
    //             title: '更新信息',
    //             cssClass: 'popup-hasheader',
    //             template: '更新错误代码：' + error.code + '<br>错误描述：' + error.description,
    //             okText: '确定'
    //         });
    //     } else {
    //         console.log('更新完成!');
    //         //版本更新 成功后 开启引导页 "1":为开启 "0": 为关闭
    //         // resourceSvc.setLocal("bootPage", "0");
    //     }
    // }

    // debug测试用
    // function debugUpdate() {
    //     var versionParams = {
    //         platform: 'A',
    //         // platform: ionic.Platform.isIOS() ? 'I' : 'A',
    //         version_code: "1.0.0",
    //         version_num: "1.0.0"
    //     }
    //
    //     httpSvc.post('sys020201.json', versionParams)
    //         .then(function (data) {
    //             console.info('Aaaaa', data);
    //             // var apkUrl = PACK_CONFIG.IMG_SERVER_URL + data.version_list.download_address;
    //             // beginUpdate(apkUrl);
    //         }, function (err) {
    //             $ionicLoading.show({
    //                 template: "apk路径获取失败"
    //             });
    //         });
    // };
    // debugUpdate();

    return {
        // 检查更新
        checkForUpdate: function(noUpdateCallback) {
            if (!window.cordova) return;
            return checkForcedUpdate(noUpdateCallback);
        },
        // 检测安装包
        // checkInstallPackge: function() {
        //     return isUpdateInstall();
        // },
        // 获取版本信息
        // getUpdateVersion: function() {
        //     if (!window.chcp) return;
        //     var defer = $q.defer();
        //     chcp.getVersionInfo(function(err, data) {
        //         // console.log('Current web version: ' + data.currentWebVersion);
        //         // console.log('Previous web version: ' + data.previousWebVersion);
        //         // console.log('Loaded and ready for installation web version: ' + data.readyToInstallWebVersion);
        //         // console.log('Application version name: ' + data.appVersion);
        //         // console.log('Application build version: ' + data.buildVersion);
        //         // console.log('Application is err: ' + err);
        //         defer.resolve(data);
        //         defer.reject(err);
        //     });
        //     return defer.promise;
        // }
    };
})
