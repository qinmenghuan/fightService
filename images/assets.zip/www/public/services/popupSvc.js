/**
 * 弹框服务
 * author duying
 *
 * Created by fusy on 2016/9/6.
 *
 */
publicModule.factory('popupSvc', ['$ionicPopup', '$ionicLoading', 'CONFIG', '$ionicModal', '$ionicActionSheet', "$ionicBackdrop", "$ionicBody", "$q", "$ionicTemplateLoader", "$rootScope", "$compile", "$timeout", "$animate",
    function ($ionicPopup, $ionicLoading, CONFIG, $ionicModal, $ionicActionSheet, $ionicBackdrop, $ionicBody, $q, $ionicTemplateLoader, $rootScope, $compile, $timeout, $animate) {
        var closeByDocumentCallback;
        var currentPopup, closeShowPop;
        var jqLite = angular.element;
        var TPL = "<section class='custom-popup popup-container'><div class='popup'></div></section>";
        var ACTION_TPL = "<div><div class='action-sheet-wrapper'></div></div>";

        //加载模版
        //$ionicTemplateLoader.load(options.templateUrl)
        function loadTpl(options, scope, element, warpClassName) {
            var deferred = $q.defer();
            return $q.when(
                options.templateUrl ?
                    $ionicTemplateLoader.load(options.templateUrl) :
                    (options.template || options.content || '')
            ).then(function (template) {
                var popupBody = jqLite(element[0].querySelector(warpClassName || '.popup'));
                if (template) {
                    popupBody.html(template);
                    $compile(popupBody.contents())(scope);
                }
                deferred.resolve();
            }, function () {
                deferred.reject();
            });
            return deferred.promise;
        }

        //创建一个新的弹框
        function createPopup(className) {
            var self = {};
            self.element = jqLite(TPL);
            self.backdropEL = jqLite("<div id='custom-backdrop' class='custom-backdrop'></div>");
            self.element.addClass(className);
            self.responseDeferred = $q.defer();

            //获取body对象 并将解析后的TPL 添加到body对象
            $ionicBody.get().appendChild(self.backdropEL[0]);
            console.log(self.element[0]);
            $ionicBody.get().appendChild(self.element[0]);
            //加载模版
            //loadTpl(options, self.scope, self.element);

            self.show = function () {
                if (self.isShown || self.removed) return;

                self.isShown = true;
                ionic.requestAnimationFrame(function () {
                    //if hidden while waiting for raf, don't show
                    if (!self.isShown) return;

                    self.element.removeClass('popup-hidden');
                    self.element.addClass('popup-showing active');
                });
            };

            self.hide = function (callback) {
                callback = callback || angular.noop();
                if (!self.isShown) return callback();

                self.isShown = false;
                self.element.removeClass('active');
                self.element.addClass('popup-hidden');
                $timeout(function () {
                    self.element.removeClass("popup-showing");
                    callback();
                }, 250, false);

            };

            self.remove = function () {
                if (self.removed) return;
                self.hide(function () {
                    self.element.remove();
                });
                self.removed = true;
            };

            return self;
        }

        var _backdrop = {
            hide: function () {
                // $ionicBody.removeClass('popup-open');
                var el = angular.element(document.getElementById("custom-backdrop"));
                el.css({'opacity': '0'});
                $timeout(function () {
                    el.remove();
                }, 400, false);
            },
            show: function () {
                // $ionicBody.addClass('popup-open');
                var el = angular.element(document.getElementById("custom-backdrop"));
                el.css({visibility: "visible", opacity: "1"});
            }
        };

        document.addEventListener("touchend", function (e) {
            var elem = e.srcElement || e.target;
            var closeable = angular.element(elem).hasClass("popup-container");
            if (closeShowPop) {
                $ionicLoading.hide();
            }
            if (closeable && angular.isFunction(closeByDocumentCallback)) {
                closeByDocumentCallback(e);
            }
        });
        $rootScope.$on("$stateChangeStart", function () {
            if (currentPopup) {
                currentPopup.close()
            }
        });

        return {
            popup: function (className) {
                var popup = createPopup(className);
                var isShown = false;
                var self = currentPopup = {
                    show: function (options) {
                        closeByDocumentCallback = null;
                        if (self.scope) { //销毁上一个tpl scope;
                            self.scope.$destroy && self.scope.$destroy();
                        }
                        var scope = self.scope = (options.scope || $rootScope).$new();
                        //popup = popup ? popup : createPopup();
                        if (!!options.closeByDocument) {
                            closeByDocumentCallback = function () {
                                self.close();
                            }
                        }
                        loadTpl(options, scope, popup.element).then(function () {
                            if (!isShown) {
                                _backdrop.show();
                                popup.show();
                            }
                            isShown = true;
                        })
                    },
                    hide: function () {
                        popup.hide();
                        _backdrop.hide();
                    },
                    close: function () {
                        if (self.scope) {
                            self.scope.$destroy && self.scope.$destroy();
                        }
                        popup.remove();
                        _backdrop.hide();
                    }
                };

                return self;
            },
            loading: function (message, duration) {
                closeByDocumentCallback = null;
                var _conf = {};
                if (message) {
                    _conf = {
                        template: message,
                        duration: duration ? null : CONFIG.ALERT_DURATION_TIME,
                    };
                    closeShowPop = false;
                } else {
                    _conf = {
                        template: "<ion-spinner icon='spiral'></ion-spinner>",
                    };
                    closeShowPop = true;
                }
                $ionicLoading.show(_conf);
                return closeShowPop;
            },
            alert: function (options) {
                closeByDocumentCallback = null;
                var _config = angular.extend({
                    cssClass: "popup-alert alert-has-btn",
                    title: null, // String. 弹窗的标题。
                    subTitle: null, // String (可选)。弹窗的子标题。
                    template: '', // String (可选)。放在弹窗body内的html模板。
                    okType: "button-secondary",
                    okText: '确定',
                    templateUrl: '', // String (可选)。 放在弹窗body内的html模板的URL。
                    closeByDocument: false
                }, options);
                var alert = currentPopup = $ionicPopup.alert(_config);
                if (_config.closeByDocument || false) {
                    closeByDocumentCallback = function (e) {
                        alert.close();
                    }
                }
                return alert
            },
            error: function (error) {
                return this.alert({
                    cssClass: "popup-alert alert-has-btn popup-alert-error",
                    template: '<div><span class="unbind-faild-icon"> <i class="iconfont icon-cuowu"></i></span><p class="hint">' + error + '</p></div>'
                })
            },
            message: function (message, closeByDocument) {
                var deferred = $q.defer();
                var alert = this.alert({
                    cssClass: "popup-alert btn-none",
                    template: message,
                    closeByDocument: closeByDocument
                });
                $timeout(function () {
                    alert.close();
                    deferred.resolve();
                }, CONFIG.ALERT_DURATION_TIME);
                return deferred.promise;
            },
            confirm: function (options) {
                closeByDocumentCallback = null;
                var _config = angular.extend({
                    cssClass: "popup-confirm",
                    title: '', // String. 弹窗标题。
                    subTitle: '', // String (可选)。弹窗的副标题。
                    template: '', // String (可选)。放在弹窗body内的html模板。
                    templateUrl: '', // String (可选)。放在弹窗body内的一个html模板的URL。
                    cancelText: '确定', // String (默认: 'Cancel')。一个取消按钮的文字。
                    cancelType: 'confirm-btn', // String (默认: 'button-default')。取消按钮的类型。
                    okText: '取消', // String (默认: 'OK')。OK按钮的文字。
                    okType: 'cancel-btn', // String (默认: 'button-positive')。OK按钮的类型。
                    closeByDocumentCallback: false
                }, options);
                var confirm = currentPopup = $ionicPopup.confirm(_config);
                if (_config.closeByDocument || false) {
                    closeByDocumentCallback = function (e) {
                        confirm.close();
                    }
                }
                return confirm;
            },
            modal: function (options) {
                var modal;
                if (!options.scope) {
                    return console.error("please set scope property by modal for popupSvc service!");
                }
                if (options.template) {
                    return $ionicModal.fromTemplate(options.template, options);
                }
                modal = $ionicModal.fromTemplateUrl(options.template, options);
                return modal.then(function (modal) {
                    options.scope.modal = modal;
                    return modal;
                })
            },
            actionSheet: function (options) {
                var _config = angular.extend({
                    cssClass: "gl-action-sheet",
                    cancelText: '取消',
                    buttons: [],
                    buttonClicked: function (index) {
                        console.log(index);
                        return true;
                    },
                    cancel: function () {
                    }
                }, options);
                return $ionicActionSheet.show(_config)
            },
            action: function (options) {
                var self = {};
                self.element = angular.element(ACTION_TPL);
                self.element.attr("isAction", true);
                self.element.attr("class", options.cssClass);
                self.deferred = $q.defer();
                var content = jqLite(self.element[0].querySelector('.action-sheet-wrapper'));
                self.scope = (options.scope || $rootScope).$new();
                loadTpl(options, self.scope, self.element, ".action-sheet-wrapper").then(function () {
                    self.deferred.resolve();
                });
                self.element.bind("click", function (e) {
                    var elem = e.srcElement || e.target;
                    if (jqLite(elem).attr("isAction") && options.closeByDocument) {
                        remove();
                    }
                });

                //显示上滑框
                show();

                function show(done) {
                    $ionicBody.append(self.element)
                        .addClass('action-sheet-open');

                    $animate.addClass(self.element, 'active action-sheet-backdrop').then(function () {
                        // if (self.scope.removed) return;
                        (done || angular.noop)();
                    });
                    $timeout(function () {
                        // if (self.scope.removed) return;
                        content.addClass('action-sheet-up');
                    }, 20, false);
                }

                function remove(done) {
                    content.removeClass('action-sheet-up');
                    $timeout(function () {
                        $ionicBody.removeClass('action-sheet-open');
                    }, 400);

                    $animate.removeClass(self.element, 'active').then(function () {
                        self.scope.$destroy();
                        self.element.remove();
                        (done || angular.noop)();
                    })
                }

                self.close = remove;
                currentPopup = self;

                return self;
            },
            loadingShow: function () {
                this.loading();
            },
            loadingHide: function () {
                $ionicLoading.hide();
            },
            close: function () {
            }
        };
    }]);

