/**
 * 分享服务
 * @author wf 2016-1-11
 * @desc
 */

publicModule.factory('shareApp',
    function (resourceSvc, CONSTANT, popupSvc, shareTips, $q, shortUrlSvc) {
        //检测是否有安装App -QQ
        function qqCheckClientInstalled() {
            var deferred = $q.defer();
            YCQQ.checkClientInstalled(function () {
                deferred.resolve();
            }, function () {
                // 如果安装的QQ客户端版本太低，不支持SSO登录也会返回没有安装客户端的错误
                deferred.reject();
                popupSvc.alert({
                    title: "检测到您设备未安装QQ或QQ版本太低,请安装或升级后重试",
                    cssClass: "popup-container one-btn",
                    buttons: [{
                        text: '<b>确定</b>',
                    }]
                });
            });
            return deferred.promise;
        }

        //检测是否有安装App-微信
        function WechatCheckClientInstalled() {
            var deferred = $q.defer();
            Wechat.isInstalled(function (installed) {
                if (installed) {
                    deferred.resolve();
                } else {
                    // 如果安装的QQ客户端版本太低，不支持SSO登录也会返回没有安装客户端的错误
                    deferred.reject();
                    popupSvc.alert({
                        title: "检测到您设备未安装微信或微信版本太低,请安装或升级后重试",
                        cssClass: "popup-container one-btn",
                        buttons: [{
                            text: '<b>确定</b>',
                        }]
                    });
                }
            });
            return deferred.promise;
        }

        //检测是否有安装App-微博
        function YCWeiboCheckClientInstalled() {
            var deferred = $q.defer();
            YCWeibo.checkClientInstalled(function () {
                console.log('client is installed');
                deferred.resolve();
            }, function () {
                // 如果安装的QQ客户端版本太低，不支持SSO登录也会返回没有安装客户端的错误
                deferred.reject();
                popupSvc.alert({
                    title: "检测到您设备未安装微博或微博版本太低,请安装或升级后重试",
                    cssClass: "popup-container one-btn",
                    buttons: [{
                        text: '<b>确定</b>',
                    }]
                });
            });
            return deferred.promise;
        }


        return {
            //生成二维码
            // qrcode: function (url,id) {
            //     var deferred = $q.defer();
            //     shortUrlSvc.longToShortUrl(url)
            //         .then(function (sucData) {
            //             var outUrl = sucData.data.urls[0].url_short;
            //             console.log('生成短链接Url：', outUrl);
            //             //生成二维码
            //             $(id).html("");
            //             $(id).qrcode({
            //                 render: "canvas",    //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
            //                 text: outUrl,    //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
            //                 width: "240",               //二维码的宽度
            //                 height: "240",              //二维码的高度
            //                 background: "#ffffff",       //二维码的后景色
            //                 foreground: "#000000",        //二维码的前景色
            //                 src: 'images/logo.png'         //二维码中间的图片
            //             });
            //             deferred.resolve(outUrl);
            //         }, function (errData) {
            //             console.log('生成短链接失败：', errData.data.error)
            //             deferred.reject("ERROR: 生成短链接失败 !");
            //             // console.log(errData.data.error_code)
            //         });
            //     return deferred.promise;
            // },
            // 长链接生成二维码
            qrcode: function (url,id) {
                var deferred = $q.defer();
                // shortUrlSvc.longToShortUrl(url)
                //     .then(function (sucData) {
                        // var outUrl = sucData.data.urls[0].url_short;
                        // console.log('生成短链接Url：', outUrl);
                        //生成二维码
                        $(id).html("");
                        $(id).qrcode({
                            render: "canvas",    //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
                            text: url,    //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
                            width: "240",               //二维码的宽度
                            height: "240",              //二维码的高度
                            background: "#ffffff",       //二维码的后景色
                            foreground: "#000000",        //二维码的前景色
                            src: 'images/logo.png'         //二维码中间的图片
                        });
                        deferred.resolve(url);
                    // }, function (errData) {
                    //     console.log('生成短链接失败：', errData.data.error)
                    //     deferred.reject("ERROR: 生成短链接失败 !");
                    //     // console.log(errData.data.error_code)
                    // });
                return deferred.promise;
            },
            //qq分享
            share2QQ: function (outUrl, title, des, img, name) {
                qqCheckClientInstalled().then(function () {
                    YCQQ.shareToQQ(function () {
                    }, function (failReason) {
                    }, {
                        url: outUrl, //分享链接地址
                        title: title || shareTips.SHARE_TITLE, //分享标题
                        description: des || shareTips.INVITE_SHARRE_DESCRIPTION, //分享描述
                        imageUrl: img || shareTips.IMG, //图片
                        appName: name || shareTips.APP_NAME //分享app名字
                    });
                })
            },
            //QQ空间分享
            share2QZone: function (outUrl, title, des, img, name) {
                qqCheckClientInstalled().then(function () {
                    var args = {};
                    args.url = outUrl;
                    args.title = title || shareTips.SHARE_TITLE;
                    args.description = des || shareTips.INVITE_SHARRE_DESCRIPTION;
                    /*var imgs = ['https://www.baidu.com/img/bdlogo.png',
                     'https://www.baidu.com/img/bdlogo.png',
                     'https://www.baidu.com/img/bdlogo.png'];*/
                    args.imageUrl = [img || shareTips.IMG];
                    YCQQ.shareToQzone(function () {
                    }, function (failReason) {
                    }, args);
                })
            },
            //微信分享
            share2Wechat: function (scene, outUrl, title, des, img, name) {
                WechatCheckClientInstalled().then(function () {
                    var wechatConfig = {
                        message: {
                            title: title || shareTips.SHARE_TITLE, //分享标题
                            description: des || shareTips.INVITE_SHARRE_DESCRIPTION, //分享描述
                            mediaTagName: "Media Tag Name(optional)",
                            thumb: img || shareTips.IMG, //分享logo
                            media: {
                                type: 7,   //1：app 2：EMOTION 3:FILE 4:IMAGE 5:MUSIC 6:VIDEO 7:WEBPAGE
                                webpageUrl: outUrl    // 分享链接
                            }
                        },
                        scene: scene   // 0: 聊天界面 1 朋友圈 2 收藏
                    };
                    Wechat.share(wechatConfig, function () {
                    }, function (reason) {
                    });
                });
            },
            //微博分享
            share2Weibo: function (outUrl, title, des, img, name) {
                YCWeiboCheckClientInstalled().then(function () {
                    YCWeibo.shareToWeibo(function () {
                    }, function (failReason) {
                        // alert(failReason);
                    }, {
                        url: outUrl, //分享链接地址
                        title: title || shareTips.SHARE_TITLE, //分享标题
                        description: des || shareTips.INVITE_SHARRE_DESCRIPTION, //分享描述
                        imageUrl: img || shareTips.IMG, //图片
                        defaultText: name || shareTips.APP_NAME //分享app名字
                    });
                })
            }
        };
    }
);


