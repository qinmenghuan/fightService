/**
 * Created by fusy on 2016/3/17.
 * 用户权限控制
 */
publicModule.provider("permissionSvc", function () {

    var isObject = angular.isObject,
        isUndefined = angular.isUndefined,
        isFunction = angular.isFunction,
        equals = angular.equals,
        isArray = angular.isArray;
    var PERMISSIONS = {};
    var _postDeferred = null;
    var doLoginDeferred = null;
    this.setPermission = function (permissionName, options) {
        if (!isObject(options)) {
            console.log("ERROR: permission options is not object");
        }
        PERMISSIONS[permissionName] = options;
        return this;
    };
    $get.$inject = ["$state", "commonEvent", "$q", "pageJumpSvc", "$rootScope"];
    function $get($state, commonEvent, $q, pageJumpSvc, $rootScope) {

        var privateMethod = {
            step: 1,
            //判断state是否有相关权限配置
            isDeploy: function (state) {
                return (!isUndefined(state.permission) && isObject(PERMISSIONS[state.permission]));
            },
            //获取state对应的权限信息
            getPermissionOpt: function (permissionName) {
                return PERMISSIONS[permissionName];
            },
            //当用用户没有权限需要做的事情
            notPermissionTodo: function (event, toState, toParams, fromState, fromParams) {
                var permissionOpt = privateMethod.getPermissionOpt(toState.permission),
                    userType = publicMethod.getUserType();
                publicMethod.getNotPermissionState = $state.go(permissionOpt.otherwise[userType]).then(function () {
                    return {toState: toState, toParams: toParams, fromState: fromState, fromParams: fromParams}
                });
            },
            //保存没有权限时的 toState 和 fromState
            saveNotPermissionState: function (toState, toParams, fromState, fromParams) {
                privateMethod.notPermissionState = {
                    toState: toState,
                    toParams: toParams,
                    fromState: fromState,
                    fromParams: fromParams
                }
            },
            clearNotPermissionState: function () {
                privateMethod.notPermissionState = {};
            },
            getNotPermissionState: function () {
                return privateMethod.notPermissionState;
            },
            setDoLoginDeferred: function (deferred) {
                doLoginDeferred = deferred;
            },
            getDoLoginDeferred: function () {
                return doLoginDeferred;
            }
        };
        /** ************************************************************************************************** **/
        var publicMethod = {
            /**
             * 获取没有权限时的toState fromState
             */
            getNotPermissionState: $q.defer().promise,
            event: {
                default: true,
                preventDefault: function () {
                    publicMethod.event.default = false;
                },
                reset: function () {
                    publicMethod.event.default = true;
                }
            },
            //清空 没有权限时的 toState 和 fromState
            clearNotPermissionState: privateMethod.clearNotPermissionState,
            //保存 没有权限时的 toState 和 fromState
            saveNotPermissionState: privateMethod.saveNotPermissionState,
            //获取用户类型
            getUserType: function (defaultValue) {
                return PERMISSIONS.userType ? PERMISSIONS.userType : defaultValue;
            },
            //设置用户类型    visitor：游客类型    login： 已登录类型    ident：已绑卡认证类型
            setUserType: function (userType) {
                PERMISSIONS.userType = userType;
            },
            //没有权限时 自定义处理
            on: function (eventName, callBack) {
                switch (eventName) {
                    case "not-permission":
                        privateMethod.notPermissionCallback = callBack;
                        break;
                    default:
                        console.log("INFO: no " + eventName + " event !");
                }
            },
            //返回上一个页面 @returns {boolean} false：有权限配置 且跳转成功。
            returnState: function () {
                if (privateMethod.notPermissionState && !equals(privateMethod.notPermissionState, {})) {
                    if (this.triggerType() === "http" && isObject(privateMethod.getDoLoginDeferred())) {
                        var doLoginDeferred = privateMethod.getDoLoginDeferred();
                        var postArgs = angular.copy(publicMethod.queryPostArgs());
                        //deferred, url, params, refresh, hasLoading, isMD5
                        doLoginDeferred.resolve(postArgs);
                        privateMethod.setDoLoginDeferred(null);
                        publicMethod.savePostArgs(null);
                        return false;
                    } else if (privateMethod.notPermissionState.fromState) {
                        var _state = privateMethod.notPermissionState;
                        pageJumpSvc.go(_state.fromState.name, _state.fromParams).then(function(){
                            privateMethod.clearNotPermissionState();
                        });
                        return false;
                    }
                }
                return true;
            },
            //跳转下一个页面 @returns {boolean} false：有权限配置 且跳转成功。
            nextState: function () {
                if (privateMethod.notPermissionState && !equals(privateMethod.notPermissionState, {})) {
                    $rootScope.$broadcast("permission-nextState", privateMethod.notPermissionState);
                    if (this.triggerType() === "http" && isObject(privateMethod.getDoLoginDeferred())) {
                        var doLoginDeferred = privateMethod.getDoLoginDeferred();
                        var postArgs = angular.copy(publicMethod.queryPostArgs());
                        //deferred, url, params, refresh, hasLoading, isMD5
                        doLoginDeferred.resolve(postArgs);
                        privateMethod.setDoLoginDeferred(null);
                        publicMethod.savePostArgs(null);
                        return false;
                    } else if (privateMethod.notPermissionState.toState) {
                        var _state = privateMethod.notPermissionState;
                        pageJumpSvc.go(_state.toState.name, _state.toParams).then(function () {
                            if (_state.deferred) {
                                _state.deferred.resolve();
                            }
                            privateMethod.clearNotPermissionState();
                        });
                        return false;
                    }
                }
                return true;

            },
            autoGoState: function () {
                publicMethod.httpCheck = false;
                if (privateMethod.step > 0) {
                    privateMethod.step = 1;
                    return publicMethod.nextState();
                } else {
                    privateMethod.step = 1;
                    return publicMethod.returnState();
                }
            },
            triggerType: function (type) {
                if (type) {
                    privateMethod.triggerType = type
                }
                return privateMethod.triggerType;
            },
            savePostArgs: function (postArgs) {
                _postDeferred = postArgs;
            },
            queryPostArgs: function () {
                return _postDeferred;
            },
            //页面切换时 处理方法
            registerPageListener: function (event, toState, toParams, fromState, fromParams) {
                publicMethod.event.reset();
                //监听页面切换事件
                if (!privateMethod.isDeploy(toState)) return;
                //获取当前state的权限
                var permissionOpt = privateMethod.getPermissionOpt(toState.permission),
                    userType = publicMethod.getUserType();
                if (!permissionOpt.userPermission[userType]) { //用户没有这个state的访问权限
                    publicMethod.triggerType("page");
                    privateMethod.step = 1;
                    privateMethod.saveNotPermissionState(toState, toParams, fromState, fromParams);
                    if (isFunction(privateMethod.notPermissionCallback)) {
                        privateMethod.notPermissionCallback(publicMethod.event, permissionOpt, toState, toParams, fromState, fromParams);
                    }
                    if (publicMethod.event.default) {
                        privateMethod.notPermissionTodo(event, toState, toParams, fromState, fromParams);
                    }
                    event.preventDefault();
                }
            },
            //点击按钮 处理方法
            registerDirectiveListener: function (permissionName, el, attr, e) {
                var permissionOpt = privateMethod.getPermissionOpt(permissionName),
                    userType = publicMethod.getUserType();
                if (!permissionOpt.userPermission[userType]) {
                    privateMethod.step = -1;
                    publicMethod.triggerType("button");
                    if (isFunction(privateMethod.notPermissionCallback)) {
                        privateMethod.notPermissionCallback(publicMethod.event, permissionOpt);
                    }
                    if (publicMethod.event.default) {
                        publicMethod.getNotPermissionState = $state.go(permissionOpt.otherwise[userType]).then(function () {
                            var stateChangeHistory = commonEvent.getStateHistory();
                            var state = stateChangeHistory[stateChangeHistory.length - 1];
                            privateMethod.saveNotPermissionState(state.toState, state.toParams, state.fromState, state.fromParams);
                            return {
                                toState: state.toState,
                                toParams: state.toParams,
                                fromState: state.fromState,
                                fromParams: state.fromParams
                            };
                        });
                    }
                }
            },
            //发送请求 处理方法
            registerHttpListener: function (permissionName, doLoginDeferred) {
                var permissionOpt = privateMethod.getPermissionOpt(permissionName),
                    userType = publicMethod.getUserType();
                publicMethod.triggerType("http");
                privateMethod.setDoLoginDeferred(doLoginDeferred);
                publicMethod.httpCheck = true;
                privateMethod.step = -1;
                if (isFunction(privateMethod.notPermissionCallback)) {
                    privateMethod.notPermissionCallback(publicMethod.event, permissionOpt);
                }
                if (publicMethod.event.default) {
                    publicMethod.getNotPermissionState = $state.go(permissionOpt.otherwise[userType]).then(function () {
                        var stateChangeHistory = commonEvent.getStateHistory();
                        var state = stateChangeHistory[stateChangeHistory.length - 1];
                        privateMethod.saveNotPermissionState(state.toState, state.toParams, state.fromState, state.fromParams);
                        return {
                            toState: state.toState,
                            toParams: state.toParams,
                            fromState: state.fromState,
                            fromParams: state.fromParams
                        };
                    });
                }
            }
        };
        return publicMethod;
    }

    this.$get = $get;
});
publicModule.directive("permission", ["permissionSvc", function (permissionSvc) {
    return {
        restrict: "A",
        scope: {
            permission: "@"
        },
        link: function (scope, el, attr) {
            var permissionName = scope.saveState;
            el.bind("click", function (e) {
                permissionSvc.registerDirectiveListener(permissionName, el, attr, e);
            })
        }
    }
}]);
//初始化权限控制，将config 的权限配置信息添加到权限控制服务
publicModule.config(["CONFIG", "permissionSvcProvider", function (CONFIG, permissionSvcProvider) {
    CONFIG.PERMISSIONS.forEach(function (value) {
        permissionSvcProvider.setPermission(value.PERMISSION_NAME, value.PERMISSION_CONFIG);
    });
}]);

