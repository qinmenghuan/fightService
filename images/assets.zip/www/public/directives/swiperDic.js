/**
 * Created by Luo Xianli on 2016/12/13.
 */
publicModule.directive('swiperDic', ['$timeout', function ($timeout) {
    return {
        restrict: 'A',
        scope: true,
        transclude: true,
        template: '<div class="swiper-wrapper" ng-transclude></div>',
        link: function (scope, element, attrs) {
            var _params = {
                    pagination: '.swiper-pagination',
                    autoplay: 5000,//5s自动滑动
                },
                swiper;

            angular.forEach(['autoplay', 'slidesPerView', 'spaceBetween'], function (key) {
                if (angular.isDefined(attrs[key])) {
                    if (/^\d+$/.test(attrs[key])) {
                        _params[key] = parseInt(attrs[key]);
                    } else {
                        _params[key] = attrs[key];
                    }
                }
            });

            angular.forEach(['freeMode', 'centeredSlides', 'loop'], function (key) {
                if (angular.isDefined(attrs[key])) {
                    _params[key] = /^(true|1)$/.test(attrs[key]);
                }
            });

            swiper = new Swiper(element, _params);

            if (angular.isDefined(attrs.listData)) {
                scope.$parent.$watch(attrs.listData, function () {
                    $timeout(function () {
                        swiper.update();
                    }, 100);
                });
            }

            if (angular.isDefined(attrs.initialSlide)) {
                scope.$parent.$watch(attrs.initialSlide, function (newValue) {
                    $timeout(function () {
                        swiper.slideTo(newValue, 0, false);
                    }, 100);
                });
            }
        }
    };
}]);
