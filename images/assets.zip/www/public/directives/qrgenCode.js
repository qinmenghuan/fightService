/**
 * Created by kayak on 2016/10/18.
 */
publicModule.directive("wminfo", function () {
    return {
        restrict: 'AE',
        replace: true,
        scope: {
            infostr: '@',
            size: '@',
            color: '@'
        },
        template: "<div id='qrcanvas'></div>",
        link: function (scope, element, attrs) {
            (function ($) {
                var q = $('#qrcanvas');
                var draw = function () {
                    var colorIn = '#191970';
                    var colorOut = '#cd5c5c';
                    var colorFore = scope.color;
                    var options = {
                        cellSize: Number(scope.size),
                        foreground: [
                            // 背景颜色
                            {style: colorFore},
                            // outer squares of the positioner
                            {row: 0, rows: 7, col: 0, cols: 7, style: colorOut},
                            {row: -7, rows: 7, col: 0, cols: 7, style: colorOut},
                            {row: 0, rows: 7, col: -7, cols: 7, style: colorOut},
                            // inner squares of the positioner
                            {row: 2, rows: 3, col: 2, cols: 3, style: colorIn},
                            {row: -5, rows: 3, col: 2, cols: 3, style: colorIn},
                            {row: 2, rows: 3, col: -5, cols: 3, style: colorIn},
                        ],
                        data: scope.infostr,
                        typeNumber: 1,
                    };
                    q.innerHTML = '';
                    q.appendChild(qrgen.canvas(options));
                };
                draw();//自动调用画图方法
            })(document.querySelector.bind(document));
        }
    };
});