/**
 * 2016/10/8
 * 订单追踪, 选择时间
 */
publicModule.directive('trackTime', ["popupSvc", function(popupSvc){
    return {
    	transclude : true,
    	template : '<div ng-transclude></div>',
    	scope : {
    		startTime : '=',
    		endTime : '=',
    		changeTimeHandler : '&'
    	},
    	link : function(scope, els){
    		var startTimeBtn = angular.element(document.getElementById('start-time')),
    			endTimeBtn = angular.element(document.getElementById('end-time')),
    			weekBtn = angular.element(document.getElementById('week')),
    			oneMonthBtn = angular.element(document.getElementById('one-month')),
    			threeMonthBtn = angular.element(document.getElementById('three-month'));

    		var selectState = '';	//startTime, endTime;
    		var calendar = null;
    		var currentTarget = null,	//当前选择的td
    			currentTime = {
    				startTime : scope.startTime,
    				endTime : scope.endTime
    			};
    		//开始时间
    		startTimeBtn.on('click', function(){
    			selectState = 'startTime';
    			pop("startTime");
    		});

    		//结束时间
    		endTimeBtn.on('click', function(){
    			selectState = 'endTime';
    			pop("endTime");
    		});

    		//周
    		weekBtn.on('click', function(){
    			selectState = '';
				var endDate = new Time(),
					endTime ={
						year : endDate.getFullYear(),
						month : endDate.getMonth() + 1,
						day : endDate.getDate()
					},
					startDate = new Date(endTime.year, endTime.month - 1, endTime.day - 6),
					startTime = {
						year : startDate.getFullYear(),
						month : startDate.getMonth() + 1,
						day : startDate.getDate()
					};
    			currentTime.startTime = formatTime(startTime);
    			currentTime.endTime = formatTime(endTime);
    			scope.changeTimeHandler({
    				startTime : currentTime.startTime,
    				endTime : currentTime.endTime
    			});
    		});

    		//一月
    		oneMonthBtn.on('click', function(){
    			selectState = '';
				var endDate = new Time(),
					endTime ={
						year : endDate.getFullYear(),
						month : endDate.getMonth() + 1,
						day : endDate.getDate()
					},
					startDate = new Date(endTime.year, endTime.month - 2, endTime.day),
					startTime = {
						year : startDate.getFullYear(),
						month : startDate.getMonth() + 1,
						day : startDate.getDate()
					};
    			currentTime.startTime = formatTime(startTime);
    			currentTime.endTime = formatTime(endTime);
    			scope.changeTimeHandler({
    				startTime : currentTime.startTime,
    				endTime : currentTime.endTime
    			});
    		});

    		//三月
    		threeMonthBtn.on('click', function(){
    			selectState = '';
				var endDate = new Time(),
					endTime ={
						year : endDate.getFullYear(),
						month : endDate.getMonth() + 1,
						day : endDate.getDate()
					},
					startDate = new Date(endTime.year, endTime.month - 4, endTime.day),
					startTime = {
						year : startDate.getFullYear(),
						month : startDate.getMonth() + 1,
						day : startDate.getDate()
					};
    			currentTime.startTime = formatTime(startTime);
    			currentTime.endTime = formatTime(endTime);
    			scope.changeTimeHandler({
    				startTime : currentTime.startTime,
    				endTime : currentTime.endTime
    			});
    		});
    		scope.month = '';
    		scope.init = function(){
    			calendar = new _utils.Calendar(document.getElementById('calendar'), new Time());
    			var time = calendar.getTime();

    			scope.month = time.year + '年' + time.month + '月';

    			//如果选择的是开始时间, 并有结束时间
    			if(selectState === 'startTime' && currentTime.endTime){
					calendar.setEndTime(currentTime.endTime.substring(0,4), currentTime.endTime.substring(5,7), currentTime.endTime.substring(8,10));
    			}else if(selectState === 'endTime' && currentTime.startTime){
					calendar.setStartTime(currentTime.startTime.substring(0,4), currentTime.startTime.substring(5,7), currentTime.startTime.substring(8,10));
    			}
    			calendar.render();
    		};
    		scope.select = function(e){
    			var target = e.target;
    			if(target && target.hasAttribute('data-time') && target.className.indexOf('i-disabled') === -1){
    				if(currentTarget) currentTarget.classList.remove('i-selected');
    				currentTarget = target;
    				currentTarget.classList.add('i-selected');
    			}
    		};
    		scope.prevMonth = function(){
    			if(!calendar) return;
    			var date = calendar.getTime();
    			date.month--;
    			if(date.month < 1){
    				date.month += 12;
    				date.year--;
    			}
    			scope.month = date.year + '年' + date.month + '月';
    			calendar.setTime(date.year, date.month);
    			calendar.render();
    		};
    		scope.nextMonth = function(){
    			if(!calendar) return;
    			var date = calendar.getTime();
    			date.month++;
    			if(date.month > 12){
    				date.month -= 12;
    				date.year++;
    			}
    			scope.month = date.year + '年' + date.month + '月';
    			calendar.setTime(date.year, date.month);
    			calendar.render();
    		};
			scope.$on('$destroy', function(){
				startTimeBtn.off('click');
				endTimeBtn.off('click');
				weekBtn.off('click');
				oneMonthBtn.off('click');
				threeMonthBtn.off('click');
			});
    		function splitStr(str){
    			if(typeof str !== 'string') return str;
    			str = str.split('-');
    			return {
    				year : str[0],
    				month : str[1],
    				day : str[2]
    			};
    		}
    		function formatTime(str){
    			var time = splitStr(str);
    			if(time.month < 10) time.month = '0'+time.month;
    			if(time.day < 10) time.day = '0'+time.day;
    			return '' + time.year + '-' + time.month + '-' + time.day;
    		}
    		function pop(state){
    			popupSvc.alert({
    				template : '<div class="calendar-head">' +
					    				'<p ng-bind="month"></p>' +
										'<button class="i-prev" ng-click="prevMonth()">&lt;</button>' +
										'<button class="i-next" ng-click="nextMonth()">&gt;</button>' +
						    		'</div>' +
						    		'<div ng-init="init()" id="calendar" class="calendar" ng-click="select($event)"></div>',
		            cssClass : "popup-alert",
		            scope : scope,
		            buttons: [
		                {
		                    text: '<b>确定</b>',
		                    type: 'button-positive',
		                    onTap: function (e) {
		                    	var str = '';
		                    	if(currentTarget && currentTime[state] != undefined){
		                    		str = currentTarget.getAttribute('data-time');
		                    		currentTime[state] = formatTime(str);
		                    		scope.changeTimeHandler({
					    				startTime : currentTime.startTime,
					    				endTime : currentTime.endTime
					    			});
		                    	}
		                    	currentTarget = null;
		                    }
		                },
		                {text: '取消'}
		            ]
		        });
    		}
    	}
    };
}])
