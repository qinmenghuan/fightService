publicModule.directive('formatNumber', function () {
    return {
        require: 'ngModel',
        link: function (scope, els, attrs, ngModel) {
            if (!ngModel) return;
            els.on('keyup', function (e) {
                //console.log(e.keyCode)
                var v = this.value.replace(/\D/g, function (a) {
                    return '';
                });
                ngModel.$setViewValue(v);
                ngModel.$render();

            });
            scope.$on('$destroy', function () {
                els.off('keyup');
            });
        }
    };
});
publicModule.directive('formatIdCard', function () {
    return {
        require: 'ngModel',
        link: function (scope, els, attrs, ngModel) {
            if (!ngModel) return;
            els.on('keyup', function (e) {
                var v = this.value;
                if (v.length >= 18) {
                    v = v.replace(/.$/, function (a) {
                        if (a.toLowerCase() === 'x' || !isNaN(a)) {
                            return a;
                        } else {
                            return '';
                        }
                    });
                } else {
                    v = v.replace(/(\D*)()/g, function (a) {
                        return '';
                    });
                }
                ngModel.$setViewValue(v);
                ngModel.$render();
            });
            scope.$on('$destroy', function () {
                els.off('keyup');
            });
        }
    };
});
publicModule.directive('formatPwd', function () {
    return {
        require: 'ngModel',
        link: function (scope, els, attrs, ngModel) {
            if (!ngModel) return;
            els.on('keyup', function (e) {
                var v = this.value.replace(/[\W]/g, function (a) {
                    return '';
                });
                ngModel.$setViewValue(v);
                ngModel.$render();

            });
            scope.$on('$destroy', function () {
                els.off('keyup');
            });
        }
    };
});