/**
 * 注册控制器
 * @author wf 2016-1-11
 * @desc
 */

publicModule.directive('errorInfo', [
    'commonTips',
    '$timeout',
    '$rootScope',
    function (commonTips,
              $timeout,
              $rootScope) {
        return {
            restrict: 'EA',
            scope: {
                tipInfo: '@',
                tipClass: '@',
                errorShow: '@'
            },
            template: '<div class="tip-warning {{tipClass}} {{errorShow}}">' +
            '<i class="ion-ios-information icon-small"></i>' +
            '{{netWorkInfo}}{{tipInfo}}' +
            '</div>',
            link: function (scope, element, attrs, ngModel) {
                var promise;
                //断网提醒
                $rootScope.$watch("appNetWork", function (newVl, oldVl) {
                    if (!newVl) {
                        scope.netWorkInfo = commonTips.NETWORK_OFFLINE;
                    } else {
                        scope.netWorkInfo = '';
                    }
                });
                //非断网提醒3秒钟消失
                $rootScope.$watch("tipShow", function (newVl, oldVl) {
                    if (newVl != oldVl) {
                        $timeout.cancel(promise);
                        promise = $timeout(function () {
                            $rootScope.tipShow = false;
                        }, commonTips.NETWORK_DELAY);
                    }
                });
                $rootScope.$watch("tip", function (newVl, oldVl) {
                    if (newVl != oldVl) {
                        $timeout.cancel(promise);
                        promise = $timeout(function () {
                            $rootScope.tip = false;
                        }, commonTips.NETWORK_DELAY);
                    }
                });

                $rootScope.$watch("tip", function (newVl, oldVl) {
                    if (newVl != oldVl) {
                        $timeout.cancel(promise);
                        promise = $timeout(function () {
                            $rootScope.tip = false;
                        }, commonTips.NETWORK_DELAY);
                    }
                });


            }
        };
    }
]);


