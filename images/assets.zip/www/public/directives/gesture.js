/**
 * Created by fengc on 2016/10/9.
 * 9宫格手势解锁。
 */
publicModule.directive('gesture', function(){
	return function(scope, els){
		var chosepic = new Image,
			errorpic = new Image,
			successpic = new Image;

		chosepic.src = 'images/gesture/chose.png';
		errorpic.src = 'images/gesture/error.png';
		successpic.src = 'images/gesture/success.png';

		var gesture = new _utils.DrawGesture(els[0], {
			unchosecolor : '#929394',
			chosecolor : '#666',
			successcolor : '#7dc223',
			errorcolor : '#f4422f',
			chooseFn : scope.chooseFn || function(){},
			touchend : scope.touchend || function(gesture){
				var pwd = gesture.orders.join('');

				//如果密码正确
				if(pwd === '01258'){
					gesture.successStatus();	//设置canvas正确状态
				}else{
					gesture.errorStatus();		//设置canvas错误状态
				}
				setTimeout(function(){
					gesture.clear();		//清空状态
				}, 1000);
			},
			drawInnerRound : function(gesture,ctx,x,y,r,pi){
				var status = gesture.status;
				if(status === 2){
					ctx.drawImage(successpic, x-r * 0.8, y-r * 0.8, r*2*0.8 | 1, r*2*0.8 | 1);
				}else if(status === 3){
					ctx.drawImage(errorpic, x-r * 0.8, y-r * 0.8, r*2*0.8 | 1, r*2*0.8 | 1);
				}else{
					ctx.drawImage(chosepic, x-r * 0.8, y-r * 0.8, r*2*0.8 | 1, r*2*0.8 | 1);
				}
			}
		});

		var timing = 0,
			width = gesture.width,
			height = gesture.height;
		var drawFrame = function(){
			gesture.ctx.clearRect(0,0,width,height);
			gesture.draw();
			timing = requestAnimationFrame(drawFrame);
		};
		scope.$on('canvas.init', function(){
			gesture.init();
			drawFrame();
			console.log(gesture);
		});
		scope.$on('$destroy', function(){
			cancelAnimationFrame(timing);
			gesture.destroy();
		});
	};
});
