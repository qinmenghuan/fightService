/**
 * Created by fengc on 20160510.
 * 卡号自动添加空格。
 */
publicModule.directive('formatCard', function(){
    return {
        require : 'ngModel',
        link : function(scope, els, attrs, ngModel){
            if(!ngModel) return;
            var delSpace = function(val){
                val = val.replace(/\s/g, function(a){ return ''});
                return val;
            };
            //ngModel.$viewValue添加空格
            ngModel.$render = function(){
                var value = ngModel.$viewValue;
                if(value){
                    value = delSpace(value);
                    els[0].value = value.replace(/[\d\s]{4}/g, function(a){
                        return a.substring(0,4) + ' ';
                    });
                } else {
                    //解决第一位输字母不清空的BUG
                    els[0].value = '';
                }
            };

            //ngModel.$modelValue删除空格
            ngModel.$parsers.push(delSpace);

            els.on('keyup', function(e){
                if(e.keyCode === 8) return;
                var value = this.value;
                value = value.replace(/\D/g, function(a){ return ''});
                ngModel.$setViewValue(value);
                ngModel.$render();
            });

            scope.$on('$destroy', function(){
                els.off('keyup');
            });
        }
    };
 });
