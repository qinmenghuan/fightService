/**
 * app公共方法
 * Created by fusy on 2016/9/6.
 */
publicModule.factory("util", function (CONSTANT, resourceSvc, $interval, toolSvc) {
    var util = {
        //生成guid的替代方法
        guid: function () {
            // alert(1);
            var guid = "";
            if (resourceSvc.getLocal(CONSTANT.UUID)) {
                guid = resourceSvc.getLocal(CONSTANT.UUID);
            } else {
                guid = toolSvc.getRandomStr();
                resourceSvc.setLocal(CONSTANT.UUID, guid);
            }
            console.log(guid);
            return guid;
        },
        insertAfter: function insertAfter(newElement, targetElement) {
            var parent = targetElement.parentNode;
            if (parent.lastChild == targetElement) {
                // 如果最后的节点是目标元素，则直接添加。因为默认是最后
                parent.appendChild(newElement);
            }
            else {
                //如果不是，则插入在目标元素的下一个兄弟节点的前面。也就是目标元素的后面
                parent.insertBefore(newElement, targetElement.nextSibling);
            }
        },
        random: function () {
            return Math.ceil(Math.random() * 1000000000);
        },
        countDown: function (config) {
            var options = {timer: 60};
            var interval;
            return {
                run: function (callback, cancelCallback) {
                    if (!interval) {
                        //callback(options.timer);
                        interval = $interval(function () {
                            //获取当前时间毫秒数
                            var startTime = new Date().getTime();
                            //获取结束时间
                            var endTime = config.timer;
                            //得出还剩多少秒
                            var residualTime = {timer: parseInt((endTime - startTime + 2000) / 1000)};
                            var options = angular.extend({
                                timer: 60
                            }, residualTime);
                            callback(--options.timer);
                            if (options.timer <= 0) {
                                $interval.cancel(interval);
                                cancelCallback();
                            }
                        }, 1000);
                    }
                },
                cancel: function () {
                    options.timer = config.timer;
                    $interval.cancel(interval);
                    interval = null;
                }
            }
        },
        /**
         * create by fusy at 2016年3月11日
         * 把指定时间转换为 *天*小时*分钟*秒 的形式
         * @param dif 需要转换的时间毫秒数
         * @returns {{days: number, hours: number, mins: number, seconds: number, dif: date毫秒数}}
         */
        getDHMS: function (dif) {
            var d = Math.floor(dif / 3600 / 24);
            var h = Math.floor((dif / 3600) % 24);
            var m = Math.floor((dif / 60) % 60);
            var s = Math.floor(dif % 60);
            return {
                days: d,
                hours: h,
                mins: m,
                seconds: s,
                dif: dif,
                dStr: d < 10 ? "0" + d : d,
                hStr: h < 10 ? "0" + h : h,
                mStr: m < 10 ? "0" + m : m,
                sStr: s < 10 ? "0" + s : s
            }
        },
        /**
         * * 计时器
         * @param dif 剩余时间 (s)
         * @param callback(DHMS) 倒计时回调方法 HDMS对象 查看getDHMS方法。
         */
        count: function (dif, callback) {
            callback(util.getDHMS(dif--));
            var stop = $interval(function () {
                if (dif <= 0) {
                    $interval.cancel(stop);
                    callback(util.getDHMS(0));
                    return;
                }
                callback(util.getDHMS(dif--));
            }, 1000);
            return {
                cancel: function () {
                    $interval.cancel(stop);
                    callback(util.getDHMS(0));
                }
            };
        },
        /**
         * create by fusy at 2016年3月11日
         * use like
         * toolSvc.countDown(start, end, function(DHMS){
       *    console.log(DHMS.days,DHMS.hours, DHMS.mins, DHMS.secounds, DHMS.dif);
       * })
         *
         * @param start 倒计时开始计数时间 type： 时间字符串
         * @param end  倒计时结束计数时间 type： 时间字符串
         * @param callback 倒计时回调方法 抛出对象DHMS (see getDHMS function);
         */
        countDownTimer: function (start, end, callback) {
            var dif = Math.floor((end - start) / 1000);
            this.count(dif, callback);
        },
        getRecordId: function ($scope, temporarySvc) {
            //从跳转地址或路由中获取传参（产品ID和返回state）
            var url = window.location.hash; //获取url中"?"符后的字串
            var url_info = url.split("?")[1] || "";
            console.log(url_info);
            var params = temporarySvc.get("p5") || {};
            console.log(params);
            $scope.conf = {
                record_id: ''
                , prod_code: ''
                , slideBox: ''
            };
            if (url_info) {
                var pro_params = url_info.split("&");
                var data = {};
                for (var i = 0; i < pro_params.length; i++) {
                    var tmp = pro_params[i].split("=");
                    data[tmp[0]] = tmp[1];
                }
                $scope.conf.record_id = data.ret_id;
                $scope.conf.prod_code = data.pro_id;
                $scope.conf.slideBox = data.pro_code;
            } else {
                $scope.conf.record_id = params.record_id ? params.record_id : "";
                $scope.conf.prod_code = params.prod_code;
                $scope.conf.slideBox = params.slideBox;
            }
            temporarySvc.set("p5", $scope.conf);
            return $scope.conf.record_id;
        }
    };
    return util;
});