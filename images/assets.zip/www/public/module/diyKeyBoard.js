/**
 * Created by fei on 2016/12/10.
 *  author: Mr.wang
 *  diy加密键盘模块
 */
(function (root, factory) {
    if (typeof module !== 'undefined' && module.exports) {
        // CommonJS
        if (typeof angular === 'undefined') {
            factory(require('angular'));
        } else {
            factory(angular);
        }
        // 暴露出的模块名
        module.exports = 'diyKeyboard';
    } else if (typeof define === 'function' && define.amd) {
        // AMD
        define(['angular'], factory);
    } else {
        // Global Variables
        factory(root.angular);
    }
}(this, function (angular) {
    'use strict';
    var mKeyBoard = angular.module('diyKeyboard', []);
    var $el = angular.element;
    var isDef = angular.isDefined; // 判断对象是否定义

    mKeyBoard.provider('diyKeyboard', function () {
        // 声明默认配置选项
        var defaults = this.defaults = {};
        this.setDefaults = function (newDefaults) {
            angular.extend(defaults, newDefaults);
        };
        this.$get = ['ngDialog', '$q', '$rootScope', '$timeout', '$window', '$injector',
            function (ngDialog, $q, $rootScope, $timeout, $window, $injector) {
                // 私有方法
                var privateMethods = {}
                // 公有方法
                var publicMethods = {
                    __PRIVATE__: privateMethods,
                    // 随机键位
                    randomKey: function () {
                        // 声明数字键盘按键
                        var numberArr = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
                        var randomArr = [];
                        for (var i = 0, numberLen = numberArr.length; i < numberLen; i++) {
                            var j = Math.floor(Math.random() * numberArr.length);
                            randomArr[i] = numberArr[j]
                            numberArr.splice(j, 1);
                        }
                        return randomArr;
                    }
                    // 请求

                    // 公有方法结束
                };
                return publicMethods;
            }];
    });
    // 没时间了，暂时拆分开在写，有时间在完善。
    mKeyBoard.directive('diyKeyboardSingle', [
        'diyKeyboard',
        'ngDialog',
        '$timeout',
        function (diyKeyboard, ngDialog, $timeout) {
            return {
                restrict: 'EA',
                replace: true,
                scope: {
                    pwdLen: '=',
                    cbfn: '&'
                },
                templateUrl: "public/tpl/diyKeyboard/diyKeyboardInput.html",
                link: function (scope, elem, attrs) {
                    var pwdIndex = 0;
                    // 设置默认按键个数
                    var pwdLen = attrs.pwdLen || '6';
                    scope.pwdLenArr = new Array(pwdLen * 1);

                    keyBoard();
                    // 打开按键弹框
                    elem.on('click', function (e) {
                        e.preventDefault();
                        keyBoard();
                    });
                    function keyBoard() {
                        // 获取随机键位对应的值
                        scope.numberArr = diyKeyboard.randomKey();
                        // 打开键盘模板
                        ngDialog.open({
                            template: 'public/tpl/diyKeyboard/diyKeyboardMain.html',
                            scope: scope,
                            className: 'ngdialog-theme-keyboard no-overlay',
                            showClose: false,
                            closeByDocument: true,
                            overlay: true,
                            closeByNavigation: true
                        });
                        // });
                        // 监听弹出键盘按键方法
                        scope.getKey = function (event) {
                            if (pwdIndex >= pwdLen) {
                                ngDialog.closeAll();
                                console.log('密码已输入满，准备跳转');
                                return false;
                            }
                            scope.pwdLenArr[pwdIndex] = event.target.innerText.trim();
                            pwdIndex++;
                            scope.cbfn({list: scope.pwdLenArr.join('')});
                            if (pwdIndex >= pwdLen) {
                                $timeout(function () {
                                    ngDialog.closeAll()
                                }, 200);
                                // 输入完成后执行回调
                                return false;
                            }
                        };
                        // 关闭键盘key
                        scope.closeKey = function (event) {
                            ngDialog.closeAll();
                        };
                        // 删除密码key
                        scope.deleteKey = function (event) {
                            if (pwdIndex <= 0) {
                                console.log('密码已清空');
                                return false;
                            }
                            pwdIndex--;
                            scope.pwdLenArr[pwdIndex] = '';
                            console.log('密码数组：', scope.pwdLenArr);
                            scope.cbfn({list: scope.pwdLenArr.join('')});
                        }
                    }


                    // link结束
                }

                // return结束
            }
        }]);
    // 键盘按钮分开指令
    // 设置属性pwdLen可动态设置密码输入框个数，如：4个
    mKeyBoard.directive('diyKeyboard', [
        'diyKeyboard',
        'ngDialog',
        '$timeout',
        function (diyKeyboard, ngDialog, $timeout) {
            return {
                restrict: 'EA',
                scope: {
                    pwdLen: '=',
                    cbfn: '&'
                },
                // require:'^diyKeyboardSingle',
                link: function (scope, elem, attrs) {
                    var pwdIndex = 0;
                    // 设置默认按键个数
                    var pwdLen = attrs.pwdLen || '6';
                    scope.pwdLenArr = new Array(pwdLen * 1);
                    // 打开按键弹框
                    elem.on('click', function (e) {
                        e.preventDefault();
                        // 获取随机键位对应的值
                        scope.numberArr = diyKeyboard.randomKey();
                        // 打开键盘模板
                        ngDialog.open({
                            template: 'public/tpl/diyKeyboard/diyKeyboard.html',
                            scope: scope,
                            className: 'ngdialog-theme-keyboard no-overlay',
                            showClose: false,
                            closeByDocument: true,
                            overlay: true,
                            closeByNavigation: true
                        })
                    });
                    // 监听弹出键盘按键方法
                    scope.getKey = function (event) {
                        if (pwdIndex >= pwdLen) {
                            ngDialog.closeAll();
                            console.log('密码已输入满，准备跳转');
                            return false;
                        }
                        scope.pwdLenArr[pwdIndex] = event.target.innerText.trim();
                        pwdIndex++;
                        console.log('密码数组：', scope.pwdLenArr);
                        if (pwdIndex >= pwdLen) {
                            console.log('密码已输入满，准备跳转');
                            $timeout(function () {
                                ngDialog.closeAll()
                            }, 200);
                            // 输入完成后执行回调
                            scope.cbfn();
                            return false;
                        }
                    };
                    // 关闭键盘key
                    scope.closeKey = function (event) {
                        ngDialog.closeAll();
                    };
                    // 删除密码key
                    scope.deleteKey = function (event) {
                        if (pwdIndex <= 0) {
                            console.log('密码已清空');
                            return false;
                        }
                        pwdIndex--;
                        scope.pwdLenArr[pwdIndex] = '';
                        console.log('密码数组：', scope.pwdLenArr)
                    };
                    // link结束
                }
                // return结束
            }
        }]);
}));