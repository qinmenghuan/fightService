/**
 * app 相关配置 及 常量
 * Created by fusy on 2016/9/6.
 */
// 常量配置
publicModule.constant("CONSTANT", {
    /** localStorage 缓存Key名 */
    MAIN_KEY: "mainKey", //工作密钥
    WORK_KEY: "workKey", //主密钥
    UUID: "uuid",//uuid
    JSESSIONID: "jsessionid", //用户会话标识
    HEAD_JSESSIONID: "head_jsessionid",//用户唯一标识
    USER_INFO: "user_info", //用户信息
    ACCOUNT_INFO: "account_info",//用户安全状态信息
    JSESSIONID_UNIT: "jsessionid_unit",//jsessionid保存时长
    JSESSIONID_TIME: "jsessionid_time", //jsessionid 生成时间
    DICT: "dict",//数据字典
    PARAMS: "params",//系统参数,
    DEVICE: "device",//客户设备
    CHANNEL_SRC: '1', //下载渠道

    /** 返回码 **/
    HEAD_RET_CODE_SUCCESS: "DE0000",
    HEAD_RET_CODE_ERROR: "DE",

    SHORTURL: {
        api: "https://api.weibo.com/2/short_url/shorten.json",
        appKey: "1681459862"
        //appKey: "2849184197"
    },
    /** 弹框提示 **/

    SERVER_RANDOM_ERROR: "获取服务端随机数异常，请稍后再试",
    ACCOUNT_PASSWORD_VALID_ERROR: "请输入6到24位数字和字母组合的登录密码",
    ACCOUNT_NULL: "账号不能为空",
    PHONE_MISMATCHING: "手机号不匹配",
    PHONE_NULL: "手机号不能为空",
    PHONE_ERROR: "手机号码格式有误",
    PHONE_ALREADY: "手机号已存在",
    PHONE_SUCCESS: "新手机号码绑定成功",
    PAY_UNPASSWORD: "您的账号存在安全隐患，暂时无法更换手机号",
    PAY_PASSWORD_NULL: "交易密码不能为空",
    PASSWORD_NULL: "密码不能为空",
    PASSWORD2_NULL: "确认密码不能为空",
    PASSWORD_ERROR: "密码错误",
    PASSWORD_LESS: "至少4位",
    PASSWORD_VALID_ERROR: "密码不合规",
    PASSWORD_SUCCESS: "设置成功",
    PASSWORD_DIFFERENCE: "两次输入的密码不一致",
    PASSWORD_ERROR_TIMES: "密码错误，您还有X次尝试机会",
    PASSWORD_ERROR_LOCK: "密码错误已达上限，2小时后账号解锁",
    NAME_NULL: "请输入您的真实姓名",
    NAME_UNREAL: "姓名需真实",
    ID_NULL: "身份证号不能为空",
    ID_UNVALID: "身份证号格式不正确",
    ID_UN_MATCH: "身份证号不匹配",
    ID_NO_EMPTY: "请输入18位身份证号",
    ID_ALREADY: "身份证已存在",
    CARD_NO_EMPTY: "请输入正确的银行卡卡号",
    CARD_NO_MATCH: "银行卡号不匹配",
    REGISTE_RSUCCESS: "注册成功",
    LOGIN_RSUCCESS: "登录成功",
    AGREEMENT_NONE: "您还未同意协议内容",
    CODE_NULL: "验证码不能为空",
    VALID_CODE_ERROR: "验证码无效",
    NULL_VALID_CODE: "请输入6位数字验证码",
    VALID_ERROR: "验证信息不匹配",
    VOUCHER_NO_NULL: "兑换券不能为空",
    CARD_TYPE_NULL: "银行卡种类不能为空",
    FEEDBACK_NULL: "反馈内容不能为空",
    MONEY_NULL: "金额不能为空",
    MONEY_ZERO: "金额必须大于0",
    MONEY_ERROR: "请输入正确的金额",
    MONEY_MIN: "起存金额应大于",
    MONEY_MAX: "起存金额应小于",
    MONEY_RADIO: "递增金额应为"
});
publicModule.constant('commonTips', {
    VALID_CODE_ERROR: "验证码无效",
    NULL_VALID_CODE: "请输入6位数字验证码",
    VALID_ERROR: "验证信息不匹配",
    NETWORK_OFFLINE: "世上最遥远的距离就是连不上网",
    NETWORK_DELAY: 2000,
    APPNAME: '我惠',
    QQSHARE_TITLE: '我惠',
    SHARE_DESCRIPTION: '小伙伴们，我发现了一个超牛的app，快来下载吧！',
    VALID_CODE_TIME: '60'
});
publicModule.constant("shareTips", {
    SHARE_TITLE: "我惠理财",
    APP_NAME: "我惠理财",
    IMG: "http://g.hiphotos.baidu.com/image/pic/item/9825bc315c6034a8a85c1342c3134954082376b3.jpg",
    INVITE_SHARRE_DESCRIPTION: "各位小伙伴们，我刚刚发现一个超牛的理财APP，快来注册吧。",
    GIFT_SHARE_DESCRIPTION: "快来跟我一起理财吧"
});
// 系统配置
publicModule.constant("CONFIG", {
    IMG_SERVER_URL:'', //文件资源链接地址
    USE_NEW_KEYBOARD:false,
    DEBUG_ON_CHROME: false, //浏览器调试 设置为true 打包app设置为false
    DEBUG_ON_KEYBOARD: false, //密码键盘模式  设置为true为diy键盘  设置为false为cfca键盘
    IMG_CACHE_DEBUG: true, //图片缓存日志是否开启 true为开启
    IMG_CACHE_FOLDER: "huiLifeCache",
    STORAGE_NAME: "adFlage",//首页广告是否开启 true为开启
    HTTP_URL: "http://whkayak.f3322.net:19018/fapp-api/", //服务器地址 公共
    // HTTP_URL: "http://192.168.100.4:8090/fapp-api-wh/", //服务器地址 公共
    // HTTP_URL: "http://192.168.100.11:8090/fapp-api-wh/", //服务器地址 公共
    //HTTP_URL: "http://10.6.95.76:7007/fapp-api-wh/", //服务器地址 公共
    // HTTP_URL: "http://192.168.0.136:8081/fapp-api-wh/", //服务器地址 公共
    // HTTP_URL: "http://10.5.1.146:8080/fapp-api/", //服务器地址 胡飞
    SHARE_URL: "http://whkayak.f3322.net:19018/fapp-api/sharehuiLife/www/",//分享服务器地址 --公共
    MAIN_KEY_URL: "pub010101.json", //同步主密钥的请求地址
    WORK_KEY_URL: "pub010102.json", //同步工作密钥请求地址
    MAIN_TIME: 60 * 60 * 24 * 7, //主密钥有效期 一周
    WORK_TIME: 60 * 60 * 24, //工作密钥有效期 一天
    ALERT_DURATION_TIME: 1000, //消息弹框 默认显示 1000ms后关闭
    CACHE_TIME: 10000, // 接口重复发送时间间隔
    /** 返回页面跳转黑名单配置*/
    BACK_VIEW_BLACK_LIST: [
        "login", "loginGesturePwd", "setGusturePwd", "register", "registerNext", "checkLoginPwd", "paySuccess", "buyFailed", "addBankCard3"],
    /** 不需要验证jsessionid的url **/
    DONT_NEED_CHECK_SESSION_ID: [
        "user030102.json", "pub010101.json", //验证手机号，获取验证码
        "pub010102.json", "user030501.json", //验证验证码,校验输入两次支付密码是否一致
        "acct040105.json", "acct040106.json", //验证银行卡信息(注册)，发送他行卡验证码
        "user030202.json", "version020101.json" //注册,版本更新
    ],
    /** 需要缓存url **/
    CACHE_URL_LIST: [
        'prod050101.json',
    ],

    /** 不需要loading显示的url **/
    NOT_SHOW_LOADING_URL: [],

    //持久缓存名 与上面缓存名称对应
    EVERLASTING: [
        "lockState",
        "GestureLockPwd",
        "phone",
        "hasNewVersions",
        "REVOKE_LIST",
        "custNo",
        "messageRead",
        "messageNo",
        "touchidSupport",
        "TOUCH_ID",
        "U_ID",
        "IS_FIRST_APPLY",
        "HCE_U_ID",
        "FIRST_USE_HCE",
        "app_loader_version" //H5版本
        , "apply_market"//应用市场
        , "adData"//广告缓存
        , "bigData"
    ],


    /** 需要签名的字段，前后端签名顺序需要一致 **/
    MAC_WORDS: [
        "head_jsessionid",
        "user_id",
        "buy_sum",
        "buy_amt",
        "pay_amt",
        "out_amt",
        "trans_no",
        "total_integra"

    ],
    /** 需要加解密字段 **/
    ENCODE_WORDS: [
        "aes_key",
        "hmd5_key",
        "head_jsessionid",
        "acct_no",
        "card_no",
        "id_code",
        "login_name",
        "login_pwd",
        "new_pwd",
        "mobile",
        "bank_mobile"
    ],
    HTTP_TIMEOUT: 10000,
    HTTP_RESPONSE_TYPE: "json",
    HTTP_HEADERS_ACCEPT: "application/json, text/plain, */*",
    HTTP_HEADERS_CONTENT_TYPE: "application/json;charset=utf-8",
    HTTP_FAIL_MESSAGE: "请检查您的网络连接或稍后重试",
    //用户等级
    PERMISSIONS: [{
        PERMISSION_NAME: "Lv1",
        PERMISSION_CONFIG: {
            userPermission: {
                visitor: false,
                login: true
            },
            otherwise: {
                visitor: "login"
            }
        }
    }],
    //app调用浏览器配置
    BROWSER_CONFIG: {
        statusbar: {
            color: '#ffffffff'
        },
        toolbar: {
            height: 44,
            color: '#f0f0f0ff'
        },
        title: {
            color: '#003264ff',
            showPageTitle: true
            // staticText: ""//$stateParams.title
        },
        backButton: {
            wwwImage: 'images/back.png',
            wwwImagePressed: 'images/back.png',
            wwwImageDensity: 3,
            align: 'left',
            event: 'backPressed'
        },
        closeButton: {
            wwwImage: 'images/close.png',
            wwwImagePressed: 'images/close.png',
            wwwImageDensity: 3,
            align: 'right',
            event: 'closePressed'
        },
        /*
         forwardButton: {
         image: 'forward',
         imagePressed: 'forward_pressed',
         align: 'left',
         event: 'forwardPressed'
         },

         customButtons: [
         {
         image: 'share',
         imagePressed: 'share_pressed',
         align: 'right',
         event: 'sharePressed'
         }
         ],
         menu: {
         image: 'menu',
         imagePressed: 'menu_pressed',
         title: 'Test',
         cancel: 'Cancel',
         align: 'right',
         items: [
         {
         event: 'helloPressed',
         label: 'Hello World!'
         },
         {
         event: 'testPressed',
         label: 'Test!'
         }
         ]
         },*/
        backButtonCanClose: true
    }
});
publicModule.constant('AmapTips', {
    tableId: "57fc9b422376c15ffea72d3b"
    //tableId: "578747cf305a2a4e4ff08b64"
});
// .constant('countNUm', {
//     countNUm: 90
// })