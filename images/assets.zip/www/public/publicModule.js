/**
 * 作用：用于统一public文件夹下的模块存放
 */
var publicModule = angular.module('publicModule', ['ngProgress']);

// 设置微信title
/*
publicModule.factory('wxTitleSvc', function() {
	function isWeiXin() {
		var ua = window.navigator.userAgent.toLowerCase();
		if (ua.match(/MicroMessenger/i) == 'micromessenger') {
			return true;
		} else {
			return false;
		}
	}
	return {
		set: function(title) {
			var isIOS = ionic.Platform.isIOS();
			var isWx = isWeiXin();
			if (!(isIOS && isWx)) return;
			var $body = $('body');
			document.title = title;
			var $iframe = $("<iframe style='display:none;' src='/favicon.ico'></iframe>");
			$iframe.on('load', function() {
				setTimeout(function() {
					$iframe.off('load').remove();
				}, 0);
			}).appendTo($body);

		}
	}
});
*/
