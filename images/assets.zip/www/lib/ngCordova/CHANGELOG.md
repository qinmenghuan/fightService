### 0.1.27-alpha (2016-07-06)


### 0.1.27-alpha (2016-07-06)


Please refer to the [Github ngCordova Releases file](https://github.com/driftyco/ng-cordova/releases) for detailed information.
