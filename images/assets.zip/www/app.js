console.log("=====================starter时间：" + (new Date().getTime()));
var starter = angular.module('starter', [
    'ionic',
    'ui.router',
    'publicModule',
    'validation',
    'ngCordova',
    'ksSwiper',
    'commonEvent',
    'monospaced.qrcode',
    'oc.lazyLoad',
    'ngDialog',
    'diyKeyboard'
]);
function Time() {
    if (arguments.length > 0) {
        var ary = [];
        for (var arg in arguments) {
            ary.push(arguments[arg])
        }
        eval("var date = new Date(" + ary.join(',') + ")");
        return date;
    }
    return new Date(Time.aaa());
    // return new Date(time || Time.aaa());
}
Time.aaa = function () {
    return new Date();
    //var date = new Date();
    //return "2021/05/30 " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
};
//todo:分享后打开app
function handleOpenURL(url) {
    console.log(1111);
    console.log(url);
    var newUrl = url.substring(url.indexOf("//") + 2);
    var arr, stateUrl, params;
    console.log(newUrl);
    if (newUrl.indexOf("/")) {
        arr = newUrl.split("/");
        stateUrl = arr[0];
        params = arr[1];
        console.log(stateUrl);
        console.log(params);
        window.location.href = "#/" + stateUrl + "?" + params;
    } else {
        window.location.href = "#/" + newUrl;
    }
    //alert(groupItemId);
    //var groupBuyItemId=url.substring(url.indexOf("//")+22,url.length);
    //alert(groupBuyItemId);
    //window.location.href="#/goods/"+groupItemId+"/"+groupBuyItemId;

}
starter.run(function ($ionicPlatform,
                      $rootScope,
                      $ionicLoading,
                      $timeout,
                      pageJumpSvc,
                      appInitSvc,
                      appInfoSvc,
                      encryptSvc,
                      $window,
                      CONSTANT,
                      $state,
                      $location,
                      CONFIG,
                      resourceSvc,
                      popupSvc,
                      $cordovaToast,
                      $ionicHistory,
                      mapSvc,
                      backButton,
                      imgCacheSvc,
                      deviceSyncSvc,
                      updateSvc) {
    $ionicPlatform.ready(function () {
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);
        }
        if (window.StatusBar) {
            StatusBar.styleDefault();
        }
        // 在设备上运行时候才检测
        if (window.cordova) {
            alert("haha");
            cordova.getAppVersion.getVersionNumber().then(function (version) {
                alert(version);
            });
            //检查版本更新
            //updateSvc.checkForUpdate();
        }
        // 页面跳转服务初始化
        pageJumpSvc.init();
        // app初始化服务（权限控制、初始化）
        appInitSvc.permissionInit();
        imgCacheSvc.$init();
        appInfoSvc.init();
        // deviceSyncSvc.sync();

        // android物理返回键处理初始化--包括双击退出功能
        backButton.init(["/home", "/investList", "/mine", "/loginGesturePwd", "/login", "/busCenter"]);

        // document.addEventListener('deviceready', deviceReady, false);

        $rootScope.$on('$stateChangeStart',
            function (event, toState, toParams, fromState, fromParams) {
                popupSvc.close();
                // console.log(event, toState, toParams, fromState, fromParams);
            })
    });
    //初始化网络设置和消息提醒值
    $rootScope.appNetWork = true;
    //初始化网络设置和消息提醒值
    mapSvc.networkEvent(function () {
        $rootScope.appNetWork = true;
    });
    //启动时手势登录
    /*encryptSvc.then(function (encrypt) {
     if ($window.localStorage[CONSTANT.HEAD_JSESSIONID] && $window.localStorage[CONSTANT.USER_INFO]) {
     var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
     var user_id = userInfo.query("user_id") ? userInfo.query("user_id") : "";
     if (!user_id) {
     return false
     }
     if ($window.localStorage[user_id + "gesturePwd"]) {
     $state.go('loginGesturePwd');
     } else {
     $state.go('login');
     }
     }

     });*/
    //todo:-手势密码-App挂起后  手势密码判断
    function isPause() {
        //记录挂起时间
        $rootScope.pasueDate = new Date().getTime();
    }

    document.addEventListener("pause", isPause);

    //当App被唤醒时
    function isResume() {

        //当app隐藏或退出时,点击推送消息进入app唤醒后清楚ios角标
        if (device.platform == "Android") {
            // alertContent = window.plugins.jPushPlugin.openNotification.alert;
            // alertContent = window.plugins.jPushPlugin.openNotification;
        } else {
            // alertContent = event.aps.alert;
            // alertContent = event.aps;
            // 清除角标
            window.plugins.jPushPlugin.setBadge(0);
            window.plugins.jPushPlugin.resetBadge();
            window.plugins.jPushPlugin.setApplicationIconBadgeNumber(0);
        }

        // //记录唤醒时间
        // $rootScope.resumeDate = new Date().getTime();
        // //计算挂起时间
        // var pasueTime = ($rootScope.resumeDate - $rootScope.pasueDate) / 1000;
        // if (pasueTime > 300) {
        //     encryptSvc.then(function (encrypt) {
        //         if ($window.localStorage[CONSTANT.HEAD_JSESSIONID] && $window.localStorage[CONSTANT.USER_INFO]) {
        //             var userInfo = encrypt.aesLocalTemp(CONSTANT.USER_INFO);
        //             var user_id = userInfo.query("user_id") ? userInfo.query("user_id") : "";
        //             if (!user_id) {
        //                 return false
        //             }
        //             if ($window.localStorage[user_id + "gesturePwd"]) {
        //                 $state.go('loginGesturePwd');
        //             } else {
        //                 $state.go('login');
        //             }
        //         }
        //
        //     });
        // }


    }

    document.addEventListener("resume", isResume);
    if (window.cordova) {
        // TODO: 初始化推送服务
        document.addEventListener("deviceready", function () {
            // window.codePush.sync(null, null, function (downloadProgress) {
            //     if (downloadProgress) {
            //         // $rootScope.progress = downloadProgress;
            //         // console.log('下载进度',downloadProgress);
            //         // window.codePush.notifyApplicationReady();
            //         // window.codePush.restartApplication();
            //     }
            // });

            //插件初始化
            window.plugins.jPushPlugin.init();
            window.plugins.jPushPlugin.resumePush();

            // 清除角标
            window.plugins.jPushPlugin.setBadge(0);
            window.plugins.jPushPlugin.resetBadge();
            window.plugins.jPushPlugin.setApplicationIconBadgeNumber(0);
            var onGetRegistradionID = function (data) {
                try {
                    console.log("JPushPlugin:registrationID is " + data);
                    // alert("JPushPlugin:registrationID is " + data);
                    resourceSvc.setLocal('registrationid', data);
                } catch (exception) {
                    console.log(exception);
                }
            };
            window.plugins.jPushPlugin.getRegistrationID(onGetRegistradionID);


        }, false);

        if (CONFIG.BROWSER_CONFIG == false) {
            // app自接受消息并提示
            document.addEventListener("jpush.receiveNotification", function () {
                var alertContent;
                if (device.platform == "Android") {
                    alertContent = window.plugins.jPushPlugin.receiveNotification.alert;
                } else {
                    alertContent = event.aps.alert;
                }
                alert("推送消息:" + alertContent);
            }, false);
        }
    }
})
;

// 配置区域 ---------------------------------------------------
starter.config(function ($ionicConfigProvider, keyboardSvcProvider, $provide, $compileProvider, $controllerProvider, $filterProvider) {
    starter.controller = $controllerProvider.register;
    starter.directive = $compileProvider.register;
    starter.filter = $filterProvider.register;
    starter.factory = $provide.factory;
    starter.service = $provide.service;
    starter.constant = $provide.constant;


    // 配置区域 ---------------------------------------------------
    $ionicConfigProvider.platform.ios.tabs.style('standard');
    $ionicConfigProvider.platform.ios.tabs.position('bottom');
    $ionicConfigProvider.platform.android.tabs.style('standard');
    $ionicConfigProvider.platform.android.tabs.position('bottom');

    $ionicConfigProvider.platform.ios.navBar.alignTitle('center');
    $ionicConfigProvider.platform.android.navBar.alignTitle('center');

    $ionicConfigProvider.platform.ios.backButton.previousTitleText('').icon('ion-ios-arrow-left');
    $ionicConfigProvider.platform.android.backButton.previousTitleText('').icon('ion-ios-arrow-left');

    $ionicConfigProvider.platform.ios.views.transition('ios');
    $ionicConfigProvider.platform.android.views.transition('android');

    // 默认返回文本
    $ionicConfigProvider.backButton.text('返回');
    // 禁止侧滑
    $ionicConfigProvider.views.swipeBackEnabled(false);

    $ionicConfigProvider.views.maxCache(5);


    keyboardSvcProvider.setConfig({
        outputType: OUTPUT_TYPE_ORIGINAL,
        cipherType: CIPHER_TYPE_RSA,
        serverRandom: "MTIzNDU2Nzg5MDk4NzY1NA=="
    });

});
